/*******************************************************************************
  Transcend Application Source File

  Company:
    Molex, LLC
  Summary:
    This file contains the source code for the Area data structure module.

  COPYRIGHT (C) 2016 Molex - All Rights Reserved

*******************************************************************************/
/**
 * The Area module
 *
 * @module area
 */

'use strict'

var util = require('./ct-util.js')
var latestDeleteSpaceRef ;
/**
 * SpaceRef default properties
 *
 * @type       {Object}
 */
var d_SpaceRef = {
    controller: '',
    space: ''
}

Object.freeze(d_SpaceRef)

/**
 * Creates a new SpaceRef object
 *
 * @memberof   module:area
 *
 * @class      SpaceRef
 *
 * @param      {Object}  json    Properties for the new SpaceRef object. Defaults will be used for any properties missing, props with invalid names will be left out.
 */
var SpaceRef = function (json) {
    util.addPropsOrDefaults(d_SpaceRef, this, json)
    Object.seal(this)
    return this
}

util.definePseudos(SpaceRef.prototype, ['controller', 'space'])
Object.freeze(SpaceRef.prototype)

/**
 * Area default properties
 *
 * @type       {Object}
 */
var d_Area = {
    owner: ''
}
Object.freeze(d_Area)

/**
 * Creates an Area object
 *
 * @memberof   module:area
 *
 * @class      Area
 *
 * @param      {Object}  json    Properties for the new Area object. Defaults will be used for any properties missing, props with invalid names will be left out.
 */
var Area = function (json) {
    util.addPropsOrDefaults(d_Area, this, json)
    this.spaces = util.createMapFromProp('spaces', json, SpaceRef)
    Object.seal(this)
    return this
}

/**
 * Gets SpaceRef IDs filtered by space and controller ID
 *
 * @memberof   module:area.Area
 *
 * @param      {string}  spaceID       The space id
 * @param      {string}  controllerID  The controller id
 *
 * @return     {string[]}  SpaceRef IDs
 */
Area.prototype.getSpaceRefsByIDs = function(spaceID, controllerID) {
    return Object.keys(this.spaces).filter(function (value, index) {
        var ref = this.spaces[value]
        return ref.space === spaceID && ref.controller === controllerID
    }, this)
}
/**
 * Gets SpaceRef IDs filtered by controller ID
 *
 * @memberof   module:area.Area
 *
 * @param      {string}  controllerID  The controller id
 *
 * @return     {string[]}  SpaceRef IDs
 */
Area.prototype.getSpaceRefsByController = function(controllerID) {
    return Object.keys(this.spaces).filter(function (spaceID) {
        return this.spaces[spaceID].controller === controllerID
    }, this)
}
/**
 * Adds a SpaceRef.
 *
 * @memberof   module:area.Area
 *
 * @param      {Object}  ref     Properties for the SpaceRef constructor
 *
 * @return     {string} New SpaceRef ID
 */
Area.prototype.addSpaceRef = function (ref) {
    var id = util.generateID('spaceref', '_', this.spaces)
    this.spaces[id] = new SpaceRef(ref)
    return id
}
/**
 * Deletes a SpaceRef
 *
 * @memberof   module:area.Area
 *
 * @param      {string}   id      The SpaceRef ID
 *
 * @return     {boolean}  true if ID is valid, false otherwise
 */
Area.prototype.deleteSpaceRef = function (id) {
    if (this.spaces.hasOwnProperty(id)) {
        latestDeleteSpaceRef = this.spaces[id]
        delete this.spaces[id]
        return true
    }
    return false
}

util.definePseudo(Area.prototype, 'owner')

Object.freeze(Area.prototype)
/**
 * Area class constructor
 */
module.exports = Area
