/*******************************************************************************
  Transcend Application Source File
 
  Company:
    Molex, LLC
  Summary:
    This file contains the source code for the building data structure module.
 
  COPYRIGHT (C) 2016 Molex - All Rights Reserved 
 
*******************************************************************************/

/**
 * The Building module
 * @module building
 * 
 */

'use strict'

var util = require('./ct-util.js')
var Area = require('./area.js')
var Floor = require('./floor.js')
var Controller = require('./controller.js')

/**
 * Building default properties
 *
 * @type       {Object}
 */
var d_Building = {
    name: '',
    location: '',
    userData: '',
    utilisation: 0
}
Object.freeze(d_Building)

/**
 * Creates a Building object
 * 
 * @memberof   module:building
 *
 * @class      Building 
 * 
 * @param      {Object}  json    Properties for the new Building object. Defaults will be used for missing properties, properties with invalid names will be left out.
 */
var Building = function(json) {
    util.addPropsOrDefaults(d_Building, this, json)
    this.areas = util.createMapFromProp('areas', json, Area)
    this.floors = util.createMapFromProp('floors', json, Floor)
    if (Object.keys(this.floors).length === 0) {
        this.addFloor()
    }
    Object.seal(this)
    return this
}
/**
 * Adds an Area object
 * 
 * @memberof   module:building.Building
 * 
 * @param      {Object}  area    Properties for the Area constructor
 * 
 * @return     {string} New Area ID
 */
Building.prototype.addArea = function(area) {
    var id = util.generateID('area', '_', this.areas)
    this.areas[id] = new Area(area)
    return id
}
/**
 * Deletes an Area from the building
 *
 * @memberof   module:building.Building
 * 
 * @param      {string}   id      The Area identifier
 * 
 * @return     {boolean}  true if ID is valid and Area object deleted successfully, false otherwise
 */
Building.prototype.deleteArea = function(id) {
    if (this.areas.hasOwnProperty(id)) {
        delete this.areas[id]
        return true
    }
    return false
}
/**
 * Adds a Floor object.
 *
 * @memberof   module:building.Building
 * 
 * @param      {Object}  floor   Properties for the Floor consctructor
 * 
 * @return     {string} New floor ID
 */
Building.prototype.addFloor = function(floor) {
    var id = util.generateID('floor', '_', this.floors)
    this.floors[id] = new Floor(floor)
    if (!this.floors[id]._name) {
        this.floors[id]._name = 'Floor ' + id.split('_').pop()
    }
    return id
}
/**
 * Deletes the floor from the building 
 *
 * @memberof   module:building.Building
 * 
 * @param      {string}   id      The Floor identifier
 * 
 * @return     {boolean}  true if ID is valid and floor deleted successfully, false otherwise
 */
Building.prototype.deleteFloor = function(id) {
    if (this.floors.hasOwnProperty(id)) {
        delete this.floors[id]
        return true
    }
    return false
}


util.definePseudo(Building.prototype, 'name')
util.definePseudo(Building.prototype, 'location')
util.definePseudo(Building.prototype,'userData')

util.definePseudoInt(Building.prototype, 'utilisation')

Object.freeze(Building.prototype)

/**
 * Building class constructor
 */
module.exports = Building