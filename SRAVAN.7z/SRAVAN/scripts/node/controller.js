/*******************************************************************************
  Transcend Application Source File

  Company:
    Molex, LLC
  Summary:
    This file contains the source code for the controller data structure module.

  COPYRIGHT (C) 2016 Molex - All Rights Reserved

*******************************************************************************/
/**
 * The Controller module
 * @module controller
 */

'use strict'
var util = require('./ct-util.js')
var spaces = require('./spaces.js')
var GeneralSpace = spaces.GeneralSpace
var UserSpace = spaces.UserSpace
var BeaconSpace = spaces.BeaconSpace
var latestDeleteSpace ;
var latestDeleteGeneralSpace ;
var latestDeleteBeaconSpace ;
/**
 * Default lightScenes properties
 *
 * @type       {Object}
 */
var boilerplate_lightScenes = {
    "Off": {
        "name": "All Off",
        "slot": 1,
        "circadianLink": "circadian",
        "palettes": {
            "default": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
            }
        }
    },
    "creative": {
        "name": "creative",
        "slot": 3,
        "circadianLink": "circadian",
        "palettes": {
            "default": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 220, 0, 0]
            },
            "grey": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 10, 10, 10, 0, 20, 20, 20, 0, 30, 40, 50, 0, 60, 70, 80, 0]
            }
        }
    },
    "meeting": {
        "name": "meeting",
        "slot": 4,
        "circadianLink": "circadian",
        "palettes": {
            "default": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 220, 0, 0]
            },
            "grey": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 10, 10, 10, 0, 20, 20, 20, 0, 30, 40, 50, 0, 60, 70, 80, 0]
            }
        }
    },
    "orbit": {
        "name": "orbit",
        "slot": 5,
        "circadianLink": "circadian",
        "palettes": {
            "default": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 220, 0, 0]
            },
            "grey": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 10, 10, 10, 0, 20, 20, 20, 0, 30, 40, 50, 0, 60, 70, 80, 0]
            }
        }
    },
    "speaker": {
        "name": "speaker",
        "slot": 6,
        "circadianLink": "circadian",
        "palettes": {
            "default": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 220, 0, 0]
            },
            "grey": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 10, 10, 10, 0, 20, 20, 20, 0, 30, 40, 50, 0, 60, 70, 80, 0]
            }
        }
    },
    "daylight": {
        "name": "daylight",
        "slot": 7,
        "circadianLink": "circadian",
        "palettes": {
            "default": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 220, 0, 0]
            },
            "grey": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 10, 10, 10, 0, 20, 20, 20, 0, 30, 40, 50, 0, 60, 70, 80, 0]
            }
        }
    },
    "video": {
        "name": "video",
        "slot": 8,
        "circadianLink": "circadian",
        "palettes": {
            "default": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 220, 0, 0]
            },
            "grey": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 10, 10, 10, 0, 20, 20, 20, 0, 30, 40, 50, 0, 60, 70, 80, 0]
            }
        }
    },
    "personal": {
        "name": "personal",
        "slot": 9,
        "circadianLink": "circadian",
        "Location": "https://www.dropbox.com/shxkzkatxbpmwubqcAAARRLoDavWMjRn4frFBZ-HLadl=0",
        "palettes": {
            "default": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 220, 0, 0]
            },
            "grey": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 10, 10, 10, 0, 20, 20, 20, 0, 30, 40, 50, 0, 60, 70, 80, 0]
            }
        }
    },
    "workingHours": {
        "name": "Working Hours",
        "slot": 10,
        "circadianLink": "circadian",
        "Location": "https://www.dropbox.com/shxkzkatxbpmwubqcAAARRLoDavWMjRn4frFBZ-HLadl=0",
        "palettes": {
            "default": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 220, 0, 0]
            },
            "grey": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 10, 10, 10, 0, 20, 20, 20, 0, 30, 40, 50, 0, 60, 70, 80, 0]
            }
        }
    },
    "outOfHours": {
        "name": "Out Of Hours",
        "slot": 11,
        "circadianLink": "circadian",
        "Location": "https://www.dropbox.com/shxkzkatxbpmwubqcAAARRLoDavWMjRn4frFBZ-HLadl=0",
        "palettes": {
            "default": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 220, 0, 0]
            },
            "grey": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 10, 10, 10, 0, 20, 20, 20, 0, 30, 40, 50, 0, 60, 70, 80, 0]
            }
        }
    },
    "rr": {
        "name": "RR",
        "slot": 12,
        "circadianLink": "circadian",
        "Location": "https://www.dropbox.com/shxkzkatxbpmwubqcAAARRLoDavWMjRn4frFBZ-HLadl=0",
        "palettes": {
            "default": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 220, 0, 0]
            },
            "grey": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 10, 10, 10, 0, 20, 20, 20, 0, 30, 40, 50, 0, 60, 70, 80, 0]
            }
        }
    },
    "stairs": {
        "name": "Stairs",
        "slot": 13,
        "circadianLink": "circadian",
        "Location": "https://www.dropbox.com/shxkzkatxbpmwubqcAAARRLoDavWMjRn4frFBZ-HLadl=0",
        "palettes": {
            "default": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 220, 0, 0]
            },
            "grey": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 10, 10, 10, 0, 20, 20, 20, 0, 30, 40, 50, 0, 60, 70, 80, 0]
            }
        }
    },
    "elevator": {
        "name": "Elevator",
        "slot": 14,
        "circadianLink": "circadian",
        "Location": "https://www.dropbox.com/shxkzkatxbpmwubqcAAARRLoDavWMjRn4frFBZ-HLadl=0",
        "palettes": {
            "default": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 220, 0, 0]
            },
            "grey": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 10, 10, 10, 0, 20, 20, 20, 0, 30, 40, 50, 0, 60, 70, 80, 0]
            }
        }
    },
    "lobby": {
        "name": "Lobby",
        "slot": 15,
        "circadianLink": "circadian",
        "Location": "https://www.dropbox.com/shxkzkatxbpmwubqcAAARRLoDavWMjRn4frFBZ-HLadl=0",
        "palettes": {
            "default": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 220, 0, 0]
            },
            "grey": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 10, 10, 10, 0, 20, 20, 20, 0, 30, 40, 50, 0, 60, 70, 80, 0]
            }
        }
    },
    "exit": {
        "name": "Exit",
        "slot": 16,
        "circadianLink": "circadian",
        "Location": "https://www.dropbox.com/shxkzkatxbpmwubqcAAARRLoDavWMjRn4frFBZ-HLadl=0",
        "palettes": {
            "default": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 220, 0, 0]
            },
            "grey": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 10, 10, 10, 0, 20, 20, 20, 0, 30, 40, 50, 0, 60, 70, 80, 0]
            }
        }
    },
    "cafeteria": {
        "name": "Cafeteria",
        "slot": 17,
        "circadianLink": "circadian",
        "Location": "https://www.dropbox.com/shxkzkatxbpmwubqcAAARRLoDavWMjRn4frFBZ-HLadl=0",
        "palettes": {
            "default": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 220, 0, 0]
            },
            "grey": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 10, 10, 10, 0, 20, 20, 20, 0, 30, 40, 50, 0, 60, 70, 80, 0]
            }
        }
    },
    "aisle": {
        "name": "Aisle",
        "slot": 18,
        "circadianLink": "circadian",
        "Location": "https://www.dropbox.com/shxkzkatxbpmwubqcAAARRLoDavWMjRn4frFBZ-HLadl=0",
        "palettes": {
            "default": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 220, 0, 0]
            },
            "grey": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 10, 10, 10, 0, 20, 20, 20, 0, 30, 40, 50, 0, 60, 70, 80, 0]
            }
        }
    },
    "feature": {
        "name": "Feature",
        "slot": 19,
        "circadianLink": "circadian",
        "Location": "https://www.dropbox.com/shxkzkatxbpmwubqcAAARRLoDavWMjRn4frFBZ-HLadl=0",
        "palettes": {
            "default": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 0, 0, 90, 0, 0, 220, 0, 0]
            },
            "grey": {
                "index": 1,
                "rgba": [0, 0, 0, 0, 10, 10, 10, 0, 20, 20, 20, 0, 30, 40, 50, 0, 60, 70, 80, 0]
            }
        }
    },
    "oneColour": {
        "name": "One Colour",
        "slot": 2,
        "circadianLink": "false",
        "palettes": {
          "default": {
            "index": 1,
            "rgba": [
            255,255,255,255
            ]
          },
          "fire": {
              "index": 1,
              "rgba": [255,0,0,0]
          },
          "ok": {
              "index": 1,
              "rgba": [0,255,0,0]
          },
          "blue": {
              "index": 1,
              "rgba": [0,0,255,0]
          }
        }
    }

}
Object.freeze(boilerplate_lightScenes)

/**
 * Controller default properties
 *
 * @type       {Object}
 */
var d_Controller = {
    address: '127.0.0.1:8069',
    name: '',
    location: '',
    config: '',
    lightScenes: boilerplate_lightScenes,
    "animatedPalettes":{
              "circadian":{
                "interpolation": "lerp",
                "mix": "multiplier",
                "0":{"index":1,"rgba":[150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0]},
                "4.2":{"index":1,"rgba":[150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0]},
                "8.3":{"index":1,"rgba":[150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0]},
                "12.5":{"index":1,"rgba":[150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0]},
                "16.7":{"index":1,"rgba":[150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0]},
                "20.8":{"index":1,"rgba":[150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0]},
                "25":{"index":1,"rgba":[112,178,255,0, 112,178,255,0, 112,178,255,0, 112,178,255,0, 112,178,255,0, 112,178,255,0, 112,178,255,0, 112,178,255,0, 112,178,255,0, 112,178,255,0, 112,178,255,0, 112,178,255,0, 112,178,255,0, 112,178,255,0, 112,178,255,0]},
                "29.2":{"index":1,"rgba":[132,204,255,0, 132,204,255,0, 132,204,255,0, 132,204,255,0, 132,204,255,0,  132,204,255,0, 132,204,255,0, 132,204,255,0, 132,204,255,0, 132,204,255,0, 132,204,255,0, 132,204,255,0, 132,204,255,0, 132,204,255,0, 132,204,255,0]},
                "33.3":{"index":1,"rgba":[165,229,255,0, 165,229,255,0, 165,229,255,0, 165,229,255,0, 165,229,255,0, 165,229,255,0, 165,229,255,0, 165,229,255,0, 165,229,255,0, 165,229,255,0, 165,229,255,0, 165,229,255,0, 165,229,255,0, 165,229,255,0, 165,229,255,0]},
                "37.5":{"index":1,"rgba":[193,234,255,0, 193,234,255,0, 193,234,255,0, 193,234,255,0, 193,234,255,0, 193,234,255,0, 193,234,255,0, 193,234,255,0, 193,234,255,0, 193,234,255,0, 193,234,255,0, 193,234,255,0, 193,234,255,0, 193,234,255,0, 193,234,255,0]},
                "41.7":{"index":1,"rgba":[209,242,255,0, 209,242,255,0, 209,242,255,0, 209,242,255,0, 209,242,255,0, 209,242,255,0, 209,242,255,0, 209,242,255,0, 209,242,255,0, 209,242,255,0, 209,242,255,0, 209,242,255,0, 209,242,255,0, 209,242,255,0, 209,242,255,0]},
                "45.8":{"index":1,"rgba":[216,249,255,0, 216,249,255,0, 216,249,255,0, 216,249,255,0, 216,249,255,0, 216,249,255,0, 216,249,255,0, 216,249,255,0, 216,249,255,0, 216,249,255,0, 216,249,255,0, 216,249,255,0, 216,249,255,0, 216,249,255,0, 216,249,255,0]},
                "50":{"index":1,"rgba":[221,255,255,0, 221,255,255,0, 221,255,255,0, 221,255,255,0, 221,255,255,0, 221,255,255,0, 221,255,255,0, 221,255,255,0, 221,255,255,0, 221,255,255,0, 221,255,255,0, 221,255,255,0, 221,255,255,0, 221,255,255,0, 221,255,255,0]},
                "54.2":{"index":1,"rgba":[219,249,244,0, 219,249,244,0, 219,249,244,0, 219,249,244,0, 219,249,244,0, 219,249,244,0, 219,249,244,0, 219,249,244,0, 219,249,244,0, 219,249,244,0, 219,249,244,0, 219,249,244,0, 219,249,244,0, 219,249,244,0, 219,249,244,0]},
                "58.3":{"index":1,"rgba":[216,242,234,0, 216,242,234,0, 216,242,234,0, 216,242,234,0, 216,242,234,0, 216,242,234,0, 216,242,234,0, 216,242,234,0, 216,242,234,0, 216,242,234,0, 216,242,234,0, 216,242,234,0, 216,242,234,0, 216,242,234,0, 216,242,234,0]},
                "62.5":{"index":1,"rgba":[212,230,219,0, 212,230,219,0, 212,230,219,0, 212,230,219,0, 212,230,219,0, 212,230,219,0, 212,230,219,0, 212,230,219,0, 212,230,219,0, 212,230,219,0, 212,230,219,0, 212,230,219,0, 212,230,219,0, 212,230,219,0, 212,230,219,0]},
                "66.7":{"index":1,"rgba":[202,219,204,0, 202,219,204,0, 202,219,204,0, 202,219,204,0, 202,219,204,0, 202,219,204,0, 202,219,204,0, 202,219,204,0, 202,219,204,0, 202,219,204,0, 202,219,204,0, 202,219,204,0, 202,219,204,0, 202,219,204,0, 202,219,204,0]},
                "70.8":{"index":1,"rgba":[191,209,183,0, 191,209,183,0, 191,209,183,0, 191,209,183,0, 191,209,183,0, 191,209,183,0, 191,209,183,0, 191,209,183,0, 191,209,183,0, 191,209,183,0, 191,209,183,0, 191,209,183,0, 191,209,183,0, 191,209,183,0, 191,209,183,0]},
                "75":{"index":1,"rgba":[178,191,158,0, 178,191,158,0, 178,191,158,0, 178,191,158,0, 178,191,158,0, 178,191,158,0, 178,191,158,0, 178,191,158,0, 178,191,158,0, 178,191,158,0, 178,191,158,0, 178,191,158,0, 178,191,158,0, 178,191,158,0, 178,191,158,0]},
                "79.2":{"index":1,"rgba":[163,165,114,0, 163,165,114,0, 163,165,114,0, 163,165,114,0, 163,165,114,0, 163,165,114,0, 163,165,114,0, 163,165,114,0, 163,165,114,0, 163,165,114,0, 163,165,114,0, 163,165,114,0, 163,165,114,0, 163,165,114,0, 163,165,114,0]},
                "83.3":{"index":1,"rgba":[150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0]},
                "87.5":{"index":1,"rgba":[150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0]},
                "91.7":{"index":1,"rgba":[150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0]},
                "95.8":{"index":1,"rgba":[150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0]},
                "100":{"index":1,"rgba":[150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0, 150,150,115,0]}
              }
            }
}
Object.freeze(d_Controller)

/**
 * Creates a Controller object
 *
 * @memberof   module:controller
 *
 * @class      Controller
 *
 * @param      {Object}  json    Properties for the new Controller object. Defaults will be used for missing properties, properties with invalid names will be left out.
 */
var Controller = function(json) {
    util.addPropsOrDefaults(d_Controller, this, json)
    Object.keys(this.lightScenes).forEach(function (lsID) {
        if (!(this.lightScenes[lsID].hasOwnProperty('circadianLink'))) {
            this.lightScenes[lsID].circadianLink = 'circadian'
        }
    }, this)
    this.lightScenes['Off'].circadianLink = false
    this.spaces = spaces.createMap(json)
}

Object.defineProperty(Controller.prototype, '_amBXSpaces', {
    get: function () {
        var ownSpaces = this.spaces
        var amBXSpaceVals = []
        Object.keys(ownSpaces).forEach(function (id) {
            amBXSpaceVals.push(ownSpaces[id]._amBXSpace)
        })
        return amBXSpaceVals
    }
})
/**
 * Adds a general space.
 *
 * @memberof   module:controller.Controller
 *
 * @param      {Object}  space   Properties for the GeneralSpace constructor
 *
 * @return     {string} New Space ID
 */
Controller.prototype.addGeneralSpace = function (space) {
    var id = util.generateID('gen_space', '_', this.spaces)
    // if(latestDeleteGeneralSpace != undefined){
    //     id = util.lastDeletedValue(id , latestDeleteGeneralSpace)
    //     latestDeleteGeneralSpace = undefined
    // }
    var spaceVal = util.findFreeNum(this._amBXSpaces, 0)
    // var aSpaceVal = id.split("_");
    // var spaceVal = parseInt(aSpaceVal[2])
    this.spaces[id] = new GeneralSpace(space)
    if (!this.spaces[id]._name || this.spaces[id]._name === 'default') {
        this.spaces[id]._name = 'General Space ' + id.split('_').pop()
    }
    this.spaces[id]._amBXSpace = spaceVal
    return id
}
/**
 * Adds an Beacon space.
 *
 * @memberof   module:controller.Controller
 *
 * @param      {Object}  space   Properties for the BeaconSpace constructor
 *
 * @return     {string} New Space ID
 */
Controller.prototype.addBeaconSpace = function (space) {
    var id = util.generateID('inf_space', '_', this.spaces)
    // if(latestDeleteBeaconSpace != undefined){
    //     id = util.lastDeletedValue(id , latestDeleteBeaconSpace)
    //     latestDeleteBeaconSpace = undefined
    // }

    var spaceVal = util.findFreeNum(this._amBXSpaces, 0)
    // var aSpaceVal = id.split("_");
    // var spaceVal = parseInt(aSpaceVal[2])
    this.spaces[id] = new BeaconSpace(space)
    if (!this.spaces[id]._name || this.spaces[id]._name === 'default') {
        this.spaces[id]._name = 'Utility Space ' + id.split('_').pop()
    }
    this.spaces[id]._amBXSpace = spaceVal
    return id
}

/**
 * Adds an user space.
 *
 * @memberof   module:controller.Controller
 *
 * @param      {Object}  space   Properties for the UserSpace constructor
 *
 * @return     {string} New Space ID
 */
Controller.prototype.addUserSpace = function (space) {
    var id = util.generateID('user_space', '_', this.spaces)
    // if(latestDeleteSpace != undefined){
    //     id = util.lastDeletedValue(id , latestDeleteSpace)
    //     latestDeleteSpace = undefined
    // }

    var spaceVal = util.findFreeNum(this._amBXSpaces, 0)
    // var aSpaceVal = id.split("_");
    // var spaceVal = parseInt(aSpaceVal[2])
    this.spaces[id] = new UserSpace(space)
    if (!this.spaces[id]._name || this.spaces[id]._name === 'default') {
        this.spaces[id]._name = 'User Space ' + id.split('_').pop()
    }
    this.spaces[id]._amBXSpace = spaceVal
    return id
}

/**
 * Deletes a space.
 *
 * @memberof   module:controller.Controller
 *
 * @param      {string}   id      The Space identifier
 *
 * @return     {boolean}  true if ID is valid and object deleted successfully, false otherwise
 */
Controller.prototype.deleteSpace = function (id) {
    if (this.spaces.hasOwnProperty(id)) {
        var deleteSpace = this.spaces[id].name.split(" ")
        if(deleteSpace[0] === "General"){

          latestDeleteGeneralSpace = this.spaces[id]
        }
        if(deleteSpace[0] === "Information"){

          latestDeleteBeaconSpace = this.spaces[id]
        }
        if(deleteSpace[0] === "User"){
          latestDeleteSpace = this.spaces[id]
        }
        delete this.spaces[id]
        return true
    }
    return false
}
/**
 * Gets the default space ID.
 *
 * @memberof   module:controller.Controller
 *
 * @return     {string}  The default space identifier.
 */
Controller.prototype.getDefaultSpace = function() {
    return this.getSpacesOfType('Default')[0]
}
/**
 * Gets the general space IDs.
 *
 * @memberof   module:controller.Controller
 *
 * @return     {string[]}  The general space IDs.
 */
Controller.prototype.getGeneralSpaces = function () {
    var spaces = this.spaces
    return Object.keys(spaces).filter(function (spaceID) {
        return spaces[spaceID] instanceof GeneralSpace
    })
}
/**
 * Gets the beacon space IDs.
 *
 * @memberof   module:controller.Controller
 *
 * @return     {string[]}  The beacon space IDs.
 */
Controller.prototype.getBeaconSpaces = function() {
    var spaces = this.spaces
    return Object.keys(spaces).filter(function (spaceID) {
        return spaces[spaceID] instanceof BeaconSpace
    })
}

/**
 * Gets the user space IDs.
 *
 * @memberof   module:controller.Controller
 *
 * @return     {string[]}  The user space IDs.
 */
Controller.prototype.getUserSpaces = function() {
    var spaces = this.spaces
    return Object.keys(spaces).filter(function (spaceID) {
        return spaces[spaceID] instanceof UserSpace
    })
}

/**
 * Gets the space IDs of a particular type.
 *
 * @memberof   module:controller.Controller
 *
 * @param      {string}  type    The Space type
 *
 * @return     {string[]}  The space IDs.
 */
Controller.prototype.getSpacesOfType = function(type) {
    var spaces = this.spaces
    return Object.keys(spaces).filter(function (spaceID) {
        return spaces[spaceID]._type === type
    })
}


util.definePseudos(Controller.prototype, ['address', 'name', 'location', 'config'])

Object.freeze(Controller.prototype)
/**
 * Controller class constructor
 */
module.exports = Controller
