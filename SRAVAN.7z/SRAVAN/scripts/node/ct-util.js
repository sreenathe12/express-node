/*******************************************************************************
  Transcend Application Source File

  Company:
    Molex, LLC
  Summary:
    This file contains the source code for the utility module.

  COPYRIGHT (C) 2016 Molex - All Rights Reserved

*******************************************************************************/

/**
 * Utility functions
 * @module ct-util
 *
 */

'use strict'

var fs = require('fs')
// var lastDeletedValue ;
var findFreeNum =
/**
 * Finds the lowest available integer in an array. Sorts into ordered sequence and returns first 'gap' or increments maximum
 *
 * @param      {Array}  array    The array of ints
 * @param      {number}  minimum  The minimum accepted value
 *
 * @return     {number}  Lowest integer not present in the array
 */
    /*  Sorts array of integers into ordered sequence finds lowest free number,
        ie either finds a 'gap' in the array or increments the max value if the set is complete
        eg given [4, 8, 9, 3, 1] returns 7
        but given [1, 2, 3] returns 4 */

exports.findFreeNum = function (array, minimum) {

    var minv = minimum !== undefined ? minimum : 0
    if (array.length === 0) {
        return minv
    }
    if (array.length > 1) {
        array.sort(function(a, b) {
            return a - b
        })
    }
    for (var i = 0; i < array.length; i++) {
          var a = i + minv

        if (array[i] !== i + minv) {
            var lastValue = array[array.length - 1]
                return lastValue + 1
        }
    }
  return array.length + minv

}
/**
 * Finds lowest integer not present in an array of ints
 */

var lastDeletedValue =
/**
 * Generates a new user space if last one deleted.
 *
 * @param      {Object}  latestDeleteSpace
 * @param      {Object}  id
 *
 * @return     {string}  Resulting ID: prefix + separator + generated number
 */

exports.lastDeletedValue = function (id, latestDeleteSpace){
      var lastV = latestDeleteSpace.name
      var lastV2 = lastV.split(" ");
      if(latestDeleteSpace.amBXSpace){
        var latestDeleted = parseInt(lastV2[2])
        var id1 = id.split("_");
        var id2 = parseInt(id1[2])
        if(latestDeleted >= id2){
          var id3 = latestDeleted + 1
          return id = id1[0]+"_"+id1[1]+"_"+id3
        }
      }else{
        var latestDeleted = parseInt(lastV2[1])
        var id1 = id.split("_");
        var id2 = parseInt(id1[1])
        if(latestDeleted >= id2){
          var id3 = latestDeleted + 1
          id = id1[0]+"_"+id3
          return id
        }
        if(latestDeleted < id2){
          id = id1[0]+"_"+id2
          return id
        }
      }

}

var generateID =

/**
 * Generates a new simple string key for an object.
 *
 * @param      {string}  prefix     The ID prefix
 * @param      {string}  separator  The ID separator
 * @param      {Object}  targetObj  The target object
 *
 * @return     {string}  Resulting ID: prefix + separator + generated number
 */
exports.generateID = function (prefix, separator, targetObj) {
    /*  Filter the object for keys that match the desired ID format (prefix string + sep + number),
        extract the number parts, sort them and find the lowest available number to generate a new ID*/

    var newID = 1
    var arrIDNums = []
    var reID
    var arrKeysMatched
    if (targetObj === undefined) {
        return prefix + separator + 1
    }
    reID = new RegExp(prefix + separator + '[0-9]+')
    arrKeysMatched = Object.keys(targetObj).filter(function(value) {
        return value.match(reID)
    })
    if (arrKeysMatched.length === 0) {
        return prefix + separator + 1
    }
    if (separator !== undefined && prefix !== undefined) {
        arrIDNums = arrKeysMatched.map(function(value, index) {
            return parseInt(value.split(separator).pop())
        })
    } else {
        arrIDNums = arrKeysMatched.map(function(value, index) {
            return parseInt(value)
        })
    }
    newID = findFreeNum(arrIDNums, 1)
    return prefix + separator + newID
}

var createMap =
/**
 * Creates an object of instances of class from the properties of a source object.
 *
 * @param      {Object}    source  The source object
 * @param      {Function}  thing   The contructor function
 *
 * @return     {Object} The resulting object, whose keys are the same as those of 'source' and the values are instances of 'thing'
 */
exports.createMap = function (source, thing) {
    /*  Treat source as a map of instances of thing, call constructor of thing
        on every property in source. If bCreateDefault is set and source has no enumerable props,
        create a default construct using id made from idBase and idSep*/
    var result = {}
    var src = source !== undefined ? source : {}
    Object.keys(src).forEach(function(key) {
        result[key] = new thing(src[key])
    })
    return result
}

var createMapFromProp =
/**
 * Creates an object of instances of a class from the specified property of a source object
 *
 * @param      {string}  prop    The property name
 * @param      {Object}  source  The source object
 * @param      {Function}  thing   The constructor called on each property of source[prop]
 *
 * @return     {Object}  Resulting object: keys the same as those of 'source', values are instances of 'thing'
 */
exports.createMapFromProp = function (prop, source, thing) {
    /*  Create map from propert prop of source object.*/
    if (source !== undefined) {
        return createMap(source[prop], thing)
    }
    return createMap({}, thing)
}

var copyProperties =
/**
 * Copy all own properties from the source object to the target object
 *
 * @param      {Object}  source  The source object
 * @param      {Object}  target  The target object
 *
 * @return     {Object} The target object
 */
exports.copyProperties = function (source, target) {
    /*  Copy properties from source object to target object*/
    Object.keys(source).forEach(function(prop) {
        target[prop] = source[prop]
    })
    return target
}


var addPropsOrDefaults =
/**
 * Copies properties from a source object to a target object, operating only on default property names, using default values for any properties missing in source object
 *
 * @param      {Object}  defaults  The defaults object: keys define the properties copied from source to target, default values are copied to target if they're missing in source
 * @param      {Object}  target    The target object
 * @param      {Object}  source    The source object
 *
 * @return     {Object} The modified target object
 */
exports.addPropsOrDefaults = function(defaults, target, source) {
    /*  Add properties to an object using defaults if they're missing in the source object */
    if (source === undefined) {
        copyProperties(defaults, target)
    } else {
        Object.keys(defaults).forEach(function(prop) {
            target[prop] = source[prop] !== undefined ? source[prop] : defaults[prop]
        })
    }
    return target
}

var mergeProps =
/**
 * Merges properties from source object to target object: copies property values from source if target has the same property name.
 *
 * @param      {Object}  source  The source object
 * @param      {Object}  target  The target object
 *
 * @return     {Object} The modified target object
 */
exports.mergeProps = function(source, target) {
    /*  Merge source object into target.
        Copy properties from source if and only if target has the same property */
    Object.keys(target).forEach(function(key) {
        if (source[key] !== undefined) {
            target[key] = source[key]
        }
    })
    return target
}


var setRestricted =
/**
 * Sets property on 'this' object, restricted by an array of permitted values, ie if the value provided is not in the array, does nothing
 *
 * @param      {string}  propName         The property name
 * @param      {Array}   permittedValues  The permitted values
 * @param      {string}  val              The value
 */
exports.setRestricted = function(propName, permittedValues, val) {
    /*  Create a set function that restrics desired property to array of permitted values */
    if (permittedValues.indexOf(val) >= 0) {
        this[propName] = val
    } else {
        console.error(val + ' is not a valid argument for ' + propName)
    }
}

var definePseudo =
/**
 * Defines a simple pseudo-property on an object to act a proxy for the given property name
 * (useful for sticking to a convention if only some of your pseudo properties have side-effects)
 *
 * @param      {Object}  obj     The object
 * @param      {string}  prop    The property
 */
exports.definePseudo = function (obj, prop) {
    /*  Define pseudo property on obj for prop with getter and setter */
    Object.defineProperty(obj, '_' + prop, {
        get: function() {
            return this[prop]
        },
        set: function(val) {
            this[prop] = val
        }
    })
}

var definePseudos =
/**
 * Defines multiple simple pseudo-properties on an object
 *
 * @param      {Object}  obj     The object
 * @param      {Array}  props   The property names
 */
exports.definePseudos =
function (obj, props) {
    /*  Define pseudo props on obj from props array */
    props.forEach(function(prop) {
        definePseudo(obj, prop)
    })
}


var definePseudoInt =
/**
 * Defines a non-enumerable property on an object with a getter and setter acting on a different specified property, always setting it to a valid integer
 *
 * @param      {Object}  obj        The object
 * @param      {string}  prop       The name of the enumerable property on which to act
 * @param      {string}  pseudonym  The name to use for the pseudo property
 *
 * @return     {Object} The object with newly defined properties
 */
exports.definePseudoInt =
function (obj, prop, pseudonym) {
    /*  Define pseudo property on obj which always sets the value to Number */
    var name = pseudonym !== undefined ? pseudonym : '_' + prop
    Object.defineProperty(obj, name, {
        get: function() {
            return this[prop]
        },
        set: function(val) {
            var num = parseInt(val, 10)
            if (Number.isSafeInteger(num)) {
                this[prop] = val
            }
        }
    })
    return obj
}

var definePseudoInts =
/**
 * Defines multiple pseudo-properties on an object which set specified properties to integer values
 *
 * @param      {Object}  obj     The object
 * @param      {Array}   props   The property names object: keys are the object's own property names, values are the names to use for the pseudo property
 *
 * @return     {Object} The object with newly defined properties
 */
exports.definePseudoInts =
function (obj, props) {
    /*  Define pseudo properties on obj which always sets the value to Number */
    props.forEach(function(prop) {
        definePseudoInt(obj, prop)
    })
    return obj
}

var defineNamedPseudoInts =
/**
 * Defines multiple pseudo-properties on an object which set specified properties to integer
 *
 * @param      {Object}  obj     The object
 * @param      {Object}  props   The properties object: keys are object's enumerable properties on which to act,
 *                               values are names for the pseudo properties associated with them
 *
 * @return     {Object} The object with newly defined properties
 */
exports.defineNamedPseudoInts =
function (obj, props) {
    /*  Define integer pseudo properties on obj, using object props,
        whose keys are the names of the properties to modify and whose values are the
        pseudonyms to use*/
    Object.keys(props).forEach(function(prop) {
        definePseudoInt(obj, prop, props[prop])
    })
    return obj
}

var defineRestrictedPseudo =
/**
 * Define a pseudo property on an object which restricts the value of another specified property to an array of permitted values
 *
 * @param      {Object}  obj     The object
 * @param      {string}  prop    The property name
 * @param      {Array}   vals    The permitted values
 *
 * @return     {Object} The object with the newly defined property
 */
exports.defineRestrictedPseudo =
function (obj, prop, vals) {
    /*  Define pseudo property on obj whose setter restricts it to an array of permitted values */
    Object.defineProperty(obj, '_' + prop, {
        get: function() {
            return this[prop]
        },
        set: function(val) {
            if (vals.indexOf(val) >= 0) {
                this[prop] = val
                return true
            } else if ((typeof val) === 'number') {
                var iVal = parseInt(val, 10)
                this[prop] = vals[iVal % vals.length]
                return true
            } else {
                console.error(val + ' is not a valid value for ' + prop)
                return false
            }
        }
    })
    return obj
}

var defineRestrictedPseudos =
/**
 * Define multiple pseudo-properties on an object which restrict specified properties to arrays of permitted values
 *
 * @param      {Object}  obj     The object
 * @param      {Object}  props   The properties object: keys are object's property names, values are arrays of permitted values for those properties
 *
 * @return     {Object} The object with newly defined properties
 */
exports.defineRestrictedPseudos =
function (obj, props) {
    /*  Define pseudo props on obj using object props, whose keys are the prop names
        and point to arrays of permitted values */
    Object.keys(props).forEach(function(prop) {
        defineRestrictedPseudo(obj, prop, props[prop])
    })
    return obj
}

var Point =
/**
 * Creates a 2D point object
 *
 * @param      {number}  x       X-coordinate
 * @param      {number}  y       Y-coordinate
 *
 * @return     {Object} Simple 2D point object with properties x and y
 */
exports.Point =
function (x, y) {
    this.x = Number(x)
    this.y = Number(y)
    return this
}

/**
 * Extracts individual IP address components from IPv4 address string
 *
 * @param      {string}  ipString  The IP address string
 *
 * @return     {Array} Array of four strings definig the components of the IP address
 */
function getIPArray(ipString) {
    /*  Extract integers components from IP address string, setting to 0 is absent or wrong format.
        Return array of integers */
    var stringArray = []
    var result = []
    if (ipString !== undefined) {
        stringArray = ipString.split('.').slice(0, 4)
        if (stringArray.length < 4) {
            while (stringArray.length < 4) {
                stringArray.push('0')
            }
        }
    } else {
        stringArray = ['0', '0', '0', '0']
    }
    stringArray.forEach(function(ipElementString) {
        var ipInt = parseInt(ipElementString, 10)
        if (!Number.isSafeInteger(ipInt)) {
            ipInt = 0
        }
        result.push(ipInt % 256)
    })
    return result
}


var incrementIP =
/**
 * Increments an IP address by 1
 *
 * @param      {string}    ipString  The IP address string
 * @return     {string}  Incremented IP address
 */
exports.incrementIP =
function (ipString) {
    /*  Extract array of ints from input string, increment IP address by 1, join back into a string.
        Return new IP string. */
    var components = ipString.split(':')
    var address = components[0]
    var strPort = components[1] !== undefined ?
        components[1] :
        '80'
    var numPort = parseInt(strPort, 10)
    numPort = Number.isSafeInteger(numPort) ?
            numPort % 65535 :
            80
    var ip = getIPArray(address)
    ip.reverse()
    ip.some(function(ipElement, index) {
        ipElement = (ipElement + 1) % 256
        ip[index] = ipElement
        if (ipElement !== 0) {
            return true
        }
    })
    ip.reverse()
    return ip.join('.') + ':' + numPort
}

var ipify =
/**
 * Forces a string into an IPv4 address
 *
 * @param      {string}  ipString  The input string
 *
 * @return     {string}  IP address formed. If input was malformed/invalid, 0 will replace invalid component numbers and 80 will replace the port number
 */
exports.ipify =
function  (ipString) {
    /*  Force input string into 'proper' IP address.*/
    var ipString = ipString !== undefined ?
            ipString :
            ''
    var components = ipString.split(':')
    var address = components[0]
    var strPort = components[1] !== undefined ?
            components[1] :
            '80'
    var numPort = parseInt(strPort, 10)
    numPort = Number.isSafeInteger(numPort) ?
            numPort % 65535 :
            80

    return ipString = getIPArray(address).join('.') + ':' + numPort
}

exports.ipify = ipify


var parseTrigger =
/**
 * Reads start and end time from trigger string, returns two strings as an array
 *
 * @method     parseTrigger
 * @param      {string}  trigger  Trigger of the form 'bt#hh:mm hh:mm' eg 'bt#08:00 20:00'
 *
 * @return     {string[]} Array consisting of two strings: start time and end time, or empty strings if invalid input
 */
exports.parseTrigger = function (trigger) {
    var sep = trigger.split('#')
    if (sep.length === 2) {
        var times = sep[1].split(' ')
        if (times.length === 2) {
            var isValid = times.every(function (time) {
                return time.split(':').every(function (part) {
                    return Number.isSafeInteger(parseInt(part, 10))
                })
            })
            if (isValid) {
                return times
            }
        }
    }
    return ['', '']
}


/**
 * Makes a 24H time string from two input integers (hours and minutes)
 *
 * @method     toTimeHrsMins
 * @param      {number}  hours    input hours
 * @param      {number}  minutes  input minutes
 *
 * @return     {string} 24H time string of the form 'hh:mm'
 */
function toTimeHrsMins(hours, minutes) {
    var parts = ['00', '00']
    parts[0] = Number.isSafeInteger(hours) ? (hours % 24).toString(10) : '00'
    parts[1] = Number.isSafeInteger(minutes) ? (minutes % 60).toString(10) : '00'
    if (parts[0].length < 2) {
        parts[0] = '0' + parts[0]
    }
    if (parts[1].length < 2) {
        parts[1] = '0' + parts[1]
    }
    return parts.join(':')
}


var isFile =
/**
 * Determines if arg is a file, but doesn't cry/throw if it doesn't exist.
 *
 * @param      {string}   filePath  The file path
 *
 * @return     {boolean}  True if file, False otherwise.
 */
exports.isFile = function (filePath) {
  try{
    var stats = fs.statSync(filePath)
    console.log('isFile stats: ', stats)
    return stats.isFile()
  }
  catch (err) {
    console.log('isFile error:', err)
    return false
  }
}
