/*******************************************************************************
  Transcend Application Source File

  Company:
    Molex, LLC
  Summary:
    This file contains the source code for the fixture and sensor data structure module.

  COPYRIGHT (C) 2016 Molex - All Rights Reserved

*******************************************************************************/
/**
 * The devices module
 * @module devices
 */

'use strict'

var util = require('./ct-util.js')

var amBXLocations =
    /**
     * Permitted amBXLocation values
     * @type       {string[]}
     */
    exports.amBXLocations = [
        'NW', 'N', 'NE',
        'W', 'C', 'E',
        'SW', 'S', 'SE'
    ]

var amBXLocationsOriented =
    /**
     * amBXLocations ordered clockwise from North
     * @type       {string[]}
     */
    exports.amBXLocationsOriented = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW']

// NOTE-MAK: added CoAPv1.1
var protocols = ['MolexUDPv1', 'CoAPv1', 'CoAPv1.1']

/**
 * Default Device properties
 *
 * @type       {Object}
 */
var d_Device = {
    name: '',
    id: '',
    controller: '',
    space: '',
    amBXLocation: 'N',
    gridX: -1,
    gridY: -1,
    address: '',
    userData: '',
    protocol: 'MolexUDPv1'
}

Object.freeze(d_Device)

/**
 * Device - the base class for fixtures and sensors
 *
 * @class      Device
 *
 * @memberof   module:devices
 *
 * @param      {Object}  json    Options - properties for the Device object
 */
var Device = function (json) {
    util.addPropsOrDefaults(d_Device, this, json)
    if (json.hasOwnProperty('address')) {
        this.address = json.address
    }
}

Object.defineProperty(Device.prototype, '_protocol', {
    get: function () {
        return this.protocol
    },
    set: function (val) {
        if (protocols.indexOf(val) >= 0) {
            this.protocol = val
            if (this.protocol === 'MolexUDPv1') {
                this.address = this.address.split(':')[0] + ':' + 9760
            } else {
                this.address = this.address.split(':')[0] + ':' + 5683
            }
        }
    }
})

// NOTE-MAK: added coapIdentifier to ct-util.js (utility/helper) Object.defineProperty
util.definePseudos(Device.prototype, ['name', 'id', 'controller', 'space', 'address', 'userData'])

util.defineRestrictedPseudos(Device.prototype, {
    amBXLocation: amBXLocations
})

util.definePseudoInt(Device.prototype, 'gridX', '_x')
util.definePseudoInt(Device.prototype, 'gridY', '_y')

/**
 * Sets device position to the specified grid coords
 *
 * @memberof   module:devices.Device
 *
 * @param      {number}  x       Grid x-coordinate
 * @param      {number}  y       Grid y-coordinate
 */
Device.prototype.moveTo = function (x, y) {
    this._x = x
    this._y = y
}

Object.freeze(Device.prototype)

/**
 * Valid fixture type values
 *
 * @type       {string[]}
 */
var fixtureTypes = ['MolexTroffer', 'EnOcean', 'Molex Beacon', 'Unknown']
/**
 * Valid fixture role values
 *
 * @type       {string[]}
 */
var fixtureRoles = ['Ambient', 'Task', 'Accent']
/**
 * Valid color space values
 *
 * @type       {string[]}
 */
var colorSpaces = ['RGB', 'RGBW', 'KI', 'I', 'CWWW', 'CW']

/**
 * Default Fixture properties
 *
 * @type       {Object}
 */
var d_Fixture = {
    type: 'MolexTroffer',
    role: 'Ambient',
    colorSpace: 'CWWW'
}

Object.freeze(d_Fixture)

/**
 * Fixture class
 *
 * @class      Fixture
 * @memberof   module:devices
 * @param      {Object}  json    Properties for the Fixture object
 */
var Fixture = exports.Fixture = function (json) {
    Device.call(this, json)
    util.addPropsOrDefaults(d_Fixture, this, json)
    Object.seal(this)
}

Fixture.prototype = Object.create(Device.prototype)

util.defineRestrictedPseudos(Fixture.prototype, {
    type: fixtureTypes,
    role: fixtureRoles,
    colorSpace: colorSpaces
})

Object.freeze(Fixture.prototype)

/**
 * Valid sensor type values
 *
 * @type       {string[]}
 */

var sensorTypes = ['MolexSensor', 'EnOcean','Molex Beacon', 'Unknown']
/**
 * Valid sensor role values
 *
 * @type       {string[]}
 */
 /*NOTE-KAMLESH: Added 'TEMP','HUM'. Issue: DT-30, DT-32 */
var sensorRoles = ['AQ', 'AL', 'PW', 'CT', 'PIR', 'SW', 'TEMP', 'HUM']

/**
 * Default Sensor properties
 *
 * @type       {Object}
 */
var d_Sensor = {
    type: 'MolexSensor',
    role: 'AQ',
    pollingRate: 0
}

Object.freeze(d_Sensor)

/**
 * Sensor class
 *
 * @class      Sensor
 * @memberof   module:devices
 * @param      {Object}  json    Properties for the sensor object.
 */
var Sensor = exports.Sensor = function (json) {
    Device.call(this, json)
    util.addPropsOrDefaults(d_Sensor, this, json)
    Object.seal(this)
}

Sensor.prototype = Object.create(Device.prototype)

util.defineRestrictedPseudos(Sensor.prototype, {
    role: sensorRoles,
    type: sensorTypes
})

util.definePseudoInt(Sensor.prototype, 'pollingRate')

Object.freeze(Sensor.prototype)
