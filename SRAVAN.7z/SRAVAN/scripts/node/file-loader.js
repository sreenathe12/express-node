/*******************************************************************************
  Transcend Application Source File

  Company:
    Molex, LLC
  Summary:
    This file contains the source code for the project loader module.

  COPYRIGHT (C) 2016 Molex - All Rights Reserved

*******************************************************************************/

/**
 * The file-loader module handles project loading and saving to the local file system. 
 * 
 * @module file-loader
 */

var path = require('path')
var os = require('os')

var fse = require('fs-extra')
var tar = require('tar-fs')
var zlib = require('zlib')

/**
 * The application's temp directory.
 * @type {string}
 */
var tempDir = path.join(os.tmpdir(), 'design-tool', 'tmp')

/**
 * 'Promisifies' a Node.js callback-based async function: the resulting function should not be passed a callback and will return a Promise instead.
 * @memberof module:file-loader#
 * @param {function} func - The async function to 'promisify'. It is expected that this function takes a callback as its last arugment, and that the callback expects an Error as its first argument following Node.js convention
 * 
 * @returns {function} A new function that returns a Promise, invoking func with the arguments passed, and resolving/rejecting with any data/error that func's callback might expect. 
 */
var promisify = function (func) {
  return function (...args) {
    return new Promise(function (resolve, reject) {
      func(...args, function (err, ...data) {
        if (err) {
          reject(err)
        } else {
          resolve(...data)
        }
      })
    })
  }
}

/**
 * Compresses a directory into a ".tar.gz" format with the custom ".dt" file extension
 * @param {string} src - The directory to compress 
 * @param {string} dest - The destination file path for the compression's output
 * @returns {promise} - The resulting file path, wrapped in a Promise
 */
var compress = function (src, dest) {
  var destPath = path.extname(dest) === '.gz' ? dest : dest + '.gz'

  return promisify(fse.ensureFile)(destPath)
    .then(function () {
      return new Promise(function (resolve, reject) {
        var fstream = fse.createWriteStream(destPath)
        var gzip = zlib.createGzip()
        fstream
          .on('error', function (err) {
            reject(err)
          })
          .on('finish', function () {
            resolve(destPath)
          })
        tar
          .pack(src)
          .pipe(gzip)
          .pipe(fstream)
      })
    })
}

/**
 * Saves a project by bundling it into a ".tar.gz"-like archive together with the specified floorplan directory.
 * @param {object} project - The project object
 * @param {string} floorplans - The path to the floorplans directory
 * @param {dest} dest - The destination file path
 * @returns {promise} - Output file path wrapped in a Promise
 */
exports.saveProject = function (project, floorplans, dest) {
  var floorsDir = path.resolve(String(floorplans))
  var target = path.resolve(String(dest))

  return promisify(fse.stat)(floorsDir)
    .then(function (stats) {
      if (stats.isDirectory()) {
        return Promise.all([promisify(fse.emptyDir)(tempDir), promisify(fse.ensureFile)(target)])
      } else {
        throw new Error(floorsDir + ' is not a directory')
      }
    })
    .then(function () {
      return promisify(fse.copy)(floorsDir, tempDir)
    })
    .then(function () {
      return promisify(fse.writeJSON)(path.join(tempDir, 'project.json'), project)
    })
    .then(function () {
      return compress(tempDir, target)
    })
}

/**
 * Unpacks a .tar.gz project, putting the floorplans into the specified directory and the project into a temporary directory.
 * 
 * @param {string} file - The source file to unpack
 * @param {string} floorplanDest - The destination directory for the floor plan files
 * 
 * @returns {promise} - The project file path wrapped in a promise
 */
var unpack = function (file, floorplanDest) {
  var gunzip = zlib.createGunzip()
  var fstream = fse.createReadStream(file)

  return new Promise(function (resolve, reject) {
    fstream
      .pipe(gunzip)
      .pipe(tar.extract(floorplanDest))
      .on('error', function (err) {
        reject(err)
      })
      .on('finish', function () {
        resolve(path.join(floorplanDest, 'project.json'))
      })
  })
}

/**
 * Loads a project from the specified file
 * 
 * @param {string} file - The file path
 * @param {string} floorplanDest - The destination directory for unpacking the floor floorplans
 * 
 * @returns {promise} The project object wrapped in a promise
 */
exports.loadProject = function (file, floorplanDest) {
  var src = path.resolve(file)
  var fpDest = path.resolve(floorplanDest)
  var clear = promisify(fse.emptyDir)

  return promisify(fse.stat)(src)
    .then(function (stats) {
      if (!stats.isFile()) {
        throw new Error(`${file} is not a file`)
      }
      return clear(fpDest)
    })
    .then(function () {
      return path.extname(src) === '.json' ?
        Promise.resolve(src) :
        unpack(src, fpDest)
    })
    .then(function (projectPath) {
      return promisify(fse.readJSON)(projectPath)
    })
}