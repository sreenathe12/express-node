/*******************************************************************************
  Transcend Application Source File

  Company:
    Molex, LLC
  Summary:
    This file contains the source code for the floor data structure module.

  COPYRIGHT (C) 2016 Molex - All Rights Reserved

*******************************************************************************/

/**
 * The Floor module
 * @module  floor
 */
'use strict'

var util = require('./ct-util.js')
var devices = require('./devices.js')
var Fixture = devices.Fixture
var Sensor = devices.Sensor
var latestDeleteSensor ;
var latestDeleteFixture ;

/**
 * Default options for the Floor class constructor
 * @type {Object}
 */
var d_Floor = {
    name: '',
    floorPlan: '',
    // DWGFile: '',
    gridW: 100,
    gridH: 100,
    fixtures: {},
    sensors: {}
}
Object.freeze(d_Floor)

var Floor =
    /**
     * Floor - represents floor objects in the project data structure.
     *
     * @class   Floor
     *
     * @param   {Object} json - Properties for the Floor object
     */
    module.exports = function (json) {
        util.addPropsOrDefaults(d_Floor, this, json)
        this.fixtures = util.createMapFromProp('fixtures', json, Fixture)
        this.sensors = util.createMapFromProp('sensors', json, Sensor)
        Object.seal(this)
    }

/**
 * Adds a fixture to the floor.
 *
 * @param {Object}  fixture - The fixture object.
 * @param {string}  idPrefix - The prefix for the fixture's ID (for generating this fixture's key in the floor.fixtures key-value map)
 * @returns {string} The fixture's ID.
 */
Floor.prototype.addFixture = function (fixture, idPrefix) {
    var id = util.generateID(idPrefix, '_', this.fixtures)
    if(latestDeleteFixture != undefined){
        id = util.lastDeletedValue(id , latestDeleteFixture)
        latestDeleteFixture = undefined
    }
    this.fixtures[id] = new Fixture(fixture)
    var fArr = this.fixtures[id].name
    var fArr2 = fArr.split(" ");
    var fNewArr = id.split("_");
    if(fArr2[1] <= fNewArr[1] ){
      this.fixtures[id]._name = fArr2[0]+" "+fNewArr[1]
    }
    if (!this.fixtures[id]._name) {
        this.fixtures[id]._name = 'Fixture ' + id.split('_').pop()
    }
    return id
}

/**
 * Deletes a fixture from the floor.
 *
 * @param {string} id - The id of the fixture to delete
 * @returns {boolean} true if id was valid and fixture was removed successfully, false otherwise.
 */
Floor.prototype.deleteFixture = function (id) {
    if (this.fixtures.hasOwnProperty(id)) {
        latestDeleteFixture = this.fixtures[id]
        delete this.fixtures[id]
        return true
    }
    return false
}
/**
 * Gets a list of fixture IDs associated with the given controllerID
 *
 * @param {string} controllerID - The controller ID
 *
 * @returns {string[]} Array of fixture IDs
 */
Floor.prototype.getFixturesByController = function (controllerID) {
    var fixtures = this.fixtures
    return Object.keys(fixtures).filter(function (fixtureID) {
        return fixtures[fixtureID]._controller === controllerID
    })

}
/**
 * Gets a list of fixtures that are both inside the given [MapRef]{@link module:spaces.MapRef} and associated with the given controller.
 *
 * @param {Object} mapRef - The mapRef object.
 * @param {string} controllerID - The controller ID
 *
 * @return {string[]} Array of fixture IDs
 */
Floor.prototype.getFixturesInMap = function (mapRef, controllerID) {
    var fixtures = this.fixtures
    return Object.keys(fixtures).filter(function (fixtureID) {
        var fixture = fixtures[fixtureID]
        return mapRef.contains(fixture._x, fixture._y) && fixture._controller === controllerID
    })
}
/**
 * Adds a sensor to the floor.
 *
 * @param {Object}  sensor - The sensor object.
 * @param {string}  idPrefix - The prefix for the sensor's ID (for generating this sensor's key in the floor.sensors key-value map)
 * @returns {string} The sensor's ID.
 */
Floor.prototype.addSensor = function (sensor, idPrefix) {
    var id = util.generateID(idPrefix, '_', this.sensors)

    if(latestDeleteSensor != undefined){
        id = util.lastDeletedValue(id , latestDeleteSensor)
        latestDeleteSensor = undefined
    }
    var lastSensor = Object.keys(this.sensors)[Object.keys(this.sensors).length-1];
    this.sensors[id] = new Sensor(sensor)

  if(lastSensor){
        this.sensors[id].pollingRate = this.sensors[lastSensor].pollingRate;
  }
    var sArr = this.sensors[id].name
    var sArr2 = sArr.split(" ");
    var sNewArr = id.split("_");
    if(sArr2[1] <= sNewArr[1] ){
      this.sensors[id]._name = sArr2[0]+" "+sNewArr[1]
    }
    if (!this.sensors[id]._name) {
        this.sensors[id]._name = 'Sensor ' + id.split('_').pop()
    }
    console.log(id)
    return id
}
/**
 * Deletes a sensor from the floor.
 *
 * @param {string} id - The id of the sensor to delete
 * @returns {boolean} true if id was valid and sensor was removed successfully, false otherwise.
 */
Floor.prototype.deleteSensor = function (id) {
    if (this.sensors.hasOwnProperty(id)) {
        latestDeleteSensor = this.sensors[id]
        delete this.sensors[id]
        return true
    }
    return false
}
/**
 * Gets a list of sensor IDs associated with the given controllerID
 *
 * @param {string} controllerID - The controller ID
 *
 * @returns {string[]} Array of sensor IDs
 */
Floor.prototype.getSensorsByController = function (controllerID) {
    var sensors = this.sensors
    return Object.keys(sensors).filter(function (sensorID) {
        return sensors[sensorID]._controller === controllerID
    })
}
/**
 * Gets a list of sensors that are both inside the given [MapRef]{@link module:spaces.MapRef} and associated with the given controller.
 *
 * @param {Object} mapRef - The mapRef object.
 * @param {string} controllerID - The controller ID
 *
 * @return {string[]} Array of sensor IDs
 */
Floor.prototype.getSensorsInMap = function (mapRef, controllerID) {
    var sensors = this.sensors
    return Object.keys(sensors).filter(function (sensorID) {
        var sensor = sensors[sensorID]
        return mapRef.contains(sensor._x, sensor._y) && sensor._controller === controllerID
    })
}


util.definePseudos(Floor.prototype, ['name', 'floorPlan', 'DWGFile'])
util.definePseudoInts(Floor.prototype, ['gridW', 'gridH'])


Object.freeze(Floor.prototype)
