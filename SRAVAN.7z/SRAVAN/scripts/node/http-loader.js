/*******************************************************************************
  Transcend Application Source File

  Company:
    Molex, LLC
  Summary:
    This file contains the source code for the project loader module.

  COPYRIGHT (C) 2016 Molex - All Rights Reserved

*******************************************************************************/

var path = require('path')
var http = require('http')

var fse = require('fs-extra')
var mime = require('mime-types')

var ERR_STATS_NOT_FILE = 'not a file'

/**
 * The http-loader module handles uploading/downloading projects to/from the controller. 
 * 
 * @module http-loader
 */

/**
 * 
 */
var uploadFile = function (file, host, port, uploadPath, callback) {
  var filePath = path.resolve(file)
  fse.stat(filePath, function (err, stats) {
    var req, opts, fstream
    if (err || !stats.isFile()) {
      return callback && callback(err || { message: ERR_STATS_NOT_FILE })
    }
    opts = {
      protocol: 'http:',
      hostname: String(host),
      port: parseInt(port, 10),
      path: String(uploadPath),
      method: 'PUT',
      headers: {
        'Content-Type': mime.lookup(fileName),
        'Content-Length': stats.size
      }
    }
    req = http.request(opts, function (res) {
      if (res.statusCode !== 200) {
        return callback && callback({ message: res.statusCode + ': ' + res.statusMessage })
      }
    })
    fstream = fse.createReadStream(filePath)
    fstream.on('error', function (err) {
      callback && callback(err)
    })
    fstream.pipe(req, { end: false })
    fstream.on('end', function () {
      req.end(function () {
        callback && callback()
      })
    })
  })
}

var uploadFilesCont = function (files, ipAddress, callback) {
  var uploadAsync = function (index) {
    if (index >= files.length) {
      return callback && callback()
    }
    uploadFile(files[index], ipAddress, function (err) {
      if (err && err.message !== ERR_STATS_NOT_FILE) {
        callback && callback(err)
      }
      return setTimeout(function () {
        uploadAsync(index + 1)
      }, 200)
    })
  }

  uploadAsync(0)
}

/**
 * Uploads a project to a controller
 *
 * @param      {string}    ipAddress        The SmartCore/controller IP address
 * @param      {string}    projectName      The project name
 * @param      {Function}  cb               The callback
 */
exports.uploadProject = function (project, projectID, controllerIP, callback) {
  var request
  var options
  var projectObj = {}
  var data
  var host = controllerIP.split(':')[0]
  var port = 80
  projectObj = Object.create(project)
  projectObj.lastModifiedDate = (new Date()).toISOString()
  data = JSON.stringify(projectObj)
  options = {
    protocol: 'http:',
    hostname: host,
    port: port,
    path: '/b/project/' + projectID,
    method: 'PUT',
    headers: {
      'Content-Type': 'text/plain',
      'Content-Length': data.length
    }
  }
  request = http.request(options, function (response) {
    if (response.statusCode !== 200) {
      return callback && callback({ message: response.statusCode + ': ' + response.statusMessage })
    }

  })
    .on('error', function (err) {
      callback && callback()
    })

  request.end(data, 'utf8')
}