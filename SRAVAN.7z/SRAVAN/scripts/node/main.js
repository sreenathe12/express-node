/*******************************************************************************
  Transcend Application Source File

  Company:
    Molex, LLC
  Summary:
    This file contains the source code for the nodeMain file.

  COPYRIGHT (C) 2016 Molex - All Rights Reserved

*******************************************************************************/

/**
 * The module used as the app's nodeMain module. This module manages the current project and several variables of the app's state.
 * Most of the file system interaction is done in this module, as well as any communication with the controller.
 * @module main
 */

'use strict'

var Project = require('./project.js')
var loader = require('./file-loader.js')
var util = require('./ct-util.js')

var fs = require('fs-extra')
var mime = require('mime-types')
var path = require('path')
var http = require('http')
var os = require('os')
var pjson = require('../../package.json')
/**
 * File path for storing the app's state when it quits.
 *
 * @type       {string}
 */
var DEFAULT_STATE_PATH = path.join(os.tmpdir(), 'design-tool')
/**
 * File path for storing floor plan files
 *
 * @type       {string}
 */
var FLOORPLAN_PATH = path.join(DEFAULT_STATE_PATH, 'floorplans')

/**
 * Default Project ID (key associated with the project in its data struct)
 * @type  {string}
 */
var DEFAULT_PROJECT_ID = 'Molex'

/**
 * Global project object
 *
 * @type {Object}
 */
var g_project

/**
 * Application state
 * @typedef {Object} State
 *
 * @property {string} projectFile - Project file path
 * @property {string} projectID - Project ID
 * @property {string} currentBuildingID - The string key for the current building
 * @property {string} currentFloorID - The string key for the current floor
 * @property {string} currentControllerID - The string key for the current controller
 */

/**
 * Global state object
 * @type {State}
 */
var g_state = {
  projectFile: '',
  projectID: '',
  currentBuildingID: '',
  currentFloorID: '',
  currentControllerID: ''

}

Object.seal(g_state)
// exports.state = g_state

var init =
  /**
   * Main init: looks for existing state and project in the file system, creates a new project if they're absent
   *
   * @memberof   module:main
   */
  exports.init = function () {
    var stateFile = DEFAULT_STATE_PATH + 'ct-state' + pjson.version.replace(/\./g,
      '-') + '.json'
    try {
      // var stats = fs.statSync(stateFile)
      var stateContent = fs.readFileSync(stateFile, 'utf8')
      var stateObj = JSON.parse(stateContent)
      util.mergeProps(stateObj, g_state)
      if (g_state.projectFile === '') {
        throw 'no project file'
      }
      initProject(g_state.projectFile)
    } catch (err) {
      newProject()
    }
    if (!fs.existsSync(DEFAULT_STATE_PATH)) {
      fs.mkdirSync(DEFAULT_STATE_PATH, fs.W_OK | fs.R_OK)
    }
  }

function toDataURL(src, callback, outputFormat) {
  var img = new Image();
  img.crossOrigin = 'Anonymous';
  img.onload = function() {
    var canvas = document.createElement('CANVAS');
    var ctx = canvas.getContext('2d');
    var dataURL;
    canvas.height = this.naturalHeight;
    canvas.width = this.naturalWidth;
    ctx.drawImage(this, 0, 0);
    dataURL = canvas.toDataURL(outputFormat);
    callback(dataURL);
  };
  img.src = src;
  if (img.complete || img.complete === undefined) {
    img.src = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==";
    img.src = src;
  }
}
function wait(ms){
   var start = new Date().getTime();
   var end = start;
   while(end < start + ms) {
     end = new Date().getTime();
  }
}
var importFloorPlan =
  /**
   * Imports a floor plan for the specified floor
   *
   * @memberof   module:main
   *
   * @param      {string}    file             The file path
   * @param      {string}    floorID          The floor id
   * @param      {string}    buildingID       The building id
   * @param      {Function}  cb               The callback
   */
    exports.importFloorPlan = function (file, floorID, buildingID, cb) {
        var destFileName = floorID + path.extname(file)
        var localPath = path.join(FLOORPLAN_PATH, g_state.projectID, buildingID,
            destFileName)
        fs.mkdirs(path.dirname(localPath), function (err) {
            if (err) {
                return (cb && cb(err))
            }

            fs.readdir(path.dirname(localPath), function (err, files) {
                files.forEach(function(file) {
                    var ext = path.extname(file)
                    var base = path.basename(file, ext)
                    if (base === floorID) {
                        fs.remove(path.dirname(localPath) + '\\' + file);
                    }
                })

            })
            fs.copy(file, localPath, {
                clobber: true
            }, function (err) {
                if (err) {
                    return (cb && cb(err))
                }
                toDataURL(
                    file,
                    function (dataUrl) {
                        // console.log('%c       ', 'font-size: 100px; background: url('+dataUrl+') no-repeat;');
                        wait(3000);
                        g_project.buildings[buildingID].floors[floorID].floorPlan =
                            dataUrl
                    }
                )

                return cb && cb()
            })

        })
    }

var newProject =
  /**
   * Creates a new project and resets global state vars
   *
   * @memberof   module:main
   */
  exports.newProject = function () {
    g_project = new Project()
    g_state.currentBuildingID = Object.keys(g_project.buildings)[0]
    g_state.currentControllerID = Object.keys(g_project.controllers)[0]
    g_state.currentFloorID = Object.keys(g_project.buildings[g_state.currentBuildingID]
      .floors)[0]
    g_state.projectFile = ''
    g_state.projectID = DEFAULT_PROJECT_ID
    fs.emptyDirSync(FLOORPLAN_PATH, function (err) {
      if (err) {
      }
    })
    return true
  }

var initProject =
  /**
   * Create new project from file
   *
   * @memberof   module:main
   *
   * @param      {string}  projectFile  The project file path
   */
  exports.initProject = function (projectFile) {
    if (projectFile === undefined || projectFile === '') {
      newProject()
    }
    try {
      var fileContent = fs.readFileSync(projectFile, 'utf8')
      var projectObject = JSON.parse(fileContent)
      var projectID = Object.keys(projectObject)[0]
      g_state.projectID = projectID
      g_project = new Project(projectObject[projectID])
      g_state.currentBuildingID = Object.keys(g_project.buildings)[0]
      g_state.currentControllerID = Object.keys(g_project.controllers)[0]
      g_state.currentFloorID = Object.keys(g_project.buildings[g_state.currentBuildingID]
        .floors)[0]
    } catch (err) {
      newProject()
    }
  }

var loadProject =
  /**
   * Loads a project from file
   *
   * @param      {string}    projectFile  The project file path
   * @param      {Function}  callback     The callback
   */
  exports.loadProject = function (projectFile, callback) {
    loader.loadProject(projectFile, FLOORPLAN_PATH)
      .then(function (project) {
        var id = Object.keys(project)[0]
        g_state.projectFile = projectFile
        g_state.projectID = id
        g_project = new Project(project[id])
        g_state.currentBuildingID = Object.keys(g_project.buildings)[0]
        g_state.currentFloorID = Object.keys(getCurrentBuilding().floors)[0]
        g_state.currentControllerID = Object.keys(g_project.controllers)[0]
        callback && callback()
      })
      .catch(function (err) {
        callback && callback(err)
      })
  }

/**
 * Downloads floor plans for a list of floor IDs, chaining HTTP requests recursively. Iterates from <index> to 0.
 *
 * @memberof   module:main
 *
 * @param      {string}   host          The controller host
 * @param      {number}   port          The port number
 * @param      {string}   buildingPath  The building path for the HTTP request
 * @param      {array}    floorIDs      Array of floor IDs
 * @param      {number}   index         The index of current floor ID
 * @param      {function} callback      The callback for the last item
 */
function downloadFloorPlans(host, port, buildingPath, floorIDs, index, callback) {
  if (index < 0) {
    if (callback) {
      window.setTimeout(callback, 100)
    }
  } else {
    var request
    var floorID = floorIDs[index]
    var floorPath = buildingPath + '/' + floorID
    var options = {
      protocol: 'http:',
      hostname: host,
      port: port,
      path: floorPath,
      method: 'GET'
    }
    request = http.request(options, function (response) {
      if (response.statusCode === 200) {
        var buildingID = buildingPath.split('/')
          .pop()
        var destDir = path.join(FLOORPLAN_PATH, g_state.projectID, buildingID)
        fs.mkdirs(destDir, {
          clobber: true
        }, function (err) {
          if (err) {
            callback(err)
            return window.setTimeout(downloadFloorPlans, 200, host,
              port, buildingPath, floorIDs, index - 1, callback)
          }
          var dataURI = g_project.buildings[buildingID].floors[floorID].floorPlan
          var extension = path.extname(g_project.buildings[buildingID].floors[
            floorID].floorPlan)
          var fstream
          var destPath = path.join(destDir, floorID + '.jpeg')
          var dataURI1 = dataURI.split(',')
          let buff = new Buffer(dataURI1[1], 'base64');
          var fstream = fs.writeFile(destPath ,buff, function () {
            window.setTimeout(downloadFloorPlans, 200, host, port,
              buildingPath, floorIDs, index - 1, callback)
          });
        })
      } else {
        window.setTimeout(downloadFloorPlans, 200, host, port, buildingPath,
          floorIDs, index - 1, callback)
      }
    })
      .on('error', function (err) {
        window.setTimeout(downloadFloorPlans, 200, host, port, buildingPath,
          floorIDs, index - 1, callback)
        callback(err)
      })
    request.end()
  }
}

/**
 * Downloads floor plans for all buildings given by buildingIDs array, chaining HTTP requests by calling downloadFloorPlans. Iterates from "index" to 0
 *
 * @memberof   module:main
 *
 * @param      {string}    host         The controller hostname
 * @param      {number}    port         The port number
 * @param      {string}    projectName  The project ID
 * @param      {array}     buildingIDs  The array of building IDs
 * @param      {number}    index        The index of current building ID
 * @param      {Function}  callback     The callback once all buildings have been processed
 */
function downloadBuildingsData(host, port, projectName, buildingIDs, index,
  callback) {
  if (index < 0) {
    if (callback) {
      window.setTimeout(callback, 100)
    }
  } else {
    var buildingID = buildingIDs[index]
    var arrBuildingPath = ['/b/floorPlan', projectName, buildingID]
    var buildingPath = arrBuildingPath.join('/')
    var floorIDs = Object.keys(g_project.buildings[buildingID].floors)
    downloadFloorPlans(host, port, buildingPath, floorIDs, floorIDs.length - 1,
      function () {
        window.setTimeout(downloadBuildingsData, 200, host, port, projectName,
          buildingIDs, index - 1, callback)
      })
  }
}

/**
 * Uploads list of files. Appends basename to target path. Iterates from "index" to 0. Any validation should be done prior to calling this function
 *
 * @memberof   module:main
 *
 * @param      {string}    host          The hostname
 * @param      {number}    port          The port number
 * @param      {string}    basePath      The URL path for the upload
 * @param      {string}    directory     The directory housing the files
 * @param      {array}     files         Array of file names
 * @param      {number}    index         The index of current file
 * @param      {Function}  callback      The callback at the end of the file list
 * @return     {Function}  Calls itself with setTimeout to process the next item in the list
 */
function uploadFileList(host, port, basePath, directory, files, index, callback) {
  if (index < 0) {
    if (callback) {
      return window.setTimeout(callback, 100)
    }
  } else {
    var request
    var fstream
    var fileName = files[index]
    var fileExt = path.extname(fileName)
    var fileBase = path.basename(fileName, fileExt)
    var filePath = path.join(directory, fileName)
    var floorPath = basePath + '/' + fileBase + '/'
    var options = {
      protocol: 'http:',
      hostname: host,
      port: port,
      path: floorPath,
      method: 'PUT',
      headers: {
        'Content-Type': mime.lookup(fileName),
        'Content-Length': fs.statSync(filePath)
          .size
      }
    }
    request = http.request(options, function (response) {
      response.pipe(process.stdout)
    })
      .on('error', function (err) {
        callback && callback(err)
        return window.setTimeout(uploadFileList, 200, host, port, basePath,
          directory, files, index - 1, callback)
      })
    fstream = fs.createReadStream(filePath)
    fstream.pipe(request, {
      end: false
    })
    fstream.on('end', function () {
      request.end(function () {
        return window.setTimeout(uploadFileList, 200, host, port,
          basePath, directory, files, index - 1, callback)
      })
    })
  }
}

/**
 * Uploads floor plan files for buildings given by buildingIDs array, chaining requests by calling uploadFileList on the available files. Iterates from "index" to 0
 *
 * @memberof   module:main
 *
 * @param      {string}    host         The hostname
 * @param      {number}    port         The port number
 * @param      {string}    projectName  The project ID
 * @param      {array}     buildingIDs  Array of building IDs
 * @param      {number}    index        The index of current building ID
 * @param      {Function}  callback     The callback
 * @return     {Function}  calls itself for the next item in the list
 */
function uploadBuildingFloorPlans(host, port, projectName, buildingIDs, index,
  callback) {
  if (index < 0) {
    if (callback) {
      return window.setTimeout(callback, 100)
    }
  } else {
    var buildingID = buildingIDs[index]
    var buildingDir = path.join(FLOORPLAN_PATH, g_project._name, buildingID)
    fs.readdir(buildingDir, function (err, files) {
      if (err) {
        callback && callback(err)
        return window.setTimeout(uploadBuildingFloorPlans, 100, host, port,
          projectName, buildingIDs, index - 1, callback)
      }
      var arrBuildingPath = ['/b/floorPlan', projectName, buildingID]
      var buildingPath = arrBuildingPath.join('/')
      var floorFiles = files.filter(function (fileName) {
        var filePath = path.join(buildingDir, fileName)
        var fileExt = path.extname(fileName)
        var fileBase = path.basename(fileName, fileExt)
        return fs.statSync(filePath)
          .isFile() && g_project.buildings[buildingID].floors.hasOwnProperty(
            fileBase)
      })
      uploadFileList(host, port, buildingPath, buildingDir, floorFiles,
        floorFiles.length - 1,
        function () {
          return window.setTimeout(uploadBuildingFloorPlans, 200, host,
            port, projectName, buildingIDs, index - 1, callback)
        })
    })
  }
}

/**
 * Uploads a project to a controller
 *
 * @memberof   module:main
 *
 * @param      {string}    ipAddress        The SmartCore/controller IP address
 * @param      {string}    projectName      The project name
 * @param      {Function}  cb               The callback
 */
function uploadProject(ipAddress, projectName, cb) {
  var request
  var options
  var projectObj = {}
  var data
  var ipComponents = ipAddress.split(':')
  var host = ipComponents[0]
  var port = 80
  projectObj = g_project
  projectObj.lastModifiedDate = (new Date()).toISOString()
  data = JSON.stringify(projectObj)
  options = {
    protocol: 'http:',
    hostname: host,
    port: port,
    path: '/b/project/' + projectName,
    method: 'PUT',
    headers: {
      'Content-Type': 'text/plain',
      'Content-Length': data.length
    }
  }
  request = http.request(options, function (response) {
    var buildingIDs = Object.keys(g_project.buildings)
    uploadBuildingFloorPlans(host, port, projectName, buildingIDs,
      buildingIDs.length - 1,
      function () {
        cb && cb()
      })
  })
    .on('error', function (err) {
      cb && cb(err)
    })

  request.end(data, 'utf8')
}
function decodeBase64Image(dataString) {
  var matches = dataString.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/),
    response = {};

  if (matches.length !== 3) {
    return new Error('Invalid input string');
  }

  response.type = matches[1];
  response.data = new Buffer(matches[2], 'base64');

  return response;
}
/**
 * Downloads a project from the controller.
 *
 * @param      {string}    ipAddress            The controller ip address
 * @param      {string}    projectName          The project name
 * @param      {Function}  responseEndCallback  The response end callback
 * @param      {Function}  errorCallback        The error callback
 */
function downloadProject(ipAddress, projectName, cb) {
  var request
  var options
  var data = ''
  var projectObj = {}
  var ipComponents = ipAddress.split(':')
  var address = ipComponents[0]
  var port = 80
  options = {
    protocol: 'http:',
    hostname: address,
    port: port,
    path: '/b/project/' + projectName,
    method: 'GET'
  }
  request = http.request(options, function (reponse) {
    reponse.on('data', function (chunk) {
      data += chunk
    })
    reponse.on('end', function () {
      var projectObj = JSON.parse(data)
      var buildingIDs
      g_project = new Project(projectObj)
      g_state.projectID = projectName
      g_state.currentBuildingID = Object.keys(g_project.buildings)[0]
      g_state.currentFloorID = Object.keys(getCurrentBuilding()
        .floors)[0]
      g_state.currentControllerID = Object.keys(g_project.controllers)[
        0]
      buildingIDs = Object.keys(g_project.buildings)
      downloadBuildingsData(address, port, projectName, buildingIDs,
        buildingIDs.length - 1,
        function () {
          cb && cb()
        })
    })
  })
  request.on('error', function (err) {
    cb && cb(err)
  })
  request.end()
}

/**
 * Exports a project to file as JSON
 *
 * @memberof   module:main
 *
 * @param      {string}    file      The destination file path
 * @param      {Function}  callback  The callback
 */
function exportProject(file, callback) {

  var projectID = g_state.projectID
  var proj = {}
  g_project.lastModifiedDate = (new Date())
    .toISOString()
  g_state.projectID = projectID
  proj[projectID] = g_project
  loader.saveProject(proj, FLOORPLAN_PATH, file)
    .then(function () {
      callback && callback()
    })
    .catch(function (err) {
      callback && callback(err)
    })
}

/**
 * Saves application state to file.
 *
 * @memberof   module:main
 *
 * @param      {string}    stateFile  The destination file path
 * @param      {Function}  callback   The callback
 */
function saveState(stateFile, callback) {
  var file = stateFile !== undefined ? stateFile : DEFAULT_STATE_PATH +
    'ct-state' + pjson.version.replace(/\./g, '-') + '.json'
  if (g_state.projectFile === '') {
    g_state.projectFile = DEFAULT_STATE_PATH + 'ct-project' + pjson.version.replace(
      /\./g, '-') + '.json'
  }
  exportProject(g_state.projectFile, function () {
    fs.writeFile(file, JSON.stringify(g_state), 'utf8', function (errFile) {
      if (errFile) {
        return callback && callback(err)
      }
      callback && callback()
    })
  })
}

/**
 * Loads a state from file.
 *
 * @memberof   module:main
 *
 * @param      {string}  stateFile  The source file path
 */
function loadState(stateFile) {
  try {
    var content = fs.readFileSync(stateFile, 'utf8')
    util.mergeProps(content, g_state)
    loadProject(g_state.projectFile)
  } catch (err) {
  }
}

/**
 * Gets the current building object.
 *
 * @memberof   module:main
 *
 * @return     {object}  The current building.
 */
function getCurrentBuilding() {
  return g_project.buildings[g_state.currentBuildingID]
}

/**
 * Gets the current floor object.
 *
 * @memberof   module:main
 *
 * @return     {object}  The current floor.
 */
function getCurrentFloor() {
  return getCurrentBuilding()
    .floors[g_state.currentFloorID]
}

/**
 * Sets the current floor ID.
 *
 * @memberof   module:main
 *
 * @param      {string}  id      The identifier
 */
function setCurrentFloor(id) {
  g_state.currentFloorID = id
}

/**
 * Deletes a floor from the project
 *
 * @memberof   module:main
 *
 * @param      {string}    floorID     The floor id
 * @param      {string}    buildingID  The building id
 * @param      {Function}  callback    The callback
 */
function deleteFloor(floorID, buildingID, callback) {
  // var floorFilePath = path.join(FLOORPLAN_PATH, g_project._name, buildingID, floorID)
  var floorObj = g_project.buildings[buildingID].floors[floorID]
  g_project.deleteFloor(floorID, buildingID)
  if (floorObj.floorPlan !== '') {
    var fileName = floorObj.floorPlan
    var filePath = path.join(FLOORPLAN_PATH, g_project._name, buildingID,
      fileName)
    fs.remove(filePath, function (err) {
      if (err) {
        return callback && callback(err)
      }
      callback && callback()
    })
  } else{
     callback && callback()   // NOTE-KAMLESH : Issue DT-1 - Added else{callback && callback()}
  }
}

/**
 * Gets the current controller object.
 *
 * @memberof   module:main
 *
 * @return     {object}  The current controller.
 */
function getCurrentController() {
  return g_project.controllers[g_state.currentControllerID]
}



module.exports = {
  /**
   * Looks for existing state file or loads a new project.
   */
  init: init,
  /**
   * File path for floor plan files
   */
  floorPlanPath: FLOORPLAN_PATH,
  /**
   * Gets the current project object.
   */
  getProject: function () {
    return g_project
  },
  /**
   * Gets the app state object.
   */
  getState: function () {
    return g_state
  },
  /**
   * Loads app state from file.
   */
  loadState: loadState,
  /**
   * Saves app state to file.
   */
  saveState: saveState,
  /**
   * Initialises project: load project from file if the state object has a valid project file path, or create a new project
   */
  initProject: initProject,
  /**
   * Loads project from file
   */
  loadProject: loadProject,
  /**
   * Uploads project to the controller
   */
  uploadProject: uploadProject,
  /**
   * Downloads project from current controller
   */
  downloadProject: downloadProject,
  /**
   * Exports (save) project to file
   */
  exportProject: exportProject,
  /**
   * Imports floor plan from file
   */
  importFloorPlan: importFloorPlan,
  /**
   * Creates a new project
   */
  newProject: newProject,
  /**
   * Gets current building object
   */
  getCurrentBuilding: getCurrentBuilding,
  /**
   * Gets current controller object
   */
  getCurrentController: getCurrentController,
  /**
   * Gets current floor object
   */
  getCurrentFloor: getCurrentFloor,
  /**
   * Sets current floor ID
   */
  setCurrentFloor: setCurrentFloor,
  /**
   * Deletes floor with specified ID from project and removes associated floor plan file
   */
  deleteFloor: deleteFloor,
  /**
   * Increments an IP address by 1
   */
  incrementIP: util.incrementIP,
  /**
   * Forces a string into IPv4 format, including port number
   */
  ipify: util.ipify,
  /**
   * Gets start and end times from a trigger string
   */
  parseTrigger: util.parseTrigger,
  /**
   * Checks if file exists without throwing exceptions, returns simple bool instead
   */
  isFile: util.isFile
}
