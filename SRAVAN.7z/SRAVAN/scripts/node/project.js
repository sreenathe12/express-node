/*******************************************************************************
  Transcend Application Source File

  Company:
    Molex, LLC
  Summary:
    This file contains the source code for the Project data structure module.

  COPYRIGHT (C) 2016 Molex - All Rights Reserved

*******************************************************************************/
/**
 * The Project module
 * @module project
 *
 */

'use strict'


var util = require('./ct-util.js')
var Building = require('./building.js')
var Controller = require('./controller.js')
var spaces = require('./spaces.js')
var latestDelete

/**
 * Project default properties
 *
 * @type       {Object}
 */
var d_Project = {
    name: 'Project',
    client: '',
    contact: '',
    BIMFile: '',
    stage: 'alpha',
    baseIPFixtures: '192.168.1.1:9760',
    baseIPSensors: '192.168.1.100:9760',
    baseIPCurrent: '',
    demoSpace: {}
}

Object.freeze(d_Project)

/**
 * Permitted 'stage' values
 *
 * @type       {Array}
 */
var projectStages = ['alpha', 'beta', 'release']

/**
 * Creates a Project object
 *
 * @class      Project
 *
 * @memberof   module:project
 *
 * @param      {Object}  json    Properties for the new Project object. Defaults will be used for any properties missing, props with invalid names will be left out.
 */
var Project = function (json) {
    var newBld = ''
    var newCtr = ''
    util.addPropsOrDefaults(d_Project, this, json)
    if (this.lastModifiedDate === undefined) {
        this.lastModifiedDate = (new Date()).toISOString()
    }
    this.formatVersionnumber = '1.1.3'
    this.controllers = {}
    this.buildings = {}
    this.controllers = util.createMapFromProp('controllers', json, Controller)
    if (Object.keys(this.controllers).length === 0) {
        newCtr = this.addController()
    }
    if (json !== undefined && json.hasOwnProperty('buildings')) {
        this.buildings = util.createMapFromProp('buildings', json, Building)
        // Clear space active lists for dedupe
        Object.keys(this.controllers).forEach(function (cID) {
            var controller = this.controllers[cID]
            Object.keys(controller.spaces).forEach(function (sID) {
                var space = controller.spaces[sID]

                // NOTE Prakash: commented code and changes made for DT-90

                // space.activeFixtures.length = 0
                // space.activeSensors.length = 0
            })
        }, this)
        // Clear devices for dedupe
        Object.keys(this.buildings).forEach(function (bID) {
            var building = this.buildings[bID]
            Object.keys(building.floors).forEach(function (fID) {
                var floor = building.floors[fID]
                Object.keys(floor.fixtures).forEach(function (fixtureID) {
                    var fixture = floor.fixtures[fixtureID]
                    // NOTE Prakash: commented code and changes made for DT-90 and for Key replacement issues once we upload the project
                    // delete floor.fixtures[fixtureID]
                    // this.addFixture(fixture, bID, fID, fixture.controller)
                }, this)
                Object.keys(floor.sensors).forEach(function (sensorID) {
                    var sensor = floor.sensors[sensorID]
                    // NOTE Prakash: commented code for DT-90 and for Key replacement issues once we upload the project
                    // delete floor.sensors[sensorID]
                    // this.addSensor(sensor, bID, fID, sensor.controller)
                }, this)
            }, this)
        }, this)
    }
    if (Object.keys(this.buildings).length === 0) {
        newBld = this.addBuilding()
    }
    if (newBld && newCtr) {
        var defSpaceID = this.controllers[newCtr].getDefaultSpace()
        var areaID = this.buildings[newBld].addArea()
        var floorID = Object.keys(this.buildings[newBld].floors)[0]
        this.buildings[newBld].areas[areaID].addSpaceRef({
            controller: newCtr,
            space: defSpaceID
        })
        this.controllers[newCtr].spaces[defSpaceID].addMapRef({
            building: newBld,
            floor: floorID,
            locX: 0,
            locY: 0,
            width: this.buildings[newBld].floors[floorID]._gridW,
            height: this.buildings[newBld].floors[floorID]._gridH
        })
    }

    // Reset base IP
    if (json !== undefined && json.hasOwnProperty('baseIPCurrent')) {
        this._baseIPCurrent = json.baseIPCurrent
    }

    Object.seal(this)

    return this
}

/**
 * Adds a building to the project
 *
 * @memberof   module:project.Project
 *
 * @param      {Object}  building  Properties for the Building constructor
 *
 * @returns    {string} New building ID
 */
Project.prototype.addBuilding = function (building) {
    var id = util.generateID('building', '_', this.buildings, latestDelete)
    this.buildings[id] = new Building(building)
    if (!this.buildings[id]._name) {
        this.buildings[id]._name = 'Building ' + id.split('_').pop()
    }

    return id
}
/**
 * Deletes the building with the given ID from the project
 *
 * @memberof   module:project.Project
 *
 * @param      {string}   buildingID  The building id
 *
 * @return     {boolean}  true if project had a building with this ID, false otherwise
 */
Project.prototype.deleteBuilding = function (buildingID) {
    if (this.buildings.hasOwnProperty(buildingID)) {
        delete this.buildings[buildingID]
        for (var controllerID in this.controllers) {
            var controller = this.controllers[controllerID]
            for (var spaceID in controller.spaces) {
                var space = controller.spaces[spaceID]
                var mapRefs = space.getMapRefsByBuilding(buildingID)
                mapRefs.forEach(function (id) {
                    space.deleteMapRef(id)
                })
                if (Object.keys(space.maps).length < 1) {
                    this.deleteSpace(spaceID, controllerID)
                }
            }
        }
        return true
    }
    // TODO-MAK: conditional ternary operator and/or expressive return
    return false
}
/**
 * Adds a controller.
 *
 * @memberof   module:project.Project
 *
 * @param      {Object}  controller  Properties for the Controller constructor
 *
 * @returns    {string} New controller ID
 */
Project.prototype.addController = function (controller) {
    var id = util.generateID('controller', '_', this.controllers, latestDelete)
    this.controllers[id] = new Controller(controller)
    if (!this.controllers[id]._name) {
        this.controllers[id]._name = 'Controller' + id.split('_').pop()
    }
    return id
}
/**
 * Deletes a controller from the project
 *
 * @memberof   module:project.Project
 *
 * @param      {string}   controllerID  The controller id
 *
 * @return     {boolean}  true if project has a controller with this ID false otherwise
 */
Project.prototype.deleteController = function (controllerID) {
    if (this.controllers.hasOwnProperty(controllerID)) {
        for (var buildingID in this.buildings) {
            var areas = this.buildings[buildingID].areas
            for (var areaID in areas) {
                var area = areas[areaID]
                var spaceRefs = area.getSpaceRefsByController(controllerID)
                spaceRefs.forEach(function (id) {
                    area.deleteSpaceRef(id)
                })
            }
        }
        delete this.controllers[controllerID]
        return true
    }

    // TODO-MAK: conditional ternary operator and/or expressive return
    return false
}
/**
 * Adds a floor.
 *
 * @memberof   module:project.Project
 *
 * @param      {Object}  floor         Properties for the Floor contructor
 * @param      {string}  buildingID    ID of the building to which the floor is added
 * @param      {string}  controllerID  ID of controller that will handle this floor's spaces
 * @param      {string}  areaID        The area id for the new SpaceRef (optional)
 *
 * @return     {string}  New floor ID
 */
Project.prototype.addFloor = function (floor, buildingID, controllerID, areaID) {
    var areaID = areaID !== undefined ? areaID : Object.keys(this.buildings[buildingID].areas)[0]
    var defSpaceID = this.controllers[controllerID].getDefaultSpace()
    var floorID = this.buildings[buildingID].addFloor(floor)
    this.controllers[controllerID].spaces[defSpaceID].addMapRef({
        building: buildingID,
        floor: floorID,
        locX: 0,
        locY: 0,
        width: this.buildings[buildingID].floors[floorID]._gridW,
        height: this.buildings[buildingID].floors[floorID]._gridH
    })
    this.buildings[buildingID].areas[areaID].addSpaceRef({
        controller: controllerID,
        space: defSpaceID
    })
    return floorID
}
/**
 * Deletes a floor from the project
 *
 * @memberof   module:project.Project
 *
 * @param      {string}   id          Floor ID
 * @param      {string}   buildingID  ID of the building containing the floor
 *
 * @return     {boolean}  true if IDs are valid, false otherwise
 */
Project.prototype.deleteFloor = function (id, buildingID) {
    if (this.buildings.hasOwnProperty(buildingID) && this.buildings[buildingID].floors.hasOwnProperty(id)) {
        this.buildings[buildingID].deleteFloor(id)
        Object.keys(this.controllers).forEach(function (controllerID) {
            var spacesObj = this.controllers[controllerID].spaces
            Object.keys(spacesObj).forEach(function (spaceID) {
                var space = spacesObj[spaceID]
                var mapRefs = space.getMapRefsByIDs(buildingID, id)
                mapRefs.forEach(function (id) {
                    space.deleteMapRef(id)
                })
                if (Object.keys(space.maps).length < 1) {
                   // NOTE-KAMLESH: Issue DT-1 - Deletes space object
                   delete spacesObj[spaceID]
                }
            })
        }, this)
        return true
    }
    // TODO-MAK: conditional ternary operator and/or expressive return
    return false
}
/**
 * Adds a general space.
 *
 * @memberof   module:project.Project
 *
 * @param      {Object}  space         Properties for the space contructor
 * @param      {string}  buildingID    ID of building associated with this space
 * @param      {string}  controllerID  ID controller to which space is added
 * @param      {string}  areaID        Area ID for new SpaceRef object (optional)
 *
 * @returns    {string}  New space ID
 */
Project.prototype.addGeneralSpace = function (space, buildingID, controllerID, areaID) {
    var areaID = areaID !== undefined ? areaID : Object.keys(this.buildings[buildingID].areas)[0]
    var spaceID = this.controllers[controllerID].addGeneralSpace(space)
    this.buildings[buildingID].areas[areaID].addSpaceRef({
        controller: controllerID,
        space: spaceID
    })
    return spaceID
}
/**
 * Adds an beacon space.
 *
 * @memberof   module:project.Project
 *
 * @param      {Object}  space         Properties for the space constructor
 * @param      {string}  buildingID    ID of building associated with this space
 * @param      {string}  controllerID  ID of controller to which new space will be added
 * @param      {string}  areaID        Area ID for new SpaceRef object (optional)
 *
 * @returns    {string} New space ID
 */
Project.prototype.addBeaconSpace = function (space, buildingID, controllerID, areaID) {
    var areaID = areaID !== undefined ? areaID : Object.keys(this.buildings[buildingID].areas)[0]
    var spaceID = this.controllers[controllerID].addBeaconSpace(space)
    this.buildings[buildingID].areas[areaID].addSpaceRef({
        controller: controllerID,
        space: spaceID
    })
    return spaceID
}

/**
 * Adds an user space.
 *
 * @memberof   module:project.Project
 *
 * @param      {Object}  space         Properties for the space constructor
 * @param      {string}  buildingID    ID of building associated with this space
 * @param      {string}  controllerID  ID of controller to which new space will be added
 * @param      {string}  areaID        Area ID for new SpaceRef object (optional)
 *
 * @returns    {string} New space ID
 */
Project.prototype.addUserSpace = function (space, buildingID, controllerID, areaID) {
    var areaID = areaID !== undefined ? areaID : Object.keys(this.buildings[buildingID].areas)[0]
    var spaceID = this.controllers[controllerID].addUserSpace(space)
    this.buildings[buildingID].areas[areaID].addSpaceRef({
        controller: controllerID,
        space: spaceID
    })
    return spaceID
}
/**
 * Deletes a space from the project
 *
 * @memberof   module:project.Project
 *
 * @param      {string}   spaceID       The space id
 * @param      {string}   controllerID  The controller id
 *
 * @return     {boolean}  true if IDs are valid, false otherwise
 *
 */
Project.prototype.deleteSpace = function (spaceID, controllerID) {
    if (this.controllers.hasOwnProperty(controllerID) && this.controllers[controllerID].spaces.hasOwnProperty(spaceID)) {
        var buildings = this.buildings
        var controller = this.controllers[controllerID]
        var spaceObj = controller.spaces[spaceID]
        Object.keys(buildings).forEach(function (buildingID) {
            var areas = buildings[buildingID].areas
            Object.keys(areas).forEach(function (areaID) {
                var area = areas[areaID]
                var spaceRefs = areas[areaID].getSpaceRefsByIDs(spaceID, controllerID)
                spaceRefs.forEach(function (spaceID) {
                    area.deleteSpaceRef(spaceID)
                })
            })
        }, this)
        Object.keys(spaceObj.maps).forEach(function (mapID) {
            var mapRef = spaceObj.maps[mapID]
            var buildingID = mapRef.building
            var floorID = mapRef.floor
            var floorObj = this.buildings[buildingID].floors[floorID]
            var fixtureIDs = floorObj.getFixturesInMap(mapRef, controllerID)
            var sensorIDs = floorObj.getSensorsInMap(mapRef, controllerID)
            spaceObj.deleteMapRef(mapID)
            fixtureIDs.forEach(function (fixtureID) {
                this.allocateFixture(fixtureID, buildingID, floorID)
            }, this)
            sensorIDs.forEach(function (sensorID) {
                this.allocateSensor(sensorID, buildingID, floorID)
            }, this)
        }, this)
        this.controllers[controllerID].deleteSpace(spaceID)
        return true
    }
    // TODO-MAK: conditional ternary operator and/or expressive return
    return false
}
/**
 * Adds a fixture.
 *
 * @memberof   module:project.Project
 *
 * @param      {Object}  fixture       Properties for the Fixture contructor
 * @param      {string}  buildingID    The building id
 * @param      {string}  floorID       The floor id
 * @param      {string}  controllerID  The controller id
 *
 * @return     {string} New fixture ID
 */
Project.prototype.addFixture = function (fixture, buildingID, floorID, controllerID) {
    var buildingNum = parseInt(buildingID.split('_').pop(), 10)
    var floorNum = parseInt(floorID.split('_').pop(), 10)
    var buildingPref = Number.isSafeInteger(buildingNum) ? buildingNum : buildingID
    var floorPref = Number.isSafeInteger(floorNum) ? floorNum : floorID
    var fixID = this.buildings[buildingID].floors[floorID].addFixture(fixture, 'fixture-' + buildingPref + '-' + floorPref)
    var fixtureObj = this.buildings[buildingID].floors[floorID].fixtures[fixID]
    // NOTE: prakash - for incremental formate in id , we need to uncomment below 2 lines
    // var fDataId = fixID.split("-")
    // fixtureObj.id = fixID
    var spaceID
    fixtureObj._controller = controllerID

    // NOTE-MAK: removing id property. being replaced by coapIdentifier
    // fixtureObj._id = fixID
    spaceID = this.allocateFixture(fixID, buildingID, floorID)

    return fixID
}
/**
 * Deletes a fixture from the project
 *
 * @memberof   module:project.Project
 *
 * @param      {string}  fixtureID   The fixture id
 * @param      {string}  buildingID  The building id
 * @param      {string}  floorID     The floor id
 *
 * @return     {boolean}  true if all IDs are valid, false otherwise
 */
Project.prototype.deleteFixture = function (fixtureID, buildingID, floorID) {
    var floor = this.buildings[buildingID].floors[floorID]
    if (floor.fixtures.hasOwnProperty(fixtureID)) {
        var fixture = floor.fixtures[fixtureID]
        var controllerID = fixture._controller
        var spaceID = fixture._space
        if (this.controllers.hasOwnProperty(controllerID) &&
            this.controllers[controllerID].spaces.hasOwnProperty(spaceID)) {
            var activeFixtures = this.controllers[controllerID].spaces[spaceID].activeFixtures
            var index = activeFixtures.indexOf(fixtureID)
            if (index >= 0) {
                activeFixtures.splice(index, 1)
            }
        }
        return floor.deleteFixture(fixtureID)
    }
    // TODO-MAK: conditional ternary operator and/or expressive return
    return false
}

/**
 * Search for a fixture at given grid position
 *
 * @memberof   module:project.Project
 *
 * @param      {number}  x             Grid x-coord
 * @param      {number}  y             Grid y-coord
 * @param      {string}  buildingID    The building id
 * @param      {string}  floorID       The floor id
 * @param      {string}  controllerID  The controller id
 *
 * @return     {string} ID of fixture if one is found, empty string otherwise
 */
Project.prototype.findFixture = function (x, y, buildingID, floorID, controllerID) {
    var floor = this.buildings[buildingID].floors[floorID]
    var fixtureIDs = floor.getFixturesByController(controllerID)
    var result = ''
    fixtureIDs.some(function (id) {
        var fixture = floor.fixtures[id]
        if (fixture._x === x && fixture._y === y) {
            result = id
            return true
        }
    })
    return result
}
/**
 * Adds a sensor.
 *
 * @memberof   module:project.Project
 *
 * @param      {Object}  sensor        Properties for the Sensor constructor
 * @param      {string}  buildingID    The building id
 * @param      {string}  floorID       The floor id
 * @param      {string}  controllerID  The controller id
 *
 * @return     {string} New sensor ID
 */
Project.prototype.addSensor = function (sensor, buildingID, floorID, controllerID) {
    var buildingNum = parseInt(buildingID.split('_').pop(), 10)
    var floorNum = parseInt(floorID.split('_').pop(), 10)
    var buildingPref = Number.isSafeInteger(buildingNum) ? buildingNum : buildingID
    var floorPref = Number.isSafeInteger(floorNum) ? floorNum : floorID
    var sensorID = this.buildings[buildingID].floors[floorID].addSensor(sensor, 'sensor-' + buildingPref + '-' + floorPref)
    var sensorObj = this.buildings[buildingID].floors[floorID].sensors[sensorID]
    // NOTE: prakash - for incremental formate in id , we need to uncomment below 2 lines
    // var sDataId = sensorID.split("-")
    // sensorObj.id = sensorID
    // console.log(sensorObj.id)
    var spaceID
    sensorObj._controller = controllerID

    // NOTE-MAK: removing id property. being replaced by coapIdentifier
    //sensorObj._id = sensorID
    spaceID = this.allocateSensor(sensorID, buildingID, floorID)
    return sensorID
}
/**
 * Deletes a sensor from the project
 *
 * @memberof   module:project.Project
 *
 * @param      {string}  sensorID    The sensor id
 * @param      {string}  buildingID  The building id
 * @param      {string}  floorID     The floor id
 *
 * @return     {boolean}  true if all IDs are valid, false otherwise
 */
Project.prototype.deleteSensor = function (sensorID, buildingID, floorID) {
    var floor = this.buildings[buildingID].floors[floorID]
    if (floor.sensors.hasOwnProperty(sensorID)) {
        var fixture = floor.sensors[sensorID]
        var controllerID = fixture._controller
        var spaceID = fixture._space
        if (this.controllers.hasOwnProperty(controllerID) &&
            this.controllers[controllerID].spaces.hasOwnProperty(spaceID)) {
            var activeSensors = this.controllers[controllerID].spaces[spaceID].activeSensors
            var index = activeSensors.indexOf(sensorID)
            if (index >= 0) {
                activeSensors.splice(index, 1)
            }
        }
        return floor.deleteSensor(sensorID)
    }
    // TODO-MAK: conditional ternary operator and/or expressive return
    return false
}
/**
 * Searches for a sensor at the given grid position
 *
 * @memberof   module:project.Project
 *
 * @param      {number}  x             Grid x-coord
 * @param      {number}  y             Grid y-coord
 * @param      {string}  buildingID    The building id
 * @param      {string}  floorID       The floor id
 * @param      {string}  controllerID  The controller id
 *
 * @return     {string} Sensor ID if one is present at this grid position, empty string otherwise
 */
Project.prototype.findSensor = function (x, y, buildingID, floorID, controllerID) {
    var floor = this.buildings[buildingID].floors[floorID]
    var sensorIDs = floor.getSensorsByController(controllerID)
    var result = ''
    sensorIDs.some(function (id) {
        var sensor = floor.sensors[id]
        if (sensor._x === x && sensor._y === y) {
            result = id
            return true
        }
    })
    return result
}
/**
 * Searches for a space of a specific type at the given grid position
 *
 * @memberof   module:project.Project
 *
 * @param      {string}  type          The Space type to look for
 * @param      {number}  x             Grid x-coord
 * @param      {number}  y             Grid y-coord
 * @param      {string}  buildingID    The building id
 * @param      {string}  floorID       The floor id
 * @param      {string}  controllerID  The controller id
 *
 * @return     {Object} Object with the properties 'spaceID' and 'mapID' referering to the Space and its MapRef at this postion if found, empty strings otherwise.
 *
 */
Project.prototype.findSpaceOfType = function (type, x, y, buildingID, floorID, controllerID) {
    var result = { spaceID: '', mapID: '' }
    var controller = this.controllers[controllerID]
    controller.getSpacesOfType(type).some(function (spaceID) {
        var space = controller.spaces[spaceID]
        return space.getMapRefsByIDs(buildingID, floorID).some(function (mapID) {
            if (space.maps[mapID].contains(x, y)) {
                result.spaceID = spaceID
                result.mapID = mapID
                return true
            }
        })
    })
    return result
}
/**
 * Searches for a general layer space at the given grid position
 *
 * @memberof   module:project.Project
 *
 * @param      {number}  x             Grid x-coord
 * @param      {number}  y             Grid y-coord
 * @param      {string}  buildingID    The building id
 * @param      {string}  floorID       The floor id
 * @param      {string}  controllerID  The controller id
 *
 * @return     {Object} Object with the properties 'spaceID' and 'mapID' referring to the Space and its MapRef at this position if found, empty strings otherwise
 */
Project.prototype.findGeneralSpace = function (x, y, buildingID, floorID, controllerID) {
    var result = { spaceID: '', mapID: '' }
    var self = this
    spaces.typesByPriority.slice(8, 16).some(function (type) {
        var ref = self.findSpaceOfType(type, x, y, buildingID, floorID, controllerID)
        if (ref.spaceID !== '' && ref.mapID !== '') {
            result = ref
            return true
        }
    })
    return result
}
/**
 * Searches for a beacon layer space at the given grid position
 *
 * @memberof   module:project.Project
 *
 * @param      {number}  x             Grid x-coord
 * @param      {number}  y             Grid y-coord
 * @param      {string}  buildingID    The building id
 * @param      {string}  floorID       The floor id
 * @param      {string}  controllerID  The controller id
 *
 * @return     {Object} Object with the properties 'spaceID' and 'mapID' referring to the Space and its MapRef at this position if found, empty strings otherwise
 */
Project.prototype.findBeaconSpace = function (x, y, buildingID, floorID, controllerID) {
    var result = { spaceID: '', mapID: '' }
    var self = this
    spaces.typesByPriority.slice(16, -1).some(function (type) {
        var ref = self.findSpaceOfType(type, x, y, buildingID, floorID, controllerID)
        if (ref.spaceID !== '' && ref.mapID !== '') {
            result = ref
            return true
        }
    })
    return result
}


/**
 * Searches for a user layer space at the given grid position
 *
 * @memberof   module:project.Project
 *
 * @param      {number}  x             Grid x-coord
 * @param      {number}  y             Grid y-coord
 * @param      {string}  buildingID    The building id
 * @param      {string}  floorID       The floor id
 * @param      {string}  controllerID  The controller id
 *
 * @return     {Object} Object with the properties 'spaceID' and 'mapID' referring to the Space and its MapRef at this position if found, empty strings otherwise
 */
Project.prototype.findUserSpace = function (x, y, buildingID, floorID, controllerID) {
    var result = { spaceID: '', mapID: '' }
    var self = this
    spaces.typesByPriority.slice(0, 8).some(function (type) {
        var ref = self.findSpaceOfType(type, x, y, buildingID, floorID, controllerID)
        if (ref.spaceID !== '' && ref.mapID !== '') {
            result = ref
            return true
        }
    })
    return result
}
/**
 * Allocates a device to a space: finds which Space a device belongs to, calculates its amBXLocation and adjusts the Space's list of active devices
 *
 * @memberof   module:project.Project
 *
 * @param      {string}  deviceID       The device id
 * @param      {string}  buildingID     The building id
 * @param      {string}  floorID        The floor id
 * @param      {string}  devicesKey     The property name in the Floor object for looking up the device ID - can be 'fixtures' or 'sensors'
 * @param      {string}  activeListKey  The property name in the Space object for active devices - can be 'activeFixtures' or 'activeSensors'
 *
 * @return     {string}  Space ID now associated with the device
 */
Project.prototype.allocateDevice = function (deviceID, buildingID, floorID, devicesKey, activeListKey) {
    var self = this
    var floor = this.buildings[buildingID].floors[floorID]
    var device = floor[devicesKey][deviceID]
    var controller = this.controllers[device._controller]
    var currentSpace
    if (device._space === '' || !controller.spaces.hasOwnProperty(device._space)) {
        device._space = controller.getDefaultSpace()
    }
    currentSpace = controller.spaces[device._space]
    spaces.typesByPriority.some(function (type) {
        var testSpaceRes = self.findSpaceOfType(type, device._x, device._y, buildingID, floorID, device._controller)
        var testSpaceID = testSpaceRes.spaceID
        if (testSpaceID === device._space) {
            var space = controller.spaces[testSpaceID]
            var activeList = space[activeListKey]
            var mapObj = space.maps[testSpaceRes.mapID]
            var amBXLoc = mapObj.getAMBXLocation(device._x, device._y)
            if (activeList.indexOf(deviceID) < 0) {
                activeList.push(deviceID)
            }
            if (amBXLoc !== '') {
                device._amBXLocation = amBXLoc
            }
            return true
        }
        //NOTE: Prakash - disabled  sensors creation in beacon
        var isInf = testSpaceID.split("_")
        if (isInf[0] === 'inf' && devicesKey === 'sensors') {
            testSpaceID = 'BuildingDefault'
            var space = controller.spaces[testSpaceID]
            var activeList = space[activeListKey]
            var mapObj = space.maps[testSpaceRes.mapID]
            var amBXLoc = mapObj.getAMBXLocation(device._x, device._y)
            if (activeList.indexOf(deviceID) < 0) {
                activeList.push(deviceID)
            }
            if (amBXLoc !== '') {
                device._amBXLocation = amBXLoc
            }
            return true
        }
        if (testSpaceID !== '') {
            var testSpace = controller.spaces[testSpaceID]
            var activeList = currentSpace[activeListKey]
            var deviceIndex = activeList.indexOf(deviceID)
            var mapObj = controller.spaces[testSpaceID].maps[testSpaceRes.mapID]
            var amBXLoc = mapObj.getAMBXLocation(device._x, device._y)
            if (deviceIndex >= 0) {
                activeList.splice(deviceIndex, 1)
            }
            activeList = testSpace[activeListKey]
            deviceIndex = activeList.indexOf(deviceID)
            if (deviceIndex < 0) {
                activeList.push(deviceID)
            }
            device._space = testSpaceID
            if (amBXLoc !== '') {
                device._amBXLocation = amBXLoc
            }
            return true
        }
        return false
    })
    return device._space
}
/**
 * Allocates a fixture to a space
 *
 * @memberof   module:project.Project
 *
 * @param      {string}  fixtureID   The fixture id
 * @param      {string}  buildingID  The building id
 * @param      {string}  floorID     The floor id
 *
 * @return     {string}  The fixture's new space ID
 */
Project.prototype.allocateFixture = function (fixtureID, buildingID, floorID) {
    return this.allocateDevice(fixtureID, buildingID, floorID, 'fixtures', 'activeFixtures')
}
/**
 * Allocates a sensor to a space
 *
 * @memberof   module:project.Project
 *
 * @param      {string}  fixtureID   The fixture id
 * @param      {string}  buildingID  The building id
 * @param      {string}  floorID     The floor id
 *
 * @return     {string}  The fixture's new space ID
 */
Project.prototype.allocateSensor = function (sensorID, buildingID, floorID) {
    return this.allocateDevice(sensorID, buildingID, floorID, 'sensors', 'activeSensors')
}
/**
 * Finds devices inside the given MapRef of the given Space and allocates them resolving conflicts where appropriate
 *
 * @memberof   module:project.Project
 *
 * @param      {string}  spaceID       The space id
 * @param      {string}  mapID         The map id
 * @param      {string}  buildingID    The building id
 * @param      {string}  floorID       The floor id
 * @param      {string}  controllerID  The controller id
 */
Project.prototype.allocateDevicesInSpace = function (spaceID, mapID, buildingID, floorID, controllerID) {
    var controller = this.controllers[controllerID]
    var space = controller.spaces[spaceID]
    var map = space.maps[mapID]
    var floor = this.buildings[buildingID].floors[floorID]
    var devices = floor.fixtures
    var activeDeviceListProp = 'activeFixtures'
    function reallocate(deviceID) {
        var device = devices[deviceID]
        var oldSpace = controller.spaces[device._space]
        if(device.hasOwnProperty("pollingRate") && space.layer === ('Information' || 'Beacon')){
          space = oldSpace
        }
        var amBXLoc = map.getAMBXLocation(device._x, device._y)
        if (spaceID === device._space) {
            if (amBXLoc !== '') {
                device._amBXLocation = amBXLoc
            }
        } else if (spaces.typesByPriority.indexOf(space._type) < spaces.typesByPriority.indexOf(oldSpace._type)) {
            var activeListOld = oldSpace[activeDeviceListProp]
            var activeListNew = space[activeDeviceListProp]
            activeListOld.splice(activeListOld.indexOf(deviceID), 1)
            activeListNew.push(deviceID)
            device._space = spaceID
            if (amBXLoc !== '') {
                device._amBXLocation = amBXLoc
            }
        }
    }
    floor.getFixturesInMap(map, controllerID).forEach(reallocate)
    devices = floor.sensors
    activeDeviceListProp = 'activeSensors'
    floor.getSensorsInMap(map, controllerID).forEach(reallocate)
}

/**
 * Allocates all devices on specified floor
 *
 * @memberof   module:project.Project
 *
 * @param      {string}  buildingID  The building id
 * @param      {string}  floorID     The floor id
 */
Project.prototype.allocateDevicesOnFloor = function (buildingID, floorID) {
    var building = this.buildings[buildingID]
    var floor = building.floors[floorID]
    Object.keys(floor.fixtures).forEach(function (fixtureID) {
        this.allocateDevice(fixtureID, buildingID, floorID, 'fixtures', 'activeFixtures')
    }, this)
    Object.keys(floor.sensors).forEach(function (sensorID) {
        this.allocateDevice(sensorID, buildingID, floorID, 'sensors', 'activeSensors')
    }, this)
}

util.definePseudos(Project.prototype, ['formatVersionnumber', 'name', 'lastModifiedDate', 'client', 'contact', 'BIMFile', 'baseIPFixtures', 'baseIPSensors', 'baseIPCurrent'])
util.defineRestrictedPseudo(Project.prototype, 'stage', projectStages)

Object.freeze(Project.prototype)
/**
 * Project class constructor
 */
module.exports = Project
