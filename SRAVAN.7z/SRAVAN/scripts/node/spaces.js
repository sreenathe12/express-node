/*******************************************************************************
  Transcend Application Source File

  Company:
    Molex, LLC
  Summary:
    This file contains the source code for the Spaces data structure module.

  COPYRIGHT (C) 2016 Molex - All Rights Reserved

*******************************************************************************/
/**
 * The Spaces module
 * @module spaces
 *
 */
'use strict'
var util = require('./ct-util.js')
var devices = require('./devices.js')
var amBXLocs = devices.amBXLocations
var amBXLocsOrd = devices.amBXLocationsOriented

// NOTE-MAK: adding the concept of a space having a schedule
var schedule = require('../scheduler/schedule.js')
/**
 * MapRef default properties
 *
 * @type       {Object}
 */
var d_MapRef = {
    building: '',
    floor: '',
    locX: -1,
    locY: -1,
    width: 0,
    height: 0,
    orientation: 0
}
Object.freeze(d_MapRef)

var MapRef =
    /**
     * Creates a MapRef object, which handles floor and building reference and geometry (defines rectangle on the grid) for Space objects
     *
     * @class      MapRef map
     *
     * @param      {Object}  json    Options for contructor. Valid property names are "building", "floor", "locX", "locY", "width", "height", "orientation"

     * @returns    {Object} New MapRef object
     */
    exports.MapRef = function(json) {
        util.addPropsOrDefaults(d_MapRef, this, json)
    }

/**
 * Creates a 2D point object
 *
 * @memberof   module:spaces
 *
 * @param      {number}  valX    The x value
 * @param      {number}  valY    The y value
 *
 * @return     {Object}  2D point object with properties 'x' and 'y'
 */
function point(valX, valY) {
    return { x: valX, y: valY }
}

/**
 * Gets the grid coord of the vertex specified by the index: 0 - top left, 1 - top right, 2 - bottom right, 3 - bottom left.
 *
 * @memberof   module:spaces.MapRef
 *
 * @param      {number}  index   The index
 *
 * @return     {Object}  The vertex position as a point object: {x: <number>, y: <number>}.
 */
MapRef.prototype.getVertex = function(index) {
    if (Number.isSafeInteger(index)) {
        var idx = index % 4
        switch (idx) {
            case 0:
                return point(this._x, this._y)
                break
            case 1:
                return point(this._x + this._width - 1, this._y)
                break
            case 2:
                return point(this._x + this._width - 1, this._y + this._height - 1)
                break
            case 3:
                return point(this._x, this._y + this._height - 1)
        }
    }
    return point(-1, -1)
}

/**
 * Gets the vertices of the MapRef as an array of point objects.
 *
 * @memberof   module:spaces.MapRef
 *
 * @return     {Object[]} Array of vertices as point objects ({x: <number>, y: <number>}) given clockwise starting with top-left
 *
 */
MapRef.prototype.getVertices = function() {
    var index = 0
    var arr = []
    while (index < 4) {
        arr.push(this.getVertex(index))
        index += 1
    }
    return arr
}

/**
 * Sets the MapRef rectangle to a 'drag box' between the two points defined by the params
 *
 * @memberof   module:spaces.MapRef
 *
 * @param      {number}  x1      The x-coord of the first point
 * @param      {number}  y1      The y-coord of the first point
 * @param      {number}  x2      The x-coord of the second point
 * @param      {number}  y2      The y-coord of the second point
 */
MapRef.prototype.resolve = function(x1, y1, x2, y2) {
    var w = Math.abs(x2 - x1)
    var h = Math.abs(y2 - y1)
    if (w >= 3 && h >= 3) {
        this._x = Math.min(x1, x2)
        this._y = Math.min(y1, y2)
        this._width = w
        this._height = h
    }
}

/**
 * Checks if the MapRef rectangle contains the point specified
 *
 * @memberof   module:spaces.MapRef
 *
 * @param      {number}   x       X-coord
 * @param      {number}   y       Y-coord
 *
 * @return     {boolean}  true if point lies inside the MapRef, false otherwise
 */
MapRef.prototype.contains = function(x, y) {
    return (x >= this._x) &&
        (y >= this._y) &&
        (x < (this._x + this._width)) &&
        (y < (this._y + this._height))
}

/**
 * Gets the ambx location of a point inside this map
 *
 * @param      {number}  x       grid x-coord
 * @param      {number}  y       grid y-coord
 *
 * @return     {string}  The ambx location if map contains point, empty string otherwise
 */
MapRef.prototype.getAMBXLocation = function(x, y) {
    var relativeX
    var relativeY
    var locW
    var locH
    var iRow
    var iCol
    var iLocInitial
    var locInitial
    var iLocAdjusted
    var locResult
    if (!(this.contains(x, y))) {
        return ''
    }
    relativeX = x - this._x
    relativeY = y - this._y
    locH = this._height / 3
    locW = this._width / 3
    iRow = Math.floor(relativeX / locW)
    iCol = Math.floor(relativeY / locH)
    locInitial = amBXLocs[3 * iCol + iRow]
    if (locInitial === 'C') {
        locResult = locInitial
    } else {
        iLocInitial = amBXLocsOrd.indexOf(locInitial)
        iLocAdjusted = (iLocInitial - this._orientation + amBXLocsOrd.length) % amBXLocsOrd.length
        locResult = amBXLocsOrd[iLocAdjusted]
    }
    return locResult
}

Object.defineProperty(MapRef.prototype, '_orientation', {
    get: function() {
        return this.orientation
    },
    set: function(val) {
        if (Number.isSafeInteger(val)) {
            this.orientation = parseInt(val, 10) % 8
        }
    }
})

util.definePseudos(MapRef.prototype, ['building', 'floor'])

util.defineNamedPseudoInts(MapRef.prototype, {
    locX: '_x',
    locY: '_y',
    width: '_width',
    height: '_height'
})

Object.freeze(MapRef.prototype)

/**
 * Default values for the sensorBrain property of a Space object
 *
 * @type       {Object}
 */
var boilerplate_sensorBrain = {
    "bioAdaptivityDef": 50,
    "immersionDef": 50,
    "updateSensitivity": 1,
    "presTimeout": 300000,
    "presDelta": 5,
    "presRate": 60000,
    "DHTargetLux": 500,
    "DHRate": 1,
    "DHDiffUp": 100,
    "DHDeltaUp": 0.4,
    "DHDiffDown": 100,
    "DHDeltaDown": 0.4,
    "swatchs": {
        "default": "Default",
        "palettes": {
            "alert": {
                "ww": [255, 255, 200],
                "cw": [0, 255, 255],
                "pw": [150, 255, 255]
            },
            "focused": {
                "ww": [255, 255, 170],
                "cw": [40, 255, 255],
                "pw": [200, 255, 255]
            },
            "vigilant": {
                "ww": [255, 255, 140],
                "cw": [80, 255, 255],
                "pw": [220, 255, 255]
            },
            "default": {
                "ww": [255, 255, 128],
                "cw": [128, 255, 255],
                "pw": [255, 255, 255]
            },
            "calm": {
                "ww": [255, 255, 80],
                "cw": [140, 255, 255],
                "pw": [255, 255, 220]
            },
            "relaxed": {
                "ww": [255, 255, 40],
                "cw": [170, 255, 255],
                "pw": [255, 255, 200]
            },
            "cozy": {
                "ww": [255, 255, 0],
                "cw": [200, 255, 255],
                "pw": [255, 255, 150]
            }
        }
    },
    "basePaletteUpdateEvery": 5000,
    "minimumComponentChangeForUpdate": 5,
    "DHMaxAllowedDeviation": 0,
    "bioadaptivityStepSize": 0.5,
    "immersionStepSize": 0.5,
    //Note Kamlesh: Issue Dt-52 & DT-64 - Add behaviours object and comment "occupancyEffects"
    "behaviours" : {
    "onIdle" : 'default',
    "afterIdleTimeout" : 'resetBrightness'

    },
    // WARN-MAK: adding temporary state properties for timeout, fadeout, and manual-on buttons
    // "occupancyEffects": {
    //     "timeout": false,
    //     "fadeout": false,
    //     "manual": false
    // }
    // WARN-MAK: adding temporary state properties for timeout, fadeout, and manual-on buttons
    // "occupancyEffects": {
    //     "timeout": false,
    //     "fadeout": false,
    //     "manual": false
    // }
}
Object.freeze(boilerplate_sensorBrain)

/**
 * Default activation values for each Space type
 *
 * @type       {Object}
 */
var d_SpaceActivations = {
    'Default': {
        trigger: 'bt#06:00 20:00',
        // presDelta: 0,
        presTimeout: 600000,
        presRate: 30000,
        behaviour: 'default'
    },
    'RR': {
        trigger: 'bt#08:00 18:00',
        // presDelta: 0,
        presTimeout: 300000,
        presRate: 15000,
        behaviour: 'default'
    },
    'Stairs': {
        trigger: 'bt#06:00 20:00',
        // presDelta: 0,
        presTimeout: 600000,
        presRate: 30000,
        behaviour: 'stayOn'
    },
    'Lobby': {
        trigger: 'bt#06:00 20:00',
        // presDelta: 0,
        presTimeout: 12000,
        presRate: 30000,
        behaviour: 'default'
    },
    'Elevator': {
        trigger: 'bt#06:00 20:00',
        // presDelta: 0,
        presTimeout: 600000,
        presRate: 30000,
        behaviour: 'stayOn'
    },
    'Exit': {
        trigger: 'bt#06:00 20:00',
        // presDelta: 0,
        presTimeout: 600000,
        presRate: 30000,
        behaviour: 'stayOn'
    },
    'Cafeteria': {
        trigger: 'bt#:08:00 18:00',
        // presDelta: 0,
        presTimeout: 300000,
        presRate: 15000,
        behaviour: 'default'
    },
    'Aisle': {
        trigger: 'bt#06:00 20:00',
        // presDelta: 0,
        presTimeout: 12000,
        presRate: 60000,
        behaviour: 'default'
    },
    'Feature': {
        trigger: 'bt#08:00 18:00',
        // presDelta: 0,
        presTimeout: 600000,
        presRate: 30000,
        behaviour: 'stayOn'
    },
    'Desk': {
        trigger: 'bt#06:00 20:00',
        // presDelta: 0,
        presTimeout: 600000,
        presRate: 60000,
        behaviour: 'default'
    },
    'Meeting': {
        trigger: 'bt#08:00 18:00',
        // presDelta: 0,
        presTimeout: 600000,
        presRate: 45000,
        behaviour: 'default'
    },
    'Breakout': {
        trigger: 'bt#08:00 18:00',
        // presDelta: 0,
        presTimeout: 600000,
        presRate: 30000,
        behaviour: 'default'
    },
    'Lab': {
        trigger: 'bt#06:00 20:00',
        // presDelta: 0,
        presTimeout: 600000,
        presRate: 60000,
        behaviour: 'default'
    }
}
Object.freeze(d_SpaceActivations)

/**
 * Valid light scene names
 *
 * @type       {Array}
 */
var spaceLightScenes = ['Off', 'workingHours', 'outOfHours', 'creative', 'meeting', 'personal', 'orbit', 'speaker', 'video', 'daylight', 'rr', 'stairs', 'aisle', 'exit', 'elevator', 'lobby', 'cafeteria', 'feature', 'oneColour']
    /**
     * Valid mood names
     *
     * @type       {Array}
     */
var spaceMoods = ['alert', 'focused', 'vigilant', 'default', 'calm', 'relaxed', 'cozy', 'fire', 'ok', 'blue','default']
    /**
     * Valid behaviour names
     *
     * @type       {Array}
     */
var spaceBehaviours = ['default', 'off', 'stayOn', 'buildingLayer']

/**
 * Valid DHDeltaUp and DHDeltaDown values
 *
 * @type       {Array}
 */
var dhDeltas = [0.4, 0.7, 1.0]

/**
 * Space object defaults
 *
 * @type       {Object}
 */
var d_Space = {
    name: 'default',
    amBXSpace: 0,
    layer: 'Building',
    type: 'Default',
    defaultLightScene: 'workingHours',
    defaultMood: 'calm',
    defaultBrightness: 100,
    availableLightScenes: {
        'workingHours': 'calm',
        'outOfHours': 'calm'
    }
}
Object.freeze(d_Space)

/**
 * Creates a space object according to Project Structure Spec, using default values for required properties if none given
 *
 * @memberof   module:spaces
 *
 * @class
 * @param      {Object}  json    optional object. Defaults values will be used for missing properties.
 */
var Space = function(json) {
    util.addPropsOrDefaults(d_Space, this, json)
    this.activeFixtures = []
    this.activeSensors = []
    this.schedule = {}
    this.activation = {
        zoneActive: {
            trigger: 'bt#06:00 20:00',
            action: '=lightScene#workingHours',
            otherwise: '=lightScene#outOfHours'

        }
    }
    this.sensorBrain = {}
    this.sensorBrain.behaviours = {}

    //Note-Kamlesh: Issue Dt-52 - comment out following line and remove default vlaue
    //this.sensorBrain.behaviours.onIdle = 'default'
    this.sensorBrain.behaviours.onIdle = ''
    //Note-Kamlesh: Issue Dt-52 & DT-64 - comment out MAK  new properties and explicit properties code line
    // NOTE-MAK: adding new properties for title24
    // this.sensorBrain.behaviours.onOccupancy = ''

    // WARN-MAK: following explicit properties with empty initialization
    //this.sensorBrain.occupancyEffects = {}
    //this.sensorBrain.occupancyEffects.timeout = ""
    //this.sensorBrain.occupancyEffects.fadeout = ""
   // this.sensorBrain.occupancyEffects.manual = ""

    // util.copyProperties(boilerplate_sensorBrain.behaviours, this.sensorBrain.behaviours)
    if (json !== undefined) {
        util.addPropsOrDefaults(boilerplate_sensorBrain, this.sensorBrain, json.sensorBrain)
        if (json.hasOwnProperty('activeFixtures')) {
            this.activeFixtures = json.activeFixtures
        }
        if (json.hasOwnProperty('activeSensors')) {
            this.activeSensors = json.activeSensors
        }
        if (json.hasOwnProperty('schedule')) {
            this.schedule = json.schedule
        }
        if (json.hasOwnProperty('activation')) {
            this.activation = json.activation
        }
        if (json.hasOwnProperty('sensorBrain')) {
            if (json.sensorBrain.hasOwnProperty('presTimeout')) {
                this.sensorBrain.presTimeout = json.sensorBrain.presTimeout
            }
            if (json.sensorBrain.hasOwnProperty('presRate')) {
                this.sensorBrain.presRate = json.sensorBrain.presRate
            }
            if (json.sensorBrain.hasOwnProperty('behaviours') && json.sensorBrain.behaviours.hasOwnProperty('onIdle')) {
                this.sensorBrain.behaviours.onIdle = json.sensorBrain.behaviours.onIdle
            }
            if (json.sensorBrain.hasOwnProperty('DHDeltaUp')) {
                this._dhDeltaUp = json.sensorBrain.DHDeltaUp
            }
            if (json.sensorBrain.hasOwnProperty('DHDeltaDown')) {
                this._dhDeltaDown = json.sensorBrain.DHDeltaDown
            }
            if (json.sensorBrain.hasOwnProperty('DHMaxAllowedDeviation')) {
                // Make sure it's set to the right default
                this.sensorBrain.DHMaxAllowedDeviation = 0
            }
            //Note Kamlesh: Issue Dt-52 & DT-64 - comment out MAK  loading occupancy properties from project.json
            // WARN-MAK: loading occupancy properties from project.json
            // if (json.sensorBrain.hasOwnProperty('occupancyEffects')) {
            //     this.sensorBrain.occupancyEffects = json.sensorBrain.occupancyEffects
            // }
        }
        if (json.hasOwnProperty('defaultAnimatedPalette')) {
            if (json.defaultAnimatedPalette.hasOwnProperty('animatedInfluence')) {
                this.defaultAnimatedPalette = {};
                this.defaultAnimatedPalette.animatedInfluence = json.defaultAnimatedPalette.animatedInfluence
            }
            this.defaultAnimatedPalette = {
                animatedInfluence: 100
            };
        } else {
            this.defaultAnimatedPalette = {
                animatedInfluence: 100
            };
        }
    } else {
        this.defaultAnimatedPalette = {
            animatedInfluence: 100
        };
        util.copyProperties(boilerplate_sensorBrain, this.sensorBrain)
    }
    // Make sure "pw" is available to all palettes
    Object.keys(this.sensorBrain.swatchs.palettes).forEach(function(paletteName) {
        var palette = this.sensorBrain.swatchs.palettes[paletteName]
        if (!(palette.hasOwnProperty('pw')) && boilerplate_sensorBrain.swatchs.palettes.hasOwnProperty(paletteName)) {
            palette['pw'] = boilerplate_sensorBrain.swatchs.palettes[paletteName]['pw']
        }
    }, this)
    this.maps = util.createMapFromProp('maps', json, MapRef)
}

/**
 * Filters MapRefs by building.
 *
 * @memberof   module:spaces.Space
 *
 * @param      {string}  buildingID  The building id
 *
 * @return     {string[]}  Array of MapRef IDs associated with specified building.
 */
Space.prototype.getMapRefsByBuilding = function(buildingID) {
        return Object.keys(this.maps).filter(function(value, index) {
            return this.maps[value].building === buildingID
        }, this)
    }
    /**
     * Filters MapRefs by floor.
     *
     * @memberof   module:spaces.Space
     *
     * @param      {string}  floorID  The floor id
     *
     * @return     {string[]}  Array of MapRef IDs associated with specified floor
     */
Space.prototype.getMapRefsByFloor = function(floorID) {
        return Object.keys(this.maps).filter(function(value, index) {
            return this.maps[value].floor === floorID
        }, this)
    }
    /**
     * Filters MapRefs by building and floor.
     *
     * @memberof   module:spaces.Space
     *
     * @param      {string}  buildingID  The building id
     * @param      {string}  floorID     The floor id
     * @return     {string[]}  Array of only the MapRef IDs associated with both the specified building and floor.
     */
Space.prototype.getMapRefsByIDs = function(buildingID, floorID) {
        return Object.keys(this.maps).filter(function(id, index) {
            return this.maps[id]._building === buildingID && this.maps[id]._floor === floorID
        }, this)
    }
    /**
     * Adds a MapRef object to this space
     *
     * @memberof   module:spaces.Space
     *
     * @param      {Object}  json    Options for the MapRef constructor
     *
     * @return     {string} ID of the new MapRef
     */
Space.prototype.addMapRef = function(json) {
        var id = util.generateID('map', '_', this.maps)
        this.maps[id] = new MapRef(json)
        return id
    }
    /**
     * Deletes a MapRef from this space.
     *
     * @memberof   module:spaces.Space
     *
     * @param      {string}   id      The MapRef ID.
     *
     * @return     {boolean}  true if id was valid, false otherwise.
     */
Space.prototype.deleteMapRef = function(id) {
    if (this.maps.hasOwnProperty(id)) {
        delete this.maps[id]
        return true
    }
    return false
}
Space.prototype.setAvailableLSMood = function(lightscene, mood) {
    if (this.availableLightScenes.hasOwnProperty(lightscene)) {
        if (spaceMoods.indexOf(mood) >= 0) {
            this.availableLightScenes[lightscene] = mood
            if (lightscene === this._defaultLightScene) {
                this._defaultMood = mood
            }
            return true
        }
        console.log('invalid mood value')
        return false
    }
    console.error('space does not have available lightscene ', lightscene)
    return false
};
/**
 * Add activation object to the space.
 *
 * @memberof   module:spaces.Space
 *
 * @param      {Object}  activation  activation object, should have properties "trigger", "action" and "otherwise"
 */
Space.prototype.addActivation = function(activation) {
        var id = util.generateID('activation', '_', this.activation)
        if (!activation.hasOwnProperty('action') || !activation.hasOwnProperty('otherwise')) {
            if (this.layer === 'Building') {
                activation.action = '=lightScene#workingHours'
                activation.otherwise = '=lightScene#outOfHours'
            } else {
                activation.action = '+state#zoneActive;-state#buildingLayer'
                activation.otherwise = '-state#zoneActive;+state#buildingLayer'
            }
        }
        this.activation[id] = activation
        return id
    }
    /**
     * Delete the activation with the given id if present
     *
     * @memberof   module:spaces.Space
     *
     * @param      {String}   id      ID of the activation object to be deleted
     *
     * @return     {boolean}  Return true if the activation with the given id was present, false otherwise
     */
Space.prototype.deleteActivation = function(id) {
        if (this.activation.hasOwnProperty(id)) {
            delete this.activation[id]
            return true
        }
        return false
    }
    /**
     * Set the zoneActive activation trigger
     *
     * @memberof   module:spaces.Space
     *
     * @param      {String}  trigger  trigger string with the activation start and end times, should look like 'bt#hh:mm hh:mm'
     *
     * @return     {boolean} return true if the space has a zoneActive activation, false if no activation or no arguments passed
     */
Space.prototype.setActivationTrigger = function(trigger) {
        var activationID = 'zoneActive'
        if (this.activation.hasOwnProperty(activationID)) {
            if (trigger !== undefined) {
                this.activation[activationID].trigger = trigger
                return true
            }
            console.error('invalid trigger argument')
            return false
        }
        console.error('invalid activation ID')
        return false
    }
    /**
     * Add lightscene entry to availableLightScenes object
     *
     * @memberof   module:spaces.Space
     *
     * @param      {String}            lightScene  The light scene name
     * @param      {mood}            mood        The mood for this lightscene entry
     *
     * @return     {boolean}  return true if lightscene is new to the space and added successfully, false otherwise
     */
Space.prototype.addLightScene = function(lightScene, mood) {
        if (this.availableLightScenes.hasOwnProperty(lightScene)) {
            console.error('space already has lightscene ', lightScene)
            return false
        } else if (spaceLightScenes.indexOf(lightScene) >= 0) {
            var mood = (mood !== null || spaceMoods.indexOf(mood) < 0) ?
                mood :
                'vigilant'
            this.availableLightScenes[lightScene] = mood
            return true
        }
        console.error('failed to add lightscene')
        return false
    }

Space.prototype.addSchedule = function(entry) {
        this.schedule = entry
        return false
    }
    /**
     * Remove lightscene entry from availableLightScenes Object
     *
     * @memberof   module:spaces.Space
     *
     * @param      {String}   lightScene  The light scene name
     *
     * @return     {boolean}  Return true if this space had an entry for this lightscene and removed it successfully, false otherwise
     */
Space.prototype.removeLightScene = function(lightScene) {
        var availableLightScenes = this.availableLightScenes
        if (availableLightScenes.hasOwnProperty(lightScene)) {
            delete availableLightScenes[lightScene]
            if (this._defaultLightScene === lightScene) {
                this._defaultLightScene = Object.keys(availableLightScenes)[0]
            }
            return true
        }
        console.error('space does not have ', lightScene)
        return false
    }
    /**
     * Toggle lightscene entry in the availableLightScenes object: if it has an entry for this lightscene, remove it, else add an entry with the specified mood
     *
     * @memberof   module:spaces.Space
     *
     * @param      {string}           lightScene  The light scene name
     * @param      {string}           mood        The mood name to associate with the lightscene
     *
     * @return     {Object}           Return reference to the availableLightScenes of this space object
     */
Space.prototype.toggleLightScene = function(lightScene, mood) {
    if (this.availableLightScenes.hasOwnProperty(lightScene)) {
        this.removeLightScene(lightScene)
    } else {
        this.addLightScene(lightScene, mood)
    }
    return this.availableLightScenes
}

Object.defineProperties(Space.prototype, {
    '_type': {
        configurable: true,
        get: function() {
            return this.type
        }
    },
    '_defaultLightScene': {
        get: function() {
            return this.defaultLightScene
        },
        set: function(val) {
            if (this.availableLightScenes.hasOwnProperty(val)) {
                this.defaultLightScene = val
                this._defaultMood = this.availableLightScenes[val]
                return true
            }
            console.error('invalid value for defaultLightScene: ', val)
            return false
        }
    },
    '_behaviour': {
        get: function() {
            // NOTE-MAK: making behaviour a multi property
            // return this.sensorBrain.behaviours.onIdle
            return this.sensorBrain.behaviours
        },
        // NOTE-MAK: making set behaviour a multi property

        // set: function (value) {
        //     if (spaceBehaviours.indexOf(value) >= 0) {
        //         this.sensorBrain.behaviours.onIdle = value
        //         return true
        //     }
        //     console.error('invalid behaviour value: ', value)
        //     return false
        // }
        set: function(behaviour) {
            if (spaceBehaviours.indexOf(behaviour.onIdle) >= 0) {
                //Note Kamlesh: Issue Dt-52 - comment out following line
               // this.sensorBrain.behaviours = behaviour
                return true
            }
            console.error('invalid behaviour value: ', value)
            return false
        }
    },

    // NOTE-MAK: adding new state properties for timeout, fadeout, and manual-on buttons
    // NOTE-MAK: private property underscore _ notation is actually reversed by amBX
    // WARN-MAK: placeholder for state issue
     //Note Kamlesh: Issue Dt-52 uncomment _occupancyEffects
    // TODO-MAK: require occupancy state json to another json in .tar
    '_onOccupancy': {
        get: function() {
            if(this.sensorBrain.behaviours.onOccupancy == 'leaveOff'){
              return true
            }else{
              return false
            }
        },
        set: function(effects) {
          // this.sensorBrain.behaviours.onOccupancy = effects
          if(effects === ''){
            return delete this.sensorBrain.behaviours['onOccupancy']
          }else{
            this.sensorBrain.behaviours.onOccupancy = effects
          }
        }
    },
    '_timeout': {
        get: function() {
            return this.sensorBrain.presTimeout / 1000
        },
        set: function(value) {
            if (Number.isSafeInteger(value)) {
                this.sensorBrain.presTimeout = value * 1000
                return true
            }
            console.error('invalid timeout value: ', value)
        }
    },
    '_scheduleEntry': {
        get: function() {
            return this.schedule._entries
        },
        set: function(value) {
            this.schedule._entries.push(value)
            console.error('invalid schedule value: ', value)
        }
    },
    '_fadeout': {
        get: function() {
            var sensorBrain = this.sensorBrain
            var numSteps = 100 / sensorBrain.presDelta
            return Math.round(sensorBrain.presRate * numSteps / 1000)
        },
        set: function(value) {
            if (Number.isSafeInteger(value) && value >= 1) {
                var sensorBrain = this.sensorBrain
                var numSteps = 100 / sensorBrain.presDelta
                sensorBrain.presRate = Math.round(value / numSteps * 1000)
                return true
            }
            //NOTE: Kamlesh- DT-52 sub issue no2: commit following else if because set worng value
            // else if (value < 1) {
            //     var sensorBrain = this.sensorBrain
            //     console.error('presRate value too small: ', value)
            //     sensorBrain.presRate = 1
            //     return false
            // }
            console.error('invalid presRate value: ', value)
            return false
        }
    },
    '_zoneActiveTrigger': {
        get: function() {
            return this.activation.zoneActive.trigger
        },
        set: function(value) {
            var reTrigger = /bt#[0-9]{2}:[0-9]{2} [0-9]{2}:[0-9]{2}/
            if (value.match(reTrigger)) {
                this.activation.zoneActive.trigger = value
                return
            }
            console.log('invalid trigger value: ', value)
        }
    },
    '_dhTargetLux': {
        get: function() {
            return this.sensorBrain.DHTargetLux
        },
        set: function(value) {
            var val = parseInt(value)
            if (Number.isSafeInteger(val)) {
                this.sensorBrain.DHTargetLux = parseInt(val, 10)
                return true
            }
            console.error('invalid DHTargetLux input: ', value)
            return false
        }
    },
    '_dhDeltaUp': {
        get: function() {
            return this.sensorBrain.DHDeltaUp
        },
        set: function(val) {
            var value = parseFloat(val)
            if (dhDeltas.indexOf(value) >= 0) {
                this.sensorBrain.DHDeltaUp = value
                return true
            }
            console.error('invalid DHDeltaUp input: ', value)
            console.error('setting DHDeltaUp to medium: ', dhDeltas[1])
            this.sensorBrain.DHDeltaUp = dhDeltas[1]
            return false
        }
    },
    '_dhDeltaDown': {
        get: function() {
            return this.sensorBrain.DHDeltaDown
        },
        set: function(val) {
            var value = parseFloat(val)
            if (dhDeltas.indexOf(value) >= 0) {
                this.sensorBrain.DHDeltaDown = value
                return true
            }
            console.error('invalid DHDeltaDown input: ', value)
            console.error('setting DHDeltaDown to medium: ', dhDeltas[1])
            this.sensorBrain.DHDeltaDown = dhDeltas[1]
            return false
        }
    },
    '_defaultBrightness': {
        get: function() {
            return this.defaultBrightness
        },
        set: function(val) {
            // Ensure value is in the range [0 .. 100]
            this.defaultBrightness = parseInt(val, 10) % 101
        }
    }
})

util.definePseudo(Space.prototype, 'name')
util.definePseudoInt(Space.prototype, 'amBXSpace')
util.defineRestrictedPseudo(Space.prototype, 'defaultMood', spaceMoods)

Object.freeze(Space.prototype)

/**
 * Valid General Space 'type' property values
 *
 * @memberof   module:spaces
 *
 * @type       {Array}
 */
var generalSpaceTypes = ['RR', 'Stairs', 'Aisle', 'Exit', 'Elevator', 'Cafeteria', 'Lobby', 'Feature']
    /**
     * Valid lightscene values for General Spaces
     *
     * @memberof   module:spaces
     *
     * @type       {Array}
     */
var generalLightScenes = ['rr', 'stairs', 'aisle', 'exit', 'elevator', 'cafeteria', 'lobby', 'feature']

/**
 * Hash map of defaults for General Space 'availableLightScenes' properties, indexed by space type
 * @memberof   module:spaces
 *
 * @type       {Object}
 */
var generalAvailableLS = {
    'RR': {
        'rr': 'vigilant'
    },
    'Stairs': {
        'stairs': 'vigilant'
    },
    'Aisle': {
        'aisle': 'vigilant'
    },
    'Exit': {
        'exit': 'vigilant'
    },
    'Elevator': {
        'elevator': 'vigilant'
    },
    'Lobby': {
        'lobby': 'vigilant'
    },
    'Cafeteria': {
        'cafeteria': 'vigilant'
    },
    'Feature': {
        'feature': 'vigilant'
    }
}
Object.freeze(generalAvailableLS)

/**
 * Default General Space lightscene values by space type
 *
 * @memberof   module:spaces
 *
 * @type       {Object}
 */
var generalLSDefaults = {
    RR: 'rr',
    Stairs: 'stairs',
    Aisle: 'aisle',
    Exit: 'exit',
    Elevator: 'elevator',
    Lobby: 'lobby',
    Cafeteria: 'cafeteria',
    Feature: 'feature'
}

/**
 * Default properties for General Space objects
 *
 * @type       {Object}
 */
var d_GeneralSpace = {
    type: 'RR'
        // activation: {}
}
Object.freeze(d_GeneralSpace)

/**
 * Constructor for 'General' layer space - subclass of Space
 *
 * @memberof   module:spaces
 *
 * @class      GeneralSpace
 * @param      {Object}  json    Options object with properties for the new space. Defaults will be used for missing properties, invalid property names will be ignored.
 */
var GeneralSpace = function(json) {
    var activationDefaults
    Space.call(this, json)
    Object.defineProperty(this, 'layer', {
        enumerable: true,
        value: 'General'
    })
    util.addPropsOrDefaults(d_GeneralSpace, this, json)
    this.activation.zoneActive.action = '+state#zoneActive;-state#buildingLayer'
    this.activation.zoneActive.otherwise = '-state#zoneActive;+state#buildingLayer'
    if (generalSpaceTypes.indexOf(this._type) < 0) {
        this._type = d_GeneralSpace.type
    }
    activationDefaults = d_SpaceActivations[this.type]
    this.availableLightScenes = util.copyProperties(generalAvailableLS[this.type], {})
    if (json !== undefined) {
        if (json.hasOwnProperty('defaultLightScene')) {
            this._defaultLightScene = json.defaultLightScene
        } else {
            this._defaultLightScene = generalLSDefaults[this.type]
        }
        if (json.hasOwnProperty('defaultMood')) {
            this._defaultMood = json.defaultMood
        } else {
            this._defaultMood = generalAvailableLS[this.type][this.defaultLightScene]
        }
        if (!(json.hasOwnProperty('sensorBrain'))) {
            this.sensorBrain.presTimeout = activationDefaults.presTimeout
            this.sensorBrain.presRate = activationDefaults.presRate
            this.sensorBrain.behaviours.onIdle = activationDefaults.behaviour
        } else {
            if (!(json.sensorBrain.hasOwnProperty('presTimeout'))) {
                this.sensorBrain.presTimeout = activationDefaults.presTimeout
            }
            if (!(json.sensorBrain.hasOwnProperty('presRate'))) {
                this.sensorBrain.presRate = activationDefaults.presRate
            }
            if (!(json.sensorBrain.hasOwnProperty('behaviours') && json.sensorBrain.behaviours.hasOwnProperty('onIdle'))) {
                this.sensorBrain.behaviours.onIdle = activationDefaults.behaviour
            }
        }
        if (json.hasOwnProperty('activation') && json.activation.hasOwnProperty('zoneActive') && json.activation.zoneActive.hasOwnProperty('trigger')) {
            this._zoneActiveTrigger = json.activation.zoneActive.trigger
        } else {
            this._zoneActiveTrigger = activationDefaults.trigger
        }
    } else {
        this._zoneActiveTrigger = activationDefaults.trigger
        this._defaultLightScene = generalLSDefaults[this.type]
        this.sensorBrain.presTimeout = activationDefaults.presTimeout
        this.sensorBrain.presRate = activationDefaults.presRate
        this.sensorBrain.behaviours.onIdle = activationDefaults.behaviour
    }
    Object.seal(this)
    return this
}

GeneralSpace.prototype = Object.create(Space.prototype)

Object.defineProperties(GeneralSpace.prototype, {
    '_type': {
        get: function() {
            return this.type
        },
        set: function(val) {
            if (generalSpaceTypes.indexOf(val) >= 0) {
                var ls = generalLightScenes[val]
                    // var activationID = 'zoneActive'
                var activationDefaults = d_SpaceActivations[val]
                var lsID = generalAvailableLS[val]
                this.type = val
                this.availableLightScenes = util.copyProperties(generalAvailableLS[val], {})
                this._defaultLightScene = generalLSDefaults[val]
                return true
            }
            console.error(val + ' is not a valid value for type')
            return false
        }
    }
})

Object.freeze(GeneralSpace.prototype)
exports.GeneralSpace = GeneralSpace

// --------------------------------------------------------------------------------------------------------------------------

/**
 * Valid 'type' property values for Beacon Spaces
 *
 * @type       {Array}
 */
var beaconSpaceTypes = ['Shades', 'Information', 'Status']
    /**
     * Valid User Space lightscene values
     *
     * @type       {Array}
     */
var beaconLightScenes = ['oneColour']
    /**
     * Default values for User Space lightscenes, indexed by space type
     *
     * @type       {Object}
     */
var beaconLSDefaults = {
        'Shades': 'oneColour',
        'Information': 'oneColour',
        'Status': 'oneColour'
    }
    /**
     * Default values for User Space 'availableLightScenes' property, indexed by space type
     *
     * @type       {Object}
     */
var beaconAvailableLS = {
    'Shades': {
        'oneColour' : 'default'
    },
    'Information': {
        'oneColour' : 'fire'
    },
    'Status': {
        'oneColour' : 'fire'
    }
}
Object.freeze(beaconAvailableLS)

/**
 * User Space default object
 *
 * @type       {Object}
 */
var d_BeaconSpace = {
    type: 'Shades',

}
Object.freeze(d_BeaconSpace)

var BeaconSpace =
    /**
    //  * Constructor for 'Beacon' layer space. Subclass of Space
     *
     * @class      Beacon Space
     * @param      {Object}  json    Options object with properties for the new space. Defaults will be used for missing properties, invalid property names will be ignored.
     */
    exports.BeaconSpace = function(json) {
        var activationDefaults
        Space.call(this, json)
        Object.defineProperty(this, 'layer', {
            enumerable: true,
            value: 'Information'
        })
        util.addPropsOrDefaults(d_BeaconSpace, this, json)
        this.activation.zoneActive.action = '+state#zoneActive;-state#buildingLayer'
        this.activation.zoneActive.otherwise = '-state#zoneActive;+state#buildingLayer'
        if (beaconSpaceTypes.indexOf(this.type) < 0) {
            this._type = d_BeaconSpace.type
        }
        activationDefaults = d_SpaceActivations[this.type]
        if (json !== undefined) {
            if (json.hasOwnProperty('defaultLightScene')) {
                this.defaultLightScene = json.defaultLightScene
            } else {
                this.defaultLightScene = beaconLSDefaults[this.type]
            }
            if (json.hasOwnProperty('defaultMood')) {
                this._defaultMood = json.defaultMood
            } else {
                this._defaultMood = beaconAvailableLS[this.type][this.defaultLightScene]
            }
            if (json.hasOwnProperty('availableLightScenes')) {
                this.availableLightScenes = {}
                Object.keys(json.availableLightScenes).forEach(function(lightscene) {
                    this.addLightScene(lightscene, json.availableLightScenes[lightscene])
                }, this)
            } else {
                this.availableLightScenes = util.copyProperties(beaconAvailableLS[this.type], {})
            }
        } else {
            // this.sensorBrain.presTimeout = activationDefaults.presTimeout
            // this.sensorBrain.presRate = activationDefaults.presRate
            // //Note Kamlesh: Issue Dt-52 - comment out this.sensorBrain.behaviours.onIdle and occupancy properties and add new this.sensorBrain.behaviours.onIdle
            // //this.sensorBrain.behaviours.onIdle = activationDefaults.behaviour
            // this.sensorBrain.behaviours = boilerplate_sensorBrain.behaviours
            // this._zoneActiveTrigger = activationDefaults.trigger
            // this.defaultLightScene = beaconLSDefaults[this.type]
            // this._defaultMood = beaconAvailableLS[this.type][this.defaultLightScene]
            // this.availableLightScenes = util.copyProperties(beaconAvailableLS[this.type], {})
                // WARN-MAK loading occupancy properties from sensor brain boilerplate default
         //   this.sensorBrain.occupancyEffects = boilerplate_sensorBrain.occupancyEffects
        }
        Object.seal(this)
        this.sensorBrain = {
              "behaviours": {
                "onIdle": "stayOn"
              },
              "bioadaptivityStepSize": 0.5,
              "immersionStepSize": 0.5
        }
        //NOTE: prakash- Need to comment this if we need start time and end time in beacon
        // this.activation = {}
        this.defaultAnimatedPalette.animatedInfluence = 0
        console.log(this)
        return this
    }

BeaconSpace.prototype = Object.create(Space.prototype)

Object.defineProperties(BeaconSpace.prototype, {
    _type: {
        get: function() {
            return this.type
        },
        set: function(val) {
            var idx = beaconSpaceTypes.indexOf(val)
            if (idx >= 0 && idx < 4) {
                // var activationID = 'zoneActive'
                // var activationDefaults = d_SpaceActivations[val]
                this.type = val
                this.availableLightScenes = util.copyProperties(beaconAvailableLS[val], {})
                this._defaultLightScene = beaconLSDefaults[val]
                    //this.activation[activationID].trigger = activationDefaults.trigger
                    // this.sensorBrain.presDelta = activationDefaults.presDelta
                    //this.sensorBrain.presRate = activationDefaults.presRate
                    //this.sensorBrain.presTimeout = activationDefaults.presTimeout
                    //this._behaviour = activationDefaults.behaviour
                return true
            }
            console.error(val + ' is not a valid value for type')
            return false
        }
    }
})

Object.freeze(BeaconSpace.prototype)

// --------------------------------------------------------------------------------------------------------------------------
/**
 * Valid 'type' property values for User Spaces
 *
 * @type       {Array}
 */
var userSpaceTypes = ['Desk', 'Breakout', 'Meeting', 'Lab', 'DeskCustom', 'BreakoutCustom', 'MeetingCustom', 'LabCustom']
    /**
     * Valid User Space lightscene values
     *
     * @type       {Array}
     */
var userLightScenes = ['creative', 'orbit', 'speaker', 'meeting', 'daylight', 'video', 'personal']
    /**
     * Default values for User Space lightscenes, indexed by space type
     *
     * @type       {Object}
     */
var userLSDefaults = {
        'Desk': 'daylight',
        'Breakout': 'creative',
        'Meeting': 'meeting',
        'Lab': 'creative'
    }
    /**
     * Default values for User Space 'availableLightScenes' property, indexed by space type
     *
     * @type       {Object}
     */
var userAvailableLS = {
    Desk: {

        orbit: 'vigilant',
        creative: 'vigilant',
        daylight: 'vigilant',
        meeting: 'vigilant',
        personal: 'vigilant',
    },
    Meeting: {
        'creative': 'vigilant',
        'meeting': 'vigilant',
        'orbit': 'vigilant',
        'speaker': 'vigilant',
        'daylight': 'vigilant',
        'video': 'vigilant',
        'personal': 'vigilant',
    },
    Breakout: {
        'creative': 'vigilant',
        'orbit': 'vigilant',
        'daylight': 'vigilant',
        'personal': 'vigilant',
    },
    Lab: {
        'creative': 'vigilant',
        'orbit': 'vigilant',
        'daylight': 'vigilant',
        'video': 'vigilant',
        'personal': 'vigilant',
    }
}
Object.freeze(userAvailableLS)

/**
 * User Space default object
 *
 * @type       {Object}
 */
var d_UserSpace = {
    type: 'Desk'
}
Object.freeze(d_UserSpace)

var UserSpace =
    /**
     * Constructor for 'User' layer space. Subclass of Space
     *
     * @class      UserSpace
     * @param      {Object}  json    Options object with properties for the new space. Defaults will be used for missing properties, invalid property names will be ignored.
     */
    exports.UserSpace = function(json) {
        var activationDefaults
        Space.call(this, json)
        Object.defineProperty(this, 'layer', {
            enumerable: true,
            value: 'User'
        })
        util.addPropsOrDefaults(d_UserSpace, this, json)
        this.activation.zoneActive.action = '+state#zoneActive;-state#buildingLayer'
        this.activation.zoneActive.otherwise = '-state#zoneActive;+state#buildingLayer'
        if (userSpaceTypes.indexOf(this.type) < 0) {
            this._type = d_UserSpace.type
        }
        activationDefaults = d_SpaceActivations[this.type]
        if (json !== undefined) {
            if (json.hasOwnProperty('defaultLightScene')) {
                this.defaultLightScene = json.defaultLightScene
            } else {
                this.defaultLightScene = userLSDefaults[this.type]
            }
            if (json.hasOwnProperty('defaultMood')) {
                this._defaultMood = json.defaultMood
            } else {
                this._defaultMood = userAvailableLS[this.type][this.defaultLightScene]
            }
            if (!(json.hasOwnProperty('sensorBrain'))) {
                this.sensorBrain.presTimeout = activationDefaults.presTimeout
                this.sensorBrain.presRate = activationDefaults.presRate

                //Note Kamlesh: Issue Dt-52 - comment out this.sensorBrain.behaviours.onIdle and this.sensorBrain.occupancyEffects add new this.sensorBrain.behaviours
                //this.sensorBrain.behaviours.onIdle = activationDefaults.behaviour
                this.sensorBrain.behaviours = boilerplate_sensorBrain.behaviours

                // WARN-MAK:
               // this.sensorBrain.occupancyEffects = boilerplate_sensorBrain.occupancyEffects
            } else {
                if (!(json.sensorBrain.hasOwnProperty('presTimeout'))) {
                    this.sensorBrain.presTimeout = activationDefaults.presTimeout
                }
                if (!(json.sensorBrain.hasOwnProperty('presRate'))) {
                    this.sensorBrain.presRate = activationDefaults.presRate
                }
                if (!(json.sensorBrain.hasOwnProperty('behaviours') && json.sensorBrain.behaviours.hasOwnProperty('onIdle'))) {
                    this.sensorBrain.behaviours.onIdle = activationDefaults.behaviour
                }
                //Note Kamlesh: Issue Dt-64 - comment out loading occupancy properties from sensor
                // WARN-MAK loading occupancy properties from sensor brain boilerplate default
                // if (!(json.sensorBrain.hasOwnProperty('occupancyEffects'))) {
                //     this.sensorBrain.occupancyEffects = boilerplate_sensorBrain.occupancyEffects
                // }
            }
            if (json.hasOwnProperty('activation') && json.activation.hasOwnProperty('zoneActive') && json.activation.zoneActive.hasOwnProperty('trigger')) {
                this._zoneActiveTrigger = json.activation.zoneActive.trigger
            }
            if (json.hasOwnProperty('availableLightScenes')) {
                this.availableLightScenes = {}
                Object.keys(json.availableLightScenes).forEach(function(lightscene) {
                    this.addLightScene(lightscene, json.availableLightScenes[lightscene])
                }, this)
            } else {
                this.availableLightScenes = util.copyProperties(userAvailableLS[this.type], {})
            }
        } else {
            this.sensorBrain.presTimeout = activationDefaults.presTimeout
            this.sensorBrain.presRate = activationDefaults.presRate
            //Note Kamlesh: Issue Dt-52 - comment out this.sensorBrain.behaviours.onIdle and occupancy properties and add new this.sensorBrain.behaviours.onIdle
            //this.sensorBrain.behaviours.onIdle = activationDefaults.behaviour
            this.sensorBrain.behaviours = boilerplate_sensorBrain.behaviours
            this._zoneActiveTrigger = activationDefaults.trigger
            this.defaultLightScene = userLSDefaults[this.type]
            this._defaultMood = userAvailableLS[this.type][this.defaultLightScene]
            this.availableLightScenes = util.copyProperties(userAvailableLS[this.type], {})
                // WARN-MAK loading occupancy properties from sensor brain boilerplate default
         //   this.sensorBrain.occupancyEffects = boilerplate_sensorBrain.occupancyEffects
        }
        Object.seal(this)
        return this
    }

UserSpace.prototype = Object.create(Space.prototype)

Object.defineProperties(UserSpace.prototype, {
    _type: {
        get: function() {
            return this.type
        },
        set: function(val) {
            var idx = userSpaceTypes.indexOf(val)
            if (idx >= 0 && idx < 4) {
                // var activationID = 'zoneActive'
                // var activationDefaults = d_SpaceActivations[val]
                this.type = val
                this.availableLightScenes = util.copyProperties(userAvailableLS[val], {})
                this._defaultLightScene = userLSDefaults[val]
                    //this.activation[activationID].trigger = activationDefaults.trigger
                    // this.sensorBrain.presDelta = activationDefaults.presDelta
                    //this.sensorBrain.presRate = activationDefaults.presRate
                    //this.sensorBrain.presTimeout = activationDefaults.presTimeout
                    //this._behaviour = activationDefaults.behaviour
                return true
            }
            console.error(val + ' is not a valid value for type')
            return false
        }
    }
})

Object.freeze(UserSpace.prototype)

var createMap =
    /**
     * Creates a map of Space object, inferring the appropriate constructors to use from the 'layer' properties of the argument object properties.
     *
     * @param      {Object}  json    Treated as a 'hash map' of Spaces - keys refer to Space objects.
     *
     * @returns    {Object} A 'hash map' of Space object. If argument is missing/invalid, a single 'Building' layer space will be constructed by default.
     */
    exports.createMap = function(json) {
        var gotDefault = false
        var result = {}
        if (json !== undefined && json.hasOwnProperty('spaces')) {
            Object.keys(json.spaces).forEach(function(id) {
                if (json.spaces[id].hasOwnProperty('layer')) {
                    var layer = json.spaces[id].layer
                    if (layer === 'General') {
                        result[id] = new GeneralSpace(json.spaces[id])
                    }else if (layer === 'Information') {
                        result[id] = new BeaconSpace(json.spaces[id])
                    }else if (layer === 'User') {
                        result[id] = new UserSpace(json.spaces[id])
                    } else if (layer === 'Building' && !gotDefault) {
                        result[id] = new Space(json.spaces[id])
                        gotDefault = true
                    }
                }
            })
        }
        if (!gotDefault) {
            var defaultID = 'BuildingDefault'
            result[defaultID] = new Space()
        }
        return result
    }

var typesByPriority =
    /**
     * Ordered array of Space types by priority
     *
     * @memberof   module:spaces
     *
     * @type       {Array}
     */
    exports.typesByPriority = [
        'Lab',
        'LabCustom',
        'Breakout',
        'BreakoutCustom',
        'Meeting',
        'MeetingCustom',
        'Desk',
        'DeskCustom',
        'Feature',
        'Aisle',
        'Cafeteria',
        'Exit',
        'Lobby',
        'Elevator',
        'Stairs',
        'RR',
        'Information',
        'Shades',
        'Status',
        'Default',
    ]
