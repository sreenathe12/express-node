var Scheduler = require('../scheduler/scheduler')
var Schedule = require('../scheduler/schedule')
var ScheduleEntry = require('../scheduler/scheduleEntry')
$(function() {
    var activeTab;
    var activeTabGeneral;
    var activeTabBeacon;
    var updatedScheduleEntryOjb = {};
    var schedule ;
    var entry;
    var spaceObj;
    $('#activation-user').on('click', "li", function(event) {
        var str = event.toElement.href
        if(str != undefined){
          var res = str.split("-");
          activeTab = res[2] ;
        }else{
          activeTab = 1
        }
        var currentView = 'user'
        var view = views[currentView]
        var spaceName = view.selected
        spaceObj = main.getCurrentController().spaces[view.selected]

        // WARN-MAK: spaceObj is undefined when exiting user-zone and
        if (!spaceObj) {
            return undefined
        }
        var scheduler = Scheduler.singleton
        schedule = scheduler.getSchedule(spaceObj.amBXSpace)

        if(schedule){
            if(schedule[activeTab]){
                updatedScheduleEntryOjb = schedule[activeTab]
                entry = new ScheduleEntry.ScheduleEntry(activeTab, updatedScheduleEntryOjb._name)
            }
        }
        if(activeTab > 1){
          var $time_start_Schedule = $("#time_start_schedule")
          var startPickerSchedule = $time_start_Schedule.pickatime('picker')

          var atTime = schedule[activeTab].trigger.split("#")
          startPickerSchedule.set('select', atTime[1],  { format: 'HH:i' } )
          $('#' + currentView).find('.default-brightness-slider').val(updatedScheduleEntryOjb.brightness).prop('disabled', false)
          $('#' + currentView).find('.default-brightness-value').text(updatedScheduleEntryOjb.brightness + '%')
          // disabled for scheduling
          $("#time_default").css('display','none')
          $("#time_schedule").css('display','')

          $("#manual-on-checkbox").attr("disabled", "disabled")
          $(".manual-disabled").css("cursor", "not-allowed")

          $(".timeout-disabled").css("cursor", "not-allowed")
          $("#timeout-checkbox").attr("disabled", "disabled")
          $("#occupancy-timeout-duration").attr("disabled", "disabled")

          $(".fadeout-disabled").css("cursor", "not-allowed")
          $("#fadeout-checkbox").attr("disabled", "disabled")
          $("#occupancy-fadeout-duration").attr("disabled", "disabled")

          $("#cicadium-cycle-checkbox").attr("disabled", "disabled")
          $(".cicadium-disabled").css("cursor", "not-allowed")

          $("input[id=target-lux]").attr("disabled", "disabled")
          $("input[id=dh-delta-up]").attr("disabled", "disabled")
          $("input[id=dh-delta-down]").attr("disabled", "disabled")
          // $("input[id=default-brightness-slider-general]").attr("disabled", "disabled")
        }
        else{
          var $time_start = $("#time_start"),
              $time_end = $("#time_end")
          var startPicker = $time_start.pickatime('picker'),
              endPicker = $time_end.pickatime('picker')
          var triggerTimes = main.parseTrigger(spaceObj._zoneActiveTrigger)
          startPicker.set('select', triggerTimes[0],  { format: 'HH:i' } )
          endPicker.set('select', triggerTimes[1],  { format: 'HH:i' } )
          $('#' + currentView).find('.default-brightness-slider').val(spaceObj._defaultBrightness).prop('disabled', false)
          $('#' + currentView).find('.default-brightness-value').text(spaceObj._defaultBrightness + '%')
            $("#time_schedule").css('display','none')
            $("#time_default").css('display','')

            // properties enabled for default zone level
            $("#manual-on-checkbox").removeAttr("disabled", "disabled")
            $(".manual-disabled").css("cursor", "")

            $(".timeout-disabled").css("cursor", "")
            $("#timeout-checkbox").removeAttr("disabled", "disabled")
            $("#occupancy-timeout-duration").removeAttr("disabled", "disabled")

            $(".fadeout-disabled").css("cursor", "")
            $("#fadeout-checkbox").removeAttr("disabled", "disabled")
            $("#occupancy-fadeout-duration").removeAttr("disabled", "disabled")

            $("#cicadium-cycle-checkbox").removeAttr("disabled", "disabled")
            $(".cicadium-disabled").css("cursor", "")

            $("input[id=target-lux]").removeAttr("disabled", "disabled")
            $("input[id=dh-delta-up]").removeAttr("disabled", "disabled")
            $("input[id=dh-delta-down]").removeAttr("disabled", "disabled")
            // $("input[id=default-brightness-slider-general]").removeAttr("disabled", "disabled")
        }


    });
    $('#activation-general').on('click', "li", function(event) {
        var str = event.toElement.href
        if(str != undefined){
          var res = str.split("-");
          activeTabGeneral = res[3] ;
        }else{
          activeTabGeneral = 1
        }
        var currentView = 'general'
        var view = views[currentView]
        var spaceName = view.selected
        spaceObj = main.getCurrentController().spaces[view.selected]
        // WARN-MAK: spaceObj is undefined when exiting user-zone and
        if (!spaceObj) {
            return undefined
        }
        var scheduler = Scheduler.singleton
        schedule = scheduler.getSchedule(spaceObj.amBXSpace)
        if(schedule){
            if(schedule[activeTabGeneral]){
                updatedScheduleEntryOjb = schedule[activeTabGeneral]
                entry = new ScheduleEntry.ScheduleEntry(activeTabGeneral, updatedScheduleEntryOjb._name)
            }
        }
        if(activeTabGeneral > 1){
          var $time_start_Schedule_general = $("#time_start_schedule_general")
          var startPickerSchedule = $time_start_Schedule_general.pickatime('picker')
          var atTime = schedule[activeTabGeneral].trigger.split("#")
          startPickerSchedule.set('select', atTime[1],  { format: 'HH:i' } )
          $('#' + currentView).find('.default-brightness-slider').val(updatedScheduleEntryOjb.brightness).prop('disabled', false)
          $('#' + currentView).find('.default-brightness-value').text(updatedScheduleEntryOjb.brightness + '%')
          // disabled for scheduling
          $("#time_default_general").css('display','none')
          $("#time_schedule_general").css('display','')

          $("#manual-on-checkbox-general").attr("disabled", "disabled")
          $(".manual-disabled").css("cursor", "not-allowed")

          $(".timeout-disabled").css("cursor", "not-allowed")
          $("#timeout-checkbox-general").attr("disabled", "disabled")
          $("#occupancy-timeout-duration-general").attr("disabled", "disabled")

          $(".fadeout-disabled").css("cursor", "not-allowed")
          $("#fadeout-checkbox-general").attr("disabled", "disabled")
          $("#occupancy-fadeout-duration-general").attr("disabled", "disabled")

          $("#cicadium-cycle-checkbox-general").attr("disabled", "disabled")
          $(".cicadium-disabled").css("cursor", "not-allowed")

          $("input[id=target-lux]").attr("disabled", "disabled")
          $("input[id=dh-delta-up]").attr("disabled", "disabled")
          $("input[id=dh-delta-down]").attr("disabled", "disabled")
          // $("input[id=default-brightness-slider-general]").attr("disabled", "disabled")
        }
        else{
          var $time_start = $("#activation-time-from"),
              $time_end = $("#activation-time-to")
          var startPicker = $time_start.pickatime('picker'),
              endPicker = $time_end.pickatime('picker')
          var triggerTimes = main.parseTrigger(spaceObj._zoneActiveTrigger)
          startPicker.set('select', triggerTimes[0],  { format: 'HH:i' } )
          endPicker.set('select', triggerTimes[1],  { format: 'HH:i' } )
          $('#' + currentView).find('.default-brightness-slider').val(spaceObj._defaultBrightness).prop('disabled', false)
          $('#' + currentView).find('.default-brightness-value').text(spaceObj._defaultBrightness + '%')
            $("#time_schedule_general").css('display','none')
            $("#time_default_general").css('display','')

            // properties enabled for default zone level
            $("#manual-on-checkbox-general").removeAttr("disabled", "disabled")
            $(".manual-disabled").css("cursor", "")

            $(".timeout-disabled").css("cursor", "")
            $("#timeout-checkbox-general").removeAttr("disabled", "disabled")
            $("#occupancy-timeout-duration-general").removeAttr("disabled", "disabled")

            $(".fadeout-disabled").css("cursor", "")
            $("#fadeout-checkbox-general").removeAttr("disabled", "disabled")
            $("#occupancy-fadeout-duration-general").removeAttr("disabled", "disabled")

            $("#cicadium-cycle-checkbox-general").removeAttr("disabled", "disabled")
            $(".cicadium-disabled").css("cursor", "")

            $("input[id=target-lux]").removeAttr("disabled", "disabled")
            $("input[id=dh-delta-up]").removeAttr("disabled", "disabled")
            $("input[id=dh-delta-down]").removeAttr("disabled", "disabled")
            // $("input[id=default-brightness-slider-general]").removeAttr("disabled", "disabled")
        }


    });
    $('#activation-beacon').on('click', "li", function(event) {
        var str = event.toElement.href
        if(str != undefined){
          var res = str.split("-");
          activeTabBeacon = res[3] ;
        }else{
          activeTabBeacon = 1
        }
        var currentView = 'beacon'
        var view = views[currentView]
        var spaceName = view.selected
        spaceObj = main.getCurrentController().spaces[view.selected]
        // WARN-MAK: spaceObj is undefined when exiting user-zone and
        if (!spaceObj) {
            return undefined
        }
        var scheduler = Scheduler.singleton
        schedule = scheduler.getSchedule(spaceObj.amBXSpace)
        if(schedule){
            if(schedule[activeTabBeacon]){
                updatedScheduleEntryOjb = schedule[activeTabBeacon]
                entry = new ScheduleEntry.ScheduleEntry(activeTabBeacon, updatedScheduleEntryOjb._name)
            }
        }
        if(activeTabBeacon > 1){
          var $time_start_schedule_beacon = $("#time_start_schedule_beacon")
          var startPickerSchedule = $time_start_schedule_beacon.pickatime('picker')
          var atTime = schedule[activeTabBeacon].trigger.split("#")
          startPickerSchedule.set('select', atTime[1],  { format: 'HH:i' } )
          $('#' + currentView).find('.default-brightness-slider').val(updatedScheduleEntryOjb.brightness).prop('disabled', false)
          $('#' + currentView).find('.default-brightness-value').text(updatedScheduleEntryOjb.brightness + '%')
          // disabled for scheduling
          $("#time_default_beacon").css('display','none')
          $("#time_schedule_beacon").css('display','')

          $("#manual-on-checkbox-beacon").attr("disabled", "disabled")
          $(".manual-disabled").css("cursor", "not-allowed")

          $(".timeout-disabled").css("cursor", "not-allowed")
          $("#timeout-checkbox-beacon").attr("disabled", "disabled")
          $("#occupancy-timeout-duration-beacon").attr("disabled", "disabled")

          $(".fadeout-disabled").css("cursor", "not-allowed")
          $("#fadeout-checkbox-beacon").attr("disabled", "disabled")
          $("#occupancy-fadeout-duration-beacon").attr("disabled", "disabled")

          $("#cicadium-cycle-checkbox-beacon").attr("disabled", "disabled")
          $(".cicadium-disabled").css("cursor", "not-allowed")

          $("input[id=target-lux]").attr("disabled", "disabled")
          $("input[id=dh-delta-up]").attr("disabled", "disabled")
          $("input[id=dh-delta-down]").attr("disabled", "disabled")
          // $("input[id=default-brightness-slider-general]").attr("disabled", "disabled")
        }
        else{
          var $time_start = $("#time_start_beacon"),
              $time_end = $("#time_end_beacon")
          var startPicker = $time_start.pickatime('picker'),
              endPicker = $time_end.pickatime('picker')
          var triggerTimes = main.parseTrigger(spaceObj._zoneActiveTrigger)
          startPicker.set('select', triggerTimes[0],  { format: 'HH:i' } )
          endPicker.set('select', triggerTimes[1],  { format: 'HH:i' } )
          $('#' + currentView).find('.default-brightness-slider').val(spaceObj._defaultBrightness).prop('disabled', false)
          $('#' + currentView).find('.default-brightness-value').text(spaceObj._defaultBrightness + '%')
            $("#time_schedule_beacon").css('display','none')
            $("#time_default_beacon").css('display','')

            // properties enabled for default zone level
            $("#manual-on-checkbox-beacon").removeAttr("disabled", "disabled")
            $(".manual-disabled").css("cursor", "")

            $(".timeout-disabled").css("cursor", "")
            $("#timeout-checkbox-beacon").removeAttr("disabled", "disabled")
            $("#occupancy-timeout-duration").removeAttr("disabled", "disabled")

            $(".fadeout-disabled").css("cursor", "")
            $("#fadeout-checkbox-beacon").removeAttr("disabled", "disabled")
            $("#occupancy-fadeout-duration-beacon").removeAttr("disabled", "disabled")

            $("#cicadium-cycle-checkbox-beacon").removeAttr("disabled", "disabled")
            $(".cicadium-disabled").css("cursor", "")

            $("input[id=target-lux]").removeAttr("disabled", "disabled")
            $("input[id=dh-delta-up]").removeAttr("disabled", "disabled")
            $("input[id=dh-delta-down]").removeAttr("disabled", "disabled")
            // $("input[id=default-brightness-slider-general]").removeAttr("disabled", "disabled")
        }


    });
    $('.default-brightness-slider').on('input change', function(event) {
        var view = views[currentView]
        if (view.selected !== '') {
            var value = $(this)
                .val()

                //NOTE- Kamlesh: Multiple Selection- Creating multiple spaceObj
                if(view.multiSelected.length > 1){
                    for(var i = 0; i < view.multiSelected.length; i++){
                        var spaceObj = main.getCurrentController().spaces[view.multiSelected[i]]
                          // spaceObj._defaultBrightness = value
                          switch(currentView){
                            case 'user':
                            brightnessEntry(spaceObj, value, activeTab)
                            break ;
                            case 'beacon':
                            brightnessEntry(spaceObj, value, activeTabBeacon)
                            break ;
                            case 'general':
                            brightnessEntry(spaceObj, value, activeTabGeneral)
                            break ;
                          }
                    }
                }else{
                    var spaceObj = main.getCurrentController().spaces[view.selected]
                        switch(currentView){
                          case 'user':
                          brightnessEntry(spaceObj, value, activeTab)
                          break ;
                          case 'beacon':
                          brightnessEntry(spaceObj, value, activeTabBeacon)
                          break ;
                          case 'general':
                          brightnessEntry(spaceObj, value, activeTabGeneral)
                          break ;
                        }
                }

            $('#' + currentView)
                .find('.default-brightness-value')
                .text(value + '%')
        }
    })
    $('.datepicker').pickadate({
        container: 'body',
        format: 'mm/dd/yyyy',
        selectMonths: true,
        selectYears: true,
        onClose: function() {
            $(document.activeElement).blur()
        }
    })
    $('.timepicker').pickatime({
        container: 'body',
        onClose: function() {
            $(document.activeElement).blur()
        }
    })
    .on('change', function(event) {
        // WARN-MAK: index.js has hardcoded private var currentView
        // WARN-MAK: using 'user' currentView
        //var currentView = 'user'
          var self = $(this)
          var target = $(event.target)
          var view = views[currentView]
          var spaceName = view.selected
          var spaceObj = main.getCurrentController().spaces[view.selected]
           //NOTE- Kamlesh: DT-54 Multiple Space Selection: spaceObj for multiple sapce
          // var spaceObj = main.getCurrentController().spaces[view.selected]
          if(currentView === 'general'){
            if(view.multiSelected.length >1){
                 for(var i = 0; i < view.multiSelected.length; i++){
                 var spaceObjMulti = main.getCurrentController().spaces[view.multiSelected[i]]
                 timepicker_general(spaceObjMulti, activeTabGeneral)
                }
            }else{
                // spaceObj = main.getCurrentController().spaces[view.selected]
                timepicker_general(spaceObj, activeTabGeneral)
            }
          }
          if(currentView === 'user'){
            if(view.multiSelected.length >1){
                 for(var i = 0; i < view.multiSelected.length; i++){
                 var spaceObjMulti = main.getCurrentController().spaces[view.multiSelected[i]]
                 timepicker(spaceObjMulti, activeTab)
                }
            }else{
                // var spaceObj = main.getCurrentController().spaces[view.selected]
                timepicker(spaceObj, activeTab)
            }
          }
          if(currentView === 'beacon'){
            if(view.multiSelected.length >1){
                 for(var i = 0; i < view.multiSelected.length; i++){
                 var spaceObjMulti = main.getCurrentController().spaces[view.multiSelected[i]]
                 timepicker_beacon(spaceObjMulti, activeTabBeacon)
                }
            }else{
                // var spaceObj = main.getCurrentController().spaces[view.selected]
                timepicker_beacon(spaceObj, activeTabBeacon)
            }
          }
        })
    $('.ui-checkbox').checkboxradio({
        icon: false
    });


    // // NOTE-MAK: timeout button
    var $timeout_checkbox = $("#timeout-checkbox"),
        $timeout = $(".occupancy-timeout")
    var $timeout_checkbox_general = $("#timeout-checkbox-general"),
        $timeoutGeneral = $(".occupancy-timeout-general")
    $timeout_checkbox.click(function() {
        if ($timeout_checkbox.is(':checked')) {
            $timeout.show(250).css("display", "inline-block")
        } else {
            $timeout.hide()
        }
    });
    $timeout_checkbox_general.click(function() {
        if ($timeout_checkbox_general.is(':checked')) {
            $timeoutGeneral.show(250).css("display", "inline-block")
        } else {
            $timeoutGeneral.hide()
        }
    });
    // // NOTE-MAK: fadeout button
    var $fadeout_checkbox = $("#fadeout-checkbox"),
        $fadeout = $(".occupancy-fadeout")
    var $fadeout_checkbox_general = $("#fadeout-checkbox-general"),
        $fadeoutGeneral = $(".occupancy-fadeout-general")
    $fadeout_checkbox.click(function() {
        if ($fadeout_checkbox.is(':checked')) {
            $fadeout.show(250).css("display", "inline-block")
        } else {
            $fadeout.hide()
                // $fadeout_checkbox.prop("checked", false);
        }
    });
    $fadeout_checkbox_general.click(function() {
        if ($fadeout_checkbox_general.is(':checked')) {
            $fadeoutGeneral.show(250).css("display", "inline-block")
        } else {
            $fadeoutGeneral.hide()
                // $fadeout_checkbox.prop("checked", false);
        }
    });



    // NOTE-MAK: manual on button
    var $manual_on_checkbox = $("#manual-on-checkbox")
    var $manual_on_checkbox_general = $("#manual-on-checkbox-general")
    $('.available-lightscene')
        .on('change', function(event) {
          var currentView = 'user'
          var view = views[currentView]
          if (view.selected !== '') {
              var value = $(this)
                  .val()
            //NOTE- Kamlesh: DT-54 Multiple Space Selection: Loop spacObj for multiple sapce
            if(view.multiSelected.length > 1){
              for(var i = 0; i < view.multiSelected.length; i++){
                  spaceObj = main.getCurrentController().spaces[view.multiSelected[i]]
                  availLightscene(spaceObj)
              }
            }else{
                var spaceObj = main.getCurrentController()
                  .spaces[view.selected]
                availLightscene(spaceObj)
            }
         }
    })
    $('#occupancy-timeout-duration').on('change', function(event) {
        var currentView = 'user'
        var self = $(this)
        var target = $(event.target)
        var view = views[currentView]
        // var spaceObj = main.getCurrentController().spaces[view.selected]
        if(view.multiSelected.length > 1){
            for(var i = 0; i < view.multiSelected.length; i++){
                var spaceObj = main.getCurrentController().spaces[view.multiSelected[i]]
                occupancyTimeoutDuration(spaceObj)

            }

        }else{
            var spaceObj = main.getCurrentController().spaces[view.selected]
            occupancyTimeoutDuration(spaceObj)

        }
    })
    $('#occupancy-timeout-duration-general').on('change', function(event) {
        var currentView = 'general'
        var self = $(this)
        var target = $(event.target)
        var view = views[currentView]
        // var spaceObj = main.getCurrentController().spaces[view.selected]
        if(view.multiSelected.length > 1){
            for(var i = 0; i < view.multiSelected.length; i++){
                var spaceObj = main.getCurrentController().spaces[view.multiSelected[i]]
                occupancyTimeoutDurationGeneral(spaceObj)

            }

        }else{
            var spaceObj = main.getCurrentController().spaces[view.selected]
            occupancyTimeoutDurationGeneral(spaceObj)

        }
    })
    $('#occupancy-fadeout-duration').on('change', function(event) {
        var currentView = 'user'
        var self = $(this)
        var target = $(event.target)
        var view = views[currentView]
        // var spaceObj = main.getCurrentController().spaces[view.selected]
        if(view.multiSelected.length > 1){
            for(var i = 0; i < view.multiSelected.length; i++){
                var spaceObj = main.getCurrentController().spaces[view.multiSelected[i]]
                occupancyFadeoutDuration(spaceObj)
             }
        }else{
            var spaceObj = main.getCurrentController().spaces[view.selected]
             occupancyFadeoutDuration(spaceObj)
        }
    })
    $('#occupancy-fadeout-duration-general').on('change', function(event) {
        var currentView = 'general'
        var self = $(this)
        var target = $(event.target)
        var view = views[currentView]
        // var spaceObj = main.getCurrentController().spaces[view.selected]
        if(view.multiSelected.length > 1){
            for(var i = 0; i < view.multiSelected.length; i++){
                var spaceObj = main.getCurrentController().spaces[view.multiSelected[i]]
                occupancyFadeoutDurationGeneral(spaceObj)
             }
        }else{
            var spaceObj = main.getCurrentController().spaces[view.selected]
             occupancyFadeoutDurationGeneral(spaceObj)
        }
    })
    // NOTE-MAK: log events for a picker
    /* NOTE-MAK: Occupancy timeout button */
    var $timeout_input = $('#occupancy-timeout-duration').pickatime({
        container: 'body',
        format: 'Hmis', // 5m0s
        formatLabel: '<sm!all>H</sm!all>m<sm!all>i</sm!all>s', // 5m0s
        interval: 5,
        min: [0, 0],
        max: [23, 55],
        onClose: function() {
            $(document.activeElement).blur()
        }
    })
    var $timeout_input_general = $('#occupancy-timeout-duration-general').pickatime({
        container: 'body',
        format: 'Hmis', // 5m0s
        formatLabel: '<sm!all>H</sm!all>m<sm!all>i</sm!all>s', // 5m0s
        interval: 5,
        min: [0, 0],
        max: [23, 55],
        onClose: function() {
            $(document.activeElement).blur()
        }
    })
    /* NOTE-MAK: Occupancy fadeout button */
    var $fadeout_input = $('#occupancy-fadeout-duration').pickatime({
        container: 'body',
        format: 'Hmis', // 5m0s
        formatLabel: '<sm!all>H</sm!all>m<sm!all>i</sm!all>s', // 5m0s
        interval: 5,
        min: [0, 0],
        max: [23, 55],
        onClose: function() {
            $(document.activeElement).blur()
        }
    })
    var $fadeout_input_general = $('#occupancy-fadeout-duration-general').pickatime({
        container: 'body',
        format: 'Hmis', // 5m0s
        formatLabel: '<sm!all>H</sm!all>m<sm!all>i</sm!all>s', // 5m0s
        interval: 5,
        min: [0, 0],
        max: [23, 55],
        onClose: function() {
            $(document.activeElement).blur()
        }
    })
    var timeoutPicker = $timeout_input.pickatime('picker')
    logPickerEvents(timeoutPicker)
    var fadeoutPicker = $fadeout_input.pickatime('picker')
    logPickerEvents(fadeoutPicker)
    var timeoutPickerGeneral = $timeout_input_general.pickatime('picker')
    logPickerEventsGeneral(timeoutPickerGeneral)
    var fadeoutPickerGeneral = $fadeout_input_general.pickatime('picker')
    logPickerEventsGeneral(fadeoutPickerGeneral)
    // NOTE-MAK: disable entire range
    timeoutPicker.set('disable', [
        { from: timeoutPicker.get('min'), to: timeoutPicker.get('max') }
    ])
    fadeoutPicker.set('disable', [
        { from: fadeoutPicker.get('min'), to: fadeoutPicker.get('max') }
    ])
    timeoutPickerGeneral.set('disable', [
        { from: timeoutPickerGeneral.get('min'), to: timeoutPickerGeneral.get('max') }
    ])
    fadeoutPickerGeneral.set('disable', [
        { from: fadeoutPickerGeneral.get('min'), to: fadeoutPickerGeneral.get('max') }
    ])
    // NOTE-MAK: enable time entries
    timeoutPicker.set('enable', [
        { from: [0, 5], to: [0, 5] }, // 5 sec
        { from: [0, 15], to: [0, 15] },
        { from: [0, 30], to: [0, 30] },
        { from: [1, 0], to: [1, 0] },
        { from: [3, 0], to: [3, 0] },
        { from: [5, 0], to: [5, 0] }, // 5 minutes
        { from: [10, 0], to: [10, 0] },
        { from: [15, 0], to: [15, 0] }
        // { from: [20, 0], to: [20, 0] },          // not supported
        // { from: [30, 0], to: [30, 0] },
        // { from: [60, 0], to: [60, 0] },
        // { from: [120, 0], to: [120, 0] }
    ])
    timeoutPickerGeneral.set('enable', [
        { from: [0, 5], to: [0, 5] }, // 5 sec
        { from: [0, 15], to: [0, 15] },
        { from: [0, 30], to: [0, 30] },
        { from: [1, 0], to: [1, 0] },
        { from: [3, 0], to: [3, 0] },
        { from: [5, 0], to: [5, 0] }, // 5 minutes
        { from: [10, 0], to: [10, 0] },
        { from: [15, 0], to: [15, 0] }
        // { from: [20, 0], to: [20, 0] },          // not supported
        // { from: [30, 0], to: [30, 0] },
        // { from: [60, 0], to: [60, 0] },
        // { from: [120, 0], to: [120, 0] }
    ])
    // NOTE-MAK: enable time entries
    fadeoutPicker.set('enable', [
        { from: [0, 5], to: [0, 5] }, // 5 sec
        { from: [0, 15], to: [0, 15] },
        { from: [0, 30], to: [0, 30] },
        { from: [1, 0], to: [1, 0] },
        { from: [3, 0], to: [3, 0] },
        { from: [5, 0], to: [5, 0] }, // 5 minutes
        { from: [10, 0], to: [10, 0] },
        { from: [15, 0], to: [15, 0] }
        // { from: [20, 0], to: [20, 0] },          // not supported
        // { from: [30, 0], to: [30, 0] },
        // { from: [60, 0], to: [60, 0] },
        // { from: [120, 0], to: [120, 0] }
    ])
    fadeoutPickerGeneral.set('enable', [
        { from: [0, 5], to: [0, 5] }, // 5 sec
        { from: [0, 15], to: [0, 15] },
        { from: [0, 30], to: [0, 30] },
        { from: [1, 0], to: [1, 0] },
        { from: [3, 0], to: [3, 0] },
        { from: [5, 0], to: [5, 0] }, // 5 minutes
        { from: [10, 0], to: [10, 0] },
        { from: [15, 0], to: [15, 0] }
        // { from: [20, 0], to: [20, 0] },          // not supported
        // { from: [30, 0], to: [30, 0] },
        // { from: [60, 0], to: [60, 0] },
        // { from: [120, 0], to: [120, 0] }
    ])
    // WARN-MAK: .occupancy class is triggering 3 events for 3 occupancy elements
    // TODO-MAK: use function(event,ui)
    $('.occupancy').on('change', function(event) {

        // WARN-MAK: index.js has hardcoded private var currentView
        // WARN-MAK: using 'user' currentView
        var currentView = 'user'
        var self = $(this)
        var target = $(event.target)
        var view = views[currentView]
        var spaceObj = main.getCurrentController().spaces[view.selected]
        var defaultBuildingObj = main.getCurrentController().spaces.BuildingDefault
        if(view.multiSelected.length > 1){
            for(var i = 0; i < view.multiSelected.length; i++){
                spaceObj = main.getCurrentController().spaces[view.multiSelected[i]]
                occupancy(spaceObj)
            }
        }else{
            var spaceObj = main.getCurrentController().spaces[view.selected]
            occupancy(spaceObj)
        }


    })
    $('.occupancy-general').on('change', function(event) {

        // WARN-MAK: index.js has hardcoded private var currentView
        // WARN-MAK: using 'user' currentView
        var currentView = 'general'
        var self = $(this)
        var target = $(event.target)
        var view = views[currentView]
        var spaceObj = main.getCurrentController().spaces[view.selected]
        var defaultBuildingObj = main.getCurrentController().spaces.BuildingDefault
        if(view.multiSelected.length > 1){
            for(var i = 0; i < view.multiSelected.length; i++){
                spaceObj = main.getCurrentController().spaces[view.multiSelected[i]]
                occupancyGeneral(spaceObj)
            }
        }else{
            var spaceObj = main.getCurrentController().spaces[view.selected]
            occupancyGeneral(spaceObj)
        }


    })
    $('label').click(function() {
       labelID = $(this).attr('for')
       if(labelID === 'timeout-checkbox'){
         $("label").removeClass("ui-checkboxradio-checked")
         $("label").removeClass('ui-state-active')
       }
       if(labelID === 'fadeout-checkbox'){
         $("label").removeClass("ui-checkboxradio-checked")
         $("label").removeClass('ui-state-active')
       }
       if(labelID === 'timeout-checkbox-general'){
         $("label").removeClass("ui-checkboxradio-checked")
         $("label").removeClass('ui-state-active')
       }
       if(labelID === 'fadeout-checkbox-general'){
         $("label").removeClass("ui-checkboxradio-checked")
         $("label").removeClass('ui-state-active')
       }
    });
    $('.cicedium-cycle').on('change', function(event) {

        // WARN-MAK: index.js has hardcoded private var currentView
        // WARN-MAK: using 'user' currentView
        var currentView = 'user'
        var self = $(this)
        var target = $(event.target)
        var view = views[currentView]
        var spaceObj = main.getCurrentController().spaces[view.selected]
        var defaultBuildingObj = main.getCurrentController().spaces.BuildingDefault
        if(view.multiSelected.length > 1){
            for(var i = 0; i < view.multiSelected.length; i++){
                spaceObj = main.getCurrentController().spaces[view.multiSelected[i]]
                cicadiumCycle(spaceObj)
            }
        }else{
            var spaceObj = main.getCurrentController().spaces[view.selected]
            cicadiumCycle(spaceObj)
        }


    })

    function logPickerEvents(picker) {
      if (picker) {
          picker.on({
              open: function() {
                  // console.log(arguments.callee.name)
              },
              close: function() {
                  // console.log(arguments.callee.name)
              },
              render: function() {
                  // console.log(arguments.callee.name)
              },
              start: function() {
                  // console.log(arguments.callee.name)
              },
              stop: function() {
                  // console.log(arguments.callee.name)
              },
              set: function(thingSet) {
                  // console.log('Set stuff:', thingSet)
              }
          })
      }
    }
    function logPickerEventsGeneral(picker) {
      if (picker) {
          picker.on({
              open: function() {
                  // console.log(arguments.callee.name)
              },
              close: function() {
                  // console.log(arguments.callee.name)
              },
              render: function() {
                  // console.log(arguments.callee.name)
              },
              start: function() {
                  // console.log(arguments.callee.name)
              },
              stop: function() {
                  // console.log(arguments.callee.name)
              },
              set: function(thingSet) {
                  // console.log('Set stuff:', thingSet)
              }
          })
      }
    }
    function occupancyFadeoutDuration(spaceObj){
            var view = views[currentView]
             // WARN-MAK: spaceObj is undefined when exiting user-zone and
            if (!spaceObj) {
                return undefined
            }

            var picker = fadeoutPicker.get('select')

            // NOTE--MAK: placeholder. using picker get() instead
            var fadeout = {
                minutes: picker === null ? 0 : picker.hour,
                // minutes: parseInt(self.find('.fadeout-min').val(), 10) % 60,
                seconds: picker === null ? 0 : picker.mins
                    // seconds: parseInt(self.find('.fadeout-sec').val(), 10) % 60
            }

            // NOTE-MAK: total time in seconds
            if(activeTab > 1){
              updatedScheduleEntryOjb._fadeout = picker.time
            }else{
              spaceObj._fadeout = picker.time
            }
    }
    function occupancyFadeoutDurationGeneral(spaceObj){
            var view = views[currentView]
             // WARN-MAK: spaceObj is undefined when exiting user-zone and
            if (!spaceObj) {
                return undefined
            }

            var pickerGeneral = fadeoutPickerGeneral.get('select')

            // NOTE--MAK: placeholder. using picker get() instead
            var fadeoutGeneral = {
                minutes: pickerGeneral === null ? 0 : pickerGeneral.hour,
                // minutes: parseInt(self.find('.fadeout-min').val(), 10) % 60,
                seconds: pickerGeneral === null ? 0 : pickerGeneral.mins
                    // seconds: parseInt(self.find('.fadeout-sec').val(), 10) % 60
            }

            // NOTE-MAK: total time in seconds
            if(activeTabGeneral > 1){
              updatedScheduleEntryOjb._fadeout = pickerGeneral.time
            }else{
              spaceObj._fadeout = pickerGeneral.time
            }
    }
    function availLightscene(spaceObj){

        if(activeTab > 1){
          updateScheduleEntry(updatedScheduleEntryOjb, entry, schedule, spaceObj)
        }
        if(activeTabGeneral > 1){
          updateScheduleEntry(updatedScheduleEntryOjb, entry, schedule, spaceObj)
        }
        if(activeTabBeacon > 1){
          updateScheduleEntry(updatedScheduleEntryOjb, entry, schedule, spaceObj)
        }
    }
    function brightnessEntry(spaceObj, value, activeTab){
        if(activeTab > 1){
          updatedScheduleEntryOjb.brightness = value
          updateScheduleEntry(updatedScheduleEntryOjb, entry, schedule, spaceObj)
        }else if(activeTabGeneral > 1){
            updatedScheduleEntryOjb.brightness = value
            updateScheduleEntry(updatedScheduleEntryOjb, entry, schedule, spaceObj)
        }else if(activeTabBeacon > 1){
          updatedScheduleEntryOjb.brightness = value
          updateScheduleEntry(updatedScheduleEntryOjb, entry, schedule, spaceObj)
      }else{
          spaceObj._defaultBrightness = value
        }
    }
    function occupancyTimeoutDuration(spaceObj){
        var view = views[currentView]
        // WARN-MAK: spaceObj is undefined when exiting user-zone and
        if (!spaceObj) {
            return undefined
        }
        var picker = timeoutPicker.get('select')
        // NOTE--MAK: placeholder. using picker get() instead
        var timeout = {
            minutes: picker === null ? 0 : picker.hour,
            // minutes: [parseInt(self.find('.timeout-min').val(), 10) % 60] * 60,
            seconds: picker === null ? 0 : picker.mins
            // seconds: parseInt(self.find('.timeout-sec').val(), 10) % 60
        }

        // NOTE-MAK: total time in seconds
        if(activeTab > 1){
            updatedScheduleEntryOjb._timeout = picker.time
        }else{
            spaceObj._timeout = picker.time
        }
     }
    function occupancyTimeoutDurationGeneral(spaceObj){
         var view = views[currentView]
         // WARN-MAK: spaceObj is undefined when exiting user-zone and
         if (!spaceObj) {
             return undefined
         }
         var pickerGeneral = timeoutPickerGeneral.get('select')
         // NOTE--MAK: placeholder. using picker get() instead
         var timeoutGeneral = {
             minutes: pickerGeneral === null ? 0 : pickerGeneral.hour,
             // minutes: [parseInt(self.find('.timeout-min').val(), 10) % 60] * 60,
             seconds: pickerGeneral === null ? 0 : pickerGeneral.mins
             // seconds: parseInt(self.find('.timeout-sec').val(), 10) % 60
         }

         // NOTE-MAK: total time in seconds
         if(activeTab > 1){
             updatedScheduleEntryOjb._timeout = pickerGeneral.time
         }else{
             spaceObj._timeout = pickerGeneral.time
         }
      }
    function occupancy(spaceObj){
       var view = views[currentView]
       var defaultBuildingObj = main.getCurrentController().spaces.BuildingDefault
             // WARN-MAK: spaceObj is undefined when exiting user-zone and
          if (!spaceObj) {
              return undefined
          }

          // TODO-MAK: onIdle + onOccupancy conditions

          var onIdle = {
              default: "default",
              off: "off",
              on: "stayOn"
          }

          var onOccupancy = {
              off: "leaveOff",
              on: ""
          }

          //NOTE- Kamlesh: DT-52 Add afterIdleTimeout
          var afterIdleTimeout = {
              off: "",
              reset:"resetBrightness"

          }

          // NOTE-MAK: explicit implementation
          // var timeoutIsChecked = $timeout_checkbox.is(':checked')
          // var fadeoutIsChecked = $fadeout_checkbox.is(':checked')
          var manualIsChecked = $manual_on_checkbox.is(':checked')


          //NOTE- Kamlesh : DT-52 SensorBrain- condition when manual is on
          if(manualIsChecked !== false ){
              defaultBuildingObj.sensorBrain.behaviours = {onIdle: onIdle.default, onOccupancy: onOccupancy.off, afterIdleTimeout: afterIdleTimeout.reset}
              spaceObj.sensorBrain.behaviours = {onIdle: onIdle.default, onOccupancy: onOccupancy.off, afterIdleTimeout: afterIdleTimeout.reset}

          }else{
              defaultBuildingObj.sensorBrain.behaviours = {onIdle: onIdle.default, afterIdleTimeout: afterIdleTimeout.reset}
              spaceObj.sensorBrain.behaviours = {onIdle: onIdle.default, afterIdleTimeout: afterIdleTimeout.reset}
          }
          // WARN-MAK: adding temporary state properties for timeout, fadeout, and manual-on buttons
          if(manualIsChecked == true){
            spaceObj._onOccupancy = 'leaveOff'
          }else{
            spaceObj._onOccupancy = ''
          }

    }
    function occupancyGeneral(spaceObj){
       var view = views[currentView]
       var defaultBuildingObj = main.getCurrentController().spaces.BuildingDefault
             // WARN-MAK: spaceObj is undefined when exiting user-zone and
          if (!spaceObj) {
              return undefined
          }

          // TODO-MAK: onIdle + onOccupancy conditions

          var onIdle = {
              default: "default",
              off: "off",
              on: "stayOn"
          }

          var onOccupancy = {
              off: "leaveOff",
              on: ""
          }

          //NOTE- Kamlesh: DT-52 Add afterIdleTimeout
          var afterIdleTimeout = {
              off: "",
              reset:"resetBrightness"

          }

          // NOTE-MAK: explicit implementation
          // var timeoutIsChecked = $timeout_checkbox.is(':checked')
          // var fadeoutIsChecked = $fadeout_checkbox.is(':checked')
          var manualIsCheckedGeneral = $manual_on_checkbox_general.is(':checked')


          //NOTE- Kamlesh : DT-52 SensorBrain- condition when manual is on
          if(manualIsCheckedGeneral !== false ){
              defaultBuildingObj.sensorBrain.behaviours = {onIdle: onIdle.default, onOccupancy: onOccupancy.off, afterIdleTimeout: afterIdleTimeout.reset}
              spaceObj.sensorBrain.behaviours = {onIdle: onIdle.default, onOccupancy: onOccupancy.off, afterIdleTimeout: afterIdleTimeout.reset}

          }else{
              defaultBuildingObj.sensorBrain.behaviours = {onIdle: onIdle.default, afterIdleTimeout: afterIdleTimeout.reset}
              spaceObj.sensorBrain.behaviours = {onIdle: onIdle.default, afterIdleTimeout: afterIdleTimeout.reset}
          }
          // WARN-MAK: adding temporary state properties for timeout, fadeout, and manual-on buttons
          if(manualIsCheckedGeneral == true){
            spaceObj._onOccupancy = 'leaveOff'
          }else{
            spaceObj._onOccupancy = ''
          }

    }
    function timepicker(spaceObj, activeTab){
        var view = views[currentView]
        // NOTE-MAK: two fields having a  shared property
        var time_start = $('#time_start').pickatime('picker').get('select', 'HH:i')
        var time_end = $('#time_end').pickatime('picker').get('select', 'HH:i')
        var time_start_schedule = $('#time_start_schedule').pickatime('picker').get('select', 'HH:i')
        var trigger = 'bt#' + time_start + ' ' + time_end
        // WARN-MAK: spaceObj is undefined when exiting user-zone and
        if (!spaceObj) {
            return undefined
        }
        if(activeTab > 1){
          updatedScheduleEntryOjb.trigger = time_start_schedule
          updateScheduleEntry(updatedScheduleEntryOjb, entry, schedule, spaceObj)
        }else{
           spaceObj._zoneActiveTrigger = trigger
        }

    }
    function timepicker_general(spaceObj, activeTab){
        var view = views[currentView]
        // NOTE-MAK: two fields having a  shared property
        var activation_time_from = $('#activation-time-from').pickatime('picker').get('select', 'HH:i')
        var activation_time_to = $('#activation-time-to').pickatime('picker').get('select', 'HH:i')
        var time_start_schedule_general = $('#time_start_schedule_general').pickatime('picker').get('select', 'HH:i')
        var trigger = 'bt#' + activation_time_from + ' ' + activation_time_to
        // WARN-MAK: spaceObj is undefined when exiting user-zone and
        if (!spaceObj) {
            return undefined
        }
        if(activeTabGeneral > 1){
          updatedScheduleEntryOjb.trigger = time_start_schedule_general
          updateScheduleEntry(updatedScheduleEntryOjb, entry, schedule, spaceObj)
        }else{
           spaceObj._zoneActiveTrigger = trigger
        }

    }
    function timepicker_beacon(spaceObj, activeTab){
        var view = views[currentView]
        // NOTE-MAK: two fields having a  shared property
        var time_start_beacon = $('#time_start_beacon').pickatime('picker').get('select', 'HH:i')
        var time_end_beacon = $('#time_end_beacon').pickatime('picker').get('select', 'HH:i')
        var time_start_schedule_beacon = $('#time_start_schedule_beacon').pickatime('picker').get('select', 'HH:i')
        var trigger = 'bt#' + time_start_beacon + ' ' + time_end_beacon
        // WARN-MAK: spaceObj is undefined when exiting user-zone and
        if (!spaceObj) {
            return undefined
        }
        if(activeTabBeacon > 1){
          updatedScheduleEntryOjb.trigger = time_start_schedule_beacon
          updateScheduleEntry(updatedScheduleEntryOjb, entry, schedule, spaceObj)
        }else{
           spaceObj._zoneActiveTrigger = trigger
        }

    }
    function updateScheduleEntry(updatedScheduleEntryOjb, entry, schedule, spaceObj){
          updatedScheduleEntryOjb.lightScene = spaceObj.defaultLightScene
          switch(currentView){
            case 'user':
            updatedScheduleEntryOjb.action = "=lightScene#"+spaceObj.defaultLightScene+":"+spaceObj.defaultLightScene +";=mood#"+spaceObj.defaultMood+";=brightness#"+updatedScheduleEntryOjb.brightness
            break ;
            case 'beacon':
            updatedScheduleEntryOjb.action = "=lightScene#"+spaceObj.defaultLightScene+":"+spaceObj.defaultLightScene +";=mood#"+spaceObj.defaultMood+";=brightness#"+updatedScheduleEntryOjb.brightness
            break ;
            case 'general':
            updatedScheduleEntryOjb.action = "=lightScene#"+spaceObj.defaultLightScene+":"+spaceObj.defaultLightScene +";=brightness#"+updatedScheduleEntryOjb.brightness
            break ;
          }
          entry.setAction(updatedScheduleEntryOjb.action)
          entry.setTime(updatedScheduleEntryOjb.trigger)
          entry.setBrightness(updatedScheduleEntryOjb.brightness)
          entry.setLS(updatedScheduleEntryOjb.lightScene)
          // console.log("updateEntry_schedule " , schedule)
          switch(currentView){
            case 'user':
            schedule.addEntry(entry, activeTab)
            spaceObj.addSchedule(schedule, spaceObj.amBXSpace)
            break ;
            case 'beacon':
            schedule.addEntry(entry, activeTabBeacon)
            spaceObj.addSchedule(schedule, spaceObj.amBXSpace)
            break ;
            case 'general':
            schedule.addEntry(entry, activeTabGeneral)
            spaceObj.addSchedule(schedule, spaceObj.amBXSpace)
            break ;
          }

    }
    function cicadiumCycle(spaceObj){
        if (!spaceObj) {
            return undefined
        }
        var animatedInfluence = {
            off: 100,
            on: 0
        }
        var $cicadium_on_checkbox = $("#cicadium-cycle-checkbox")
        var cicadiumIsChecked = $cicadium_on_checkbox.is(':checked')
        //NOTE- Kamlesh : DT-52 SensorBrain- condition when manual is on
        if(cicadiumIsChecked !== false ){
            spaceObj.defaultAnimatedPalette = {animatedInfluence:animatedInfluence.on};
            document.getElementById('lableToChange').innerHTML = '"Turn-ON" Circadian Rhythm';
        }else{
            spaceObj.defaultAnimatedPalette = {animatedInfluence:animatedInfluence.off};
            document.getElementById('lableToChange').innerHTML = '"Turn-OFF" Circadian Rhythm';

        }
    }

})
