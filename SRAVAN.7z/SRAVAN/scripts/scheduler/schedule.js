"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Schedule = exports.Schedule = function () {
    function Schedule(id, building, floor, space, schId) {
        _classCallCheck(this, Schedule);

        this[schId] = {atTime:"", action:"", otherwise:""};
        // this._building = building;
        // this._floor = floor;
        // this._space = space;
        // this._entries = [];
    }

    _createClass(Schedule, [{
        key: "getID",
        value: function getID() {
            return this[id];
        }
    }, {
        key: "getEntry",
        value: function getEntry(id) {
            var entry = this.filter(function (entry) {
                return entry._id == id;
            });
            return entry.pop();
        }
    }, {
        key: "getEntries",
        value: function getEntries() {
            return this;
        }
    }, {
        key: "addEntry",
        value: function addEntry(entry, activeId) {
            console.log("add entry", this)
            console.log("add entry activeId", activeId)
            return this[activeId] = entry ;
            // return this._entries.push(entry);
        }
    }, {
        key: "addEntryAction",
        value: function addEntry(entry, activeId) {
            return this[activeId].action = entry.action ;
            // return this._entries.push(entry);
        }
    }, {
        key: "addEntryTime",
        value: function addEntry(entry, activeId) {
            return this[activeId].atTime = entry.atTime ;
            // return this._entries.push(entry);
        }
    }, {
        key: "addEntryOtherwise",
        value: function addEntry(entry, activeId) {
            return this[activeId].otherwise = entry.otherwise ;
            // return this._entries.push(entry);
        }
    }, {
        key: "updateEntry",
        value: function updateEntry(entry, activeId) {
            console.log(this[activeId])
            console.log(entry)
            // return this[activeId] = entry ;
            // return this._entries.push(entry);
        }
    }, {
        key: "removeEntry",
        value: function removeEntry(id) {
            return delete this[id]
        }

        // WARN-MAK: delete entry (indexOf) is incorrect. strange behaviour. removed incorrect element.
        // deleteEntry(entry) {
        //     let index = this._entries.indexOf(entry)
        //     return this._entries.splice(index, 1)
        // }

    }]);

    return Schedule;
}();

// Schedule {
//     _building: "building_1"
//     _entries: Array(3)
//     0: ScheduleEntry
//     1: ScheduleEntry
//     2: ScheduleEntry
//     _floor: "floor_1"
//     _id: 1
//     _space: "user_space_1"
// }
