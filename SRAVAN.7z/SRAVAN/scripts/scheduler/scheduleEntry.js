'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var ScheduleEntry = exports.ScheduleEntry = function () {
    function ScheduleEntry(id, name) {
        _classCallCheck(this, ScheduleEntry);

        this.id = id;
        this._name = name;
        // this._time = '';
        this.lightScene = '';
        this.action = '';
        this.otherwise = '';
        this.mood = '';
        this.brightness = '';
        // this._timeout = '';
        // this._fadeout = '';
        this.trigger = '';
        // this._dhTargetLux = '';
        // this._dhDeltaUp = '';
        // this._dhDeltaDown = '';
    }

    _createClass(ScheduleEntry, [{
        key: 'setName',
        value: function setName(name) {
            this._name = name;
        }
    }, {
        key: 'setTime',
        value: function setTime(time) {
            this.trigger = "ct#"+time;
        }
    }, {
        key: 'setAction',
        value: function setAction(actionData) {
            this.action = actionData;
        }
    }, {
        key: 'setBehaviour',
        value: function setBehaviour(behaviour) {
            this._behaviour = behaviour;
        }
    }, {
        key: 'setLS',
        value: function setLS(ls) {
            this.lightScene = ls;
        }
    }, {
        key: 'setMood',
        value: function setMood(mood) {
            this.mood = mood;
        }
    }, {
        key: 'setBrightness',
        value: function setBrightness(brightness) {
            this.brightness = brightness;
        }
    }, {
        key: 'setTimeout',
        value: function setTimeout(timeout) {
            this._timeout = timeout;
        }
    }, {
        key: 'setFadeout',
        value: function setFadeout(fadeout) {
            this._fadeout = fadeout;
        }
    }]);

    return ScheduleEntry;
}();

// ScheduleEntry {
//     _behaviour: "" ok
//     _brightness: "" ok
//     _dhDeltaDown: "" ok
//     _dhDeltaUp: "" ok
//     _dhTargetLux: "" ok
//     _fadeout: "" ok
//     _lightScene: "" empty
//     _lightscene: "daylight" empty
//     _mood: undefined empty
//     _name: "default" ok
//     _time: "06:00"ok
//     _timeout: ""ok
//     _zoneActiveTrigger: ""ok
// }
