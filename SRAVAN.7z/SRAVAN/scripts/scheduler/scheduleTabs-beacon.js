var Scheduler = require('../scheduler/scheduler')
var Schedule = require('../scheduler/schedule')
var ScheduleEntry = require('../scheduler/scheduleEntry')

$(function() {

    $("#beacon-schedule-tab").tabs();

    var name = '' ;
    var tabTitle = $("#tab_title_beacon"),
        tabTemplate =
        "<li>" +
        "<a href='#{href}'>#{label}</a>" +
        "<span class='ui-icon ui-icon-close' role='presentation'>Remove Tab</span>" +
        "</li>",
        tabCounterBeacon = 2;

    // NOTE-MAK: initializing tabs identifiers as jquery tabs
    var tabsBeacon = $("#beacon-schedule-tab").tabs({
        activate: function(event, ui) {
            // var viewVal = $(this)
            //     .data('view')
            // if (viewVal !== currentView) {
            //     currentView = viewVal
            //     views[currentView].updateTab()
            //     $('.current-view')
            //         .val([viewVal])
            // }
            // console.log(viewVal);
        }
    });

    // Modal dialog init: custom buttons and a "close" callback resetting the form inside
    var dialogBeacon = $("#dialog-beacon").dialog({
        autoOpen: false,
        modal: true,
        buttons: {
            Add: function() {
                addScheduleEntryBeacon(tabCounterBeacon, addTab());
                incrementCounter();
                $(this).dialog("close");
            },
            Cancel: function() {
                $(this).dialog("close");
            }
        },
        close: function() {
            form[0].reset();
        }
    });

    // NOTE-MAK: may need var=form to reload button tabs on json load. add all tabs back in.
    // NOTE-MAK: property load behaves the same on click.

    // AddTab form: calls addTab function on submit and closes the dialog
    var form = dialogBeacon.find("form").on("submit", function(event) {
        addTab();
        dialogBeacon.dialog("close");
        event.preventDefault();
    });

    // Actual addTab function: adds new tab using the input from the form above
    // NOTE-MAK: custom logic
    function addTab() {
        var label = tabTitle.val() || "Schedule " + tabCounterBeacon,
            id = "tabs-beacon-" + tabCounterBeacon,
            li = $(tabTemplate.replace(/#\{href\}/g, "#" + id).replace(/#\{label\}/g, label));

        //tabs.find(".ui-tabs-nav").append(li);

        li.insertBefore("#plus-beacon-1");

        // NOTE-MAK: matching div for li ahref
        tabsBeacon.append(
            "<div id='" + id + "'>" +
            "<div id='schedule-" + tabCounterBeacon + "'>" + "</div>" +
            "</div>"
        )

        //.before(document.getElementById("plus-1"));

        tabsBeacon.tabs("refresh");
        return label ;
    }

    // NOTE-MAK: custom logic using templtaes
    // function addSchedule() {
    //     $("#schedule-" + tabCounterBeacon).load("./templates/schedule.html");
    // }
    //

    // NOTE-MAK: using scheduler from index.js
    function addScheduleEntryBeacon(id, name) {
        // WARN-MAK: index.js has hardcoded private var currentView
        // WARN-MAK: using 'user' currentView
        var currentView = 'beacon'
        var view = views[currentView]
        var spaceName = view.selected
        var spaceObj = main.getCurrentController().spaces[spaceName]
        //alert("From ScheduleTab"+JSON.stringify(spaceObj))
        var scheduler = Scheduler.singleton
        var schedule = scheduler.getSchedule(spaceObj.amBXSpace)
        // NOTE-MAK: get the schedule for this space
        if (schedule === undefined) {
            // TODO-MAK: iterate over all maps
            let mapID = "map_1"
            let map = spaceObj.maps[mapID]
            schedule = new Schedule.Schedule(spaceObj.amBXSpace, map.building, map.floor, spaceName, id)
            scheduler.addSchedule(schedule, spaceObj.amBXSpace)
        }
        let entry = new ScheduleEntry.ScheduleEntry(id, name)
        var triggerTimes = main.parseTrigger(spaceObj._zoneActiveTrigger)
        entry.setAction("=lightScene#"+spaceObj.defaultLightScene+":"+spaceObj.defaultLightScene+";=mood#"+spaceObj.defaultMood+";=brightness#"+spaceObj._defaultBrightness)
        entry.setBrightness(spaceObj._defaultBrightness)
        entry.setLS(spaceObj.availableLightScenes)
        entry.setMood(spaceObj.defaultMood)
        entry.setTime(triggerTimes[0])
        schedule.addEntry(entry, id)
        spaceObj.addSchedule(schedule, spaceObj.amBXSpace)
    }

    // NOTE-MAK: custom logic
    function incrementCounter() {
        tabCounterBeacon++;
    }

    // AddTab button: just opens the dialog
    $("#add_tab_beacon")
        .button()
        .on("click", function() {
            dialogBeacon.dialog("open");
        });

    // Close icon: removing the tab on click
    tabsBeacon.on("click", "span.ui-icon-close", function(event, ui) {

            // console.log(event)
            // console.log(ui);
            // console.log(event.toElement.id);

        // WARN-MAK: removes the tab by finding the nearby element from 'x' button
        //           need a better way to find ID
        var panelId = $(this).closest("li").remove().attr("aria-controls");
        $("#" + panelId).remove();

        // WARN-MAK: index.js has hardcoded private var currentView
        // WARN-MAK: using 'user' currentView
        var currentView = 'beacon'
        var view = views[currentView]
        var spaceName = view.selected
        var spaceObj = main.getCurrentController().spaces[spaceName]

        var scheduler = Scheduler.singleton
        var schedule = scheduler.getSchedule(spaceObj.amBXSpace)

        let id = panelId.replace('tabs-beacon','')
        let deletedElement = schedule.removeEntry(id);

        // WARN-MAK: delete entry is incorrect. strange behaviour. removed incorrect element.

        // let entry = schedule.getEntry(id)
        // schedule.deleteEntry(entry)

        tabsBeacon.tabs("refresh");
    });

    tabsBeacon.on("keyup", function(event) {
        if (event.altKey && event.keyCode === $.ui.keyCode.BACKSPACE) {
            var panelId = tabsBeacon.find(".ui-tabs-active").remove().attr("aria-controls");
            $("#" + panelId).remove();
            tabsBeacon.tabs("refresh");
        }
    });

});
