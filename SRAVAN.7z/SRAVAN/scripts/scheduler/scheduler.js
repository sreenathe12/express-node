"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Scheduler = function () {
    function Scheduler() {
        _classCallCheck(this, Scheduler);
        this.Scheduler = Scheduler ;
        this._schedules = [];
    }

    _createClass(Scheduler, [{
        key: "getSchedule",
        value: function getSchedule(id) {
            // var schedule = this._schedules.filter(function (schedule) {
            //     return schedule._id == id;
            // });
            if(this._schedules.indexOf(id)){
              return this._schedules[id]
            }

            // return schedule.pop();
        }
    }, {
        key: "getSchedules",
        value: function getSchedules() {
            return this._schedules;
        }
    }, {
        key: "addSchedule",
        value: function addSchedule(schedule, spaceId) {
          console.log("schedule", schedule)
          console.log("addSchedule", this._schedules)
          console.log("[spaceId]", spaceId)
          console.log("this._schedules[spaceId]", this._schedules[spaceId])
            return this._schedules[spaceId] = schedule ;
        }

        // NOTE-MAK: splicing will reindex the schedules array.
        //           id property check is happening for each schedule object

    }, {
        key: "removeSchedule",
        value: function removeSchedule(id) {
            var index = this._schedules.findIndex(function (schedule, index, array) {
                return schedule._id == id;
            });
            return this._schedules.splice(index, 1);
        }
    }, {
        key: "removeAllSchedules",
        value: function removeAllSchedules() {
            // NOTE-MAK: explicitly emptying array
            while (this._schedules.length) {
                this._schedules.pop();
            }
        }
    }]);

    return Scheduler;
}();
/*
    NOTE-MAK:
        * Generator
        * Iterator
        * Fitlers
 */

// NOTE-MAP: single instance of Scheduler


var singleton = exports.singleton = new Scheduler();
